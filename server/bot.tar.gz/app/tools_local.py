"""Local helpers for running SmartBot from this cloud session with data fetched via the user's browser.

Usage:
  python3 tools_local.py merge-daily <bars.json[.gz]>      # merge Yahoo daily bars into data/cache/prices + VIX
  python3 tools_local.py refresh <quotes.json> <app_data_dir>  # intraday refresh of open signals
"""
from __future__ import annotations

import gzip
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
CACHE = ROOT / "data" / "cache" / "prices"


def _load(p: str):
    return json.load(gzip.open(p, "rt") if p.endswith(".gz") else open(p, encoding="utf-8"))


def merge_daily(path: str) -> None:
    raw = _load(path)
    CACHE.mkdir(parents=True, exist_ok=True)
    n = 0
    for s, v in raw.items():
        idx = pd.to_datetime(np.array(v["d"]) * 86400, unit="s").normalize()
        if s.startswith("^"):
            continue
        new = pd.DataFrame({"open": v["o"], "high": v["h"], "low": v["l"], "close": v["c"], "volume": v["v"]}, index=idx).dropna(subset=["close"])
        f = CACHE / f"{s}.csv"
        if f.exists():
            old = pd.read_csv(f, index_col=0, parse_dates=True)
            # Yahoo adjusted history can shift after a dividend/split: if overlap differs, keep the new values.
            df = pd.concat([old[~old.index.isin(new.index)], new]).sort_index()
        else:
            df = new
        df = df[~df.index.duplicated(keep="last")]
        df.to_csv(f)
        n += 1
    vx = {}
    for k, s in (("vix", "^VIX"), ("vix3m", "^VIX3M")):
        if s in raw:
            vx[k] = pd.Series(raw[s]["rc"], index=pd.to_datetime(np.array(raw[s]["d"]) * 86400, unit="s").normalize())
    if vx:
        vp = ROOT / "data" / "cache" / "vix_term.csv"
        new = pd.DataFrame(vx).dropna()
        if vp.exists():
            old = pd.read_csv(vp, index_col=0, parse_dates=True)
            new = pd.concat([old[~old.index.isin(new.index)], new]).sort_index()
        new.to_csv(vp)
    print(f"merged {n} symbols")


def refresh(quotes_path: str, out_dir: str) -> None:
    sys.path.insert(0, str(ROOT))
    from smartbot.config import load_config, resolve_path  # noqa: E402
    from smartbot.export import refresh_prices  # noqa: E402
    from smartbot.journal import Journal  # noqa: E402

    quotes = _load(quotes_path)
    cfg = load_config(str(ROOT / "config.yaml"))
    j = Journal(resolve_path(cfg, cfg["general"]["journal_db"]))

    def fetch(sym, _since):
        q = quotes.get(sym)
        return q if q and q.get("last") is not None else None

    print(refresh_prices(Path(out_dir), fetch, j, force=True))


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "merge-daily":
        merge_daily(sys.argv[2])
    elif cmd == "refresh":
        refresh(sys.argv[2], sys.argv[3])
    else:
        raise SystemExit(__doc__)
