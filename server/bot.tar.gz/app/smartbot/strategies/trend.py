"""Time-series momentum (Moskowitz, Ooi & Pedersen 2012).

Fires when the 12-month return excluding the last month is positive AND the
close is above its 200-day SMA.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..data import MarketBundle
from ..indicators import sma, total_return
from .base import Strategy, StrategyOutput


class TrendStrategy(Strategy):
    name = "trend"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        close = bundle.prices.close
        ret = total_return(close, int(p.get("lookback_days", 252)), int(p.get("skip_days", 21)))
        ma = sma(close, int(p.get("sma_days", 200)))
        entry = (ret > 0) & (close > ma)
        return StrategyOutput(self.name, score=ret, entry=self._bool(entry))


class CrisisTrendStrategy(Strategy):
    """Defensive crisis sleeve: long-only time-series trend on bonds, gold, commodities, dollar.

    These assets have historically tended to trend up during equity sell-offs (not guaranteed).
    entry: N-day return > 0 and close > SMA;  exit: close < exit SMA.
    """

    name = "crisis_trend"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        close = bundle.prices.close
        allowed = [s for s in p.get("symbols", ["TLT", "IEF", "GLD", "DBC", "UUP"]) if s in close.columns]
        if not allowed:
            return self.unavailable(bundle, "no crisis assets in the price data")
        ret = total_return(close, int(p.get("lookback_days", 126)), 0)
        ma = sma(close, int(p.get("sma_days", 100)))
        mask = close.columns.isin(allowed)[None, :]
        entry = (ret > 0) & (close > ma) & mask
        exit_ = close < sma(close, int(p.get("exit_sma_days", 100)))
        maskdf = pd.DataFrame(np.repeat(mask, len(close), axis=0), index=close.index, columns=close.columns)
        return StrategyOutput(self.name, score=ret.where(maskdf), entry=self._bool(entry), exit=self._bool(exit_))
