"""Swing (days to weeks, daily bars) and 1-day strategies.

* SwingPullbackStrategy  - Connors-style RSI(2) pullback in an uptrend:
    entry: close > SMA200 and RSI(2) < 10;  exit: close > SMA5.
* BreakoutStrategy       - Turtle-style Donchian breakout (ETFs/indices):
    entry: close > highest high of the previous N days; exit: close < lowest low of previous M days.
* MeanReversion1DStrategy - EXPERIMENTAL 1-day mean reversion on liquid ETFs/large caps:
    entry: close > SMA200, RSI(2) < 5, IBS < 0.2; exit by time (next close).
"""
from __future__ import annotations

import pandas as pd

from ..data import MarketBundle
from ..indicators import dollar_volume, donchian_high, donchian_low, ibs, rsi, sma
from .base import Strategy, StrategyOutput


class SwingPullbackStrategy(Strategy):
    name = "swing_pullback"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        c = bundle.prices.close
        trend = c > sma(c, int(p.get("sma_days", 200)))
        exit_ = c > sma(c, int(p.get("exit_sma_days", 5)))
        if p.get("mode", "rsi") == "low_n":
            # pullback to the N-day closing low inside an uptrend
            n = int(p.get("low_days", 10))
            low_n = c.rolling(n, min_periods=n).min()
            entry = trend & (c <= low_n)
            score = -(c / c.rolling(n, min_periods=n).max() - 1.0)
            return StrategyOutput(self.name, score=score, entry=self._bool(entry), exit=self._bool(exit_))
        r = rsi(c, int(p.get("rsi_days", 2)))
        entry = trend & (r < float(p.get("rsi_entry_below", 10)))
        return StrategyOutput(self.name, score=100.0 - r, entry=self._bool(entry), exit=self._bool(exit_))


class BreakoutStrategy(Strategy):
    name = "breakout"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        px = bundle.prices
        dh = donchian_high(px.high, int(p.get("entry_days", 20)))
        dl = donchian_low(px.low, int(p.get("exit_days", 10)))
        entry = px.close > dh
        if p.get("trend_sma_days"):
            entry = entry & (px.close > sma(px.close, int(p["trend_sma_days"])))
        if p.get("universe", "etf") == "etf":
            mask = pd.Series({s: bool(bundle.is_etf.get(s, False)) for s in px.symbols})
            entry = entry & mask.reindex(px.symbols).to_numpy()[None, :]
        exit_ = px.close < dl
        score = px.close / dh - 1.0
        return StrategyOutput(self.name, score=score, entry=self._bool(entry), exit=self._bool(exit_))


class MeanReversion1DStrategy(Strategy):
    name = "mean_reversion_1d"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        px = bundle.prices
        c = px.close
        r = rsi(c, int(p.get("rsi_days", 2)))
        trend = c > sma(c, int(p.get("sma_days", 200)))
        low_close = ibs(px.high, px.low, c) < float(p.get("ibs_below", 0.2))
        etf = pd.Series({s: bool(bundle.is_etf.get(s, False)) for s in px.symbols}).reindex(px.symbols).to_numpy()[None, :]
        if p.get("etfs_only", False):
            liquid = pd.DataFrame(etf.repeat(len(c), axis=0), index=c.index, columns=c.columns)
        else:
            big = dollar_volume(c, px.volume, 20) >= float(p.get("min_dollar_volume", 3e8))
            liquid = big | etf
        entry = trend & (r < float(p.get("rsi_entry_below", 5))) & low_close & liquid
        exit_ = None
        if p.get("exit_sma_days"):
            exit_ = self._bool(c > sma(c, int(p["exit_sma_days"])))
        return StrategyOutput(self.name, score=100.0 - r, entry=self._bool(entry), exit=exit_)
