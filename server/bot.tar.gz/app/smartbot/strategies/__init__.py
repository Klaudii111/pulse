"""Strategy registry."""
from __future__ import annotations

from typing import Any

from .base import Strategy, StrategyOutput
from .extra import CalendarEffectsStrategy, InsiderClusterStrategy, SectorRotationStrategy, WeeklyReversalStrategy
from .momentum import MomentumStrategy
from .quality_value import QualityValueStrategy
from .smart_money import SmartMoneyStrategy
from .stubs import AnalystRevisionStrategy, PEADStrategy
from .shortterm import DeepPullbackStrategy, RsiVixStrategy, VolatileOversoldStrategy
from .swing import BreakoutStrategy, MeanReversion1DStrategy, SwingPullbackStrategy
from .trend import CrisisTrendStrategy, TrendStrategy

REGISTRY: dict[str, type[Strategy]] = {
    "trend": TrendStrategy,
    "momentum": MomentumStrategy,
    "smart_money": SmartMoneyStrategy,
    "quality_value": QualityValueStrategy,
    "swing_pullback": SwingPullbackStrategy,
    "breakout": BreakoutStrategy,
    "mean_reversion_1d": MeanReversion1DStrategy,
    "crisis_trend": CrisisTrendStrategy,
    "sector_rotation": SectorRotationStrategy,
    "insider_cluster": InsiderClusterStrategy,
    "calendar_effects": CalendarEffectsStrategy,
    "weekly_reversal": WeeklyReversalStrategy,
    "pead": PEADStrategy,
    "analyst_revisions": AnalystRevisionStrategy,
    # DNY (2-3 day) variants of the classes above, configured separately
    "mean_reversion_3d": MeanReversion1DStrategy,
    "pullback_10d_low": SwingPullbackStrategy,
    "short_breakout": BreakoutStrategy,
    # 2026-11 short-horizon set
    "deep_pullback": DeepPullbackStrategy,
    "deep_pullback_hold": DeepPullbackStrategy,
    "volatile_oversold": VolatileOversoldStrategy,
    "rsi_vix": RsiVixStrategy,
}


def build_strategy(name: str, cfg: dict[str, Any]) -> Strategy:
    params = cfg["strategies"].get(name, {})
    return REGISTRY[name](params, name=name)


__all__ = ["Strategy", "StrategyOutput", "REGISTRY", "build_strategy"]
