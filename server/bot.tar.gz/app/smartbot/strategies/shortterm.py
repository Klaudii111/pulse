"""Short-horizon strategies (2-3 days / 1 week), researched 2026-11 on 2015-2022 and checked on 2023-2026.

* DeepPullbackStrategy   - liquid stock in a long-term uptrend falls more than K x ATR(14) below its
                           5-day high while fear is elevated (VIX above a threshold): buy the panic dip.
* VolatileOversoldStrategy - liquid, volatile stock (ATR% above a threshold) in an uptrend with RSI(2)
                           below a threshold: short-term oversold bounce.
* RsiVixStrategy         - RSI(2) below a threshold in an uptrend, only when VIX is elevated.
All exits: close above the N-day SMA (executed next open) or the track's time limit.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..data import MarketBundle
from ..indicators import atr, dollar_volume, rsi, sma, total_return
from .base import Strategy, StrategyOutput


def _vix_mask(bundle: MarketBundle, idx: pd.DatetimeIndex, cols, vmin: float | None) -> pd.DataFrame | bool:
    if not vmin:
        return True
    if bundle.vix is None or "vix" not in bundle.vix.columns:
        return False
    v = bundle.vix["vix"].reindex(idx).ffill()
    m = (v > float(vmin)).to_numpy()[:, None]
    return pd.DataFrame(np.repeat(m, len(cols), axis=1), index=idx, columns=cols)


def _base(bundle: MarketBundle, p: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    px = bundle.prices
    c = px.close
    liquid = (dollar_volume(c, px.volume, 20) >= float(p.get("min_dollar_volume", 5e7))) & (c >= float(p.get("min_price", 5)))
    up = c > sma(c, int(p.get("sma_days", 200)))
    base = liquid & up
    bench = p.get("market_symbol", "SPY")
    if bench in c.columns:  # market in a long-term uptrend (SPY above its 200-day average)
        mk = (c[bench] > c[bench].rolling(int(p.get("sma_days", 200))).mean()).to_numpy()[:, None]
        base = base & pd.DataFrame(np.repeat(mk, c.shape[1], axis=1), index=c.index, columns=c.columns)
    return c, base


class DeepPullbackStrategy(Strategy):
    name = "deep_pullback"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        px = bundle.prices
        c, base = _base(bundle, p)
        a = atr(px.high, px.low, c, 14)
        n = int(p.get("lookback_days", 5))
        drop = (c.rolling(n, min_periods=n).max() - c) / a
        entry = base & (drop > float(p.get("drop_atr", 3.0))) & _vix_mask(bundle, c.index, c.columns, p.get("vix_min", 18))
        score = total_return(c, int(p.get("rank_mom_days", 126)), 0)
        ex = None
        if p.get("exit_sma_days"):
            ex = self._bool(c > sma(c, int(p["exit_sma_days"])))
        return StrategyOutput(self.name, score=score, entry=self._bool(entry), exit=ex)


class VolatileOversoldStrategy(Strategy):
    name = "volatile_oversold"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        px = bundle.prices
        c, base = _base(bundle, p)
        atrp = atr(px.high, px.low, c, 14) / c
        r = rsi(c, int(p.get("rsi_days", 2)))
        entry = base & (r < float(p.get("rsi_below", 10))) & (atrp > float(p.get("min_atr_pct", 0.03)))
        entry = entry & _vix_mask(bundle, c.index, c.columns, p.get("vix_min"))
        ex = self._bool(c > sma(c, int(p.get("exit_sma_days", 5))))
        score = total_return(c, int(p.get("rank_mom_days", 126)), 0)  # strongest names first (researched)
        return StrategyOutput(self.name, score=score, entry=self._bool(entry), exit=ex)


class RsiVixStrategy(Strategy):
    name = "rsi_vix"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        c, base = _base(bundle, p)
        r = rsi(c, int(p.get("rsi_days", 2)))
        entry = base & (r < float(p.get("rsi_below", 5))) & _vix_mask(bundle, c.index, c.columns, p.get("vix_min", 18))
        ex = self._bool(c > sma(c, int(p.get("exit_sma_days", 5))))
        score = total_return(c, int(p.get("rank_mom_days", 126)), 0)
        return StrategyOutput(self.name, score=score, entry=self._bool(entry), exit=ex)
