"""Cross-sectional 12-1 momentum (Jegadeesh & Titman 1993).

Each day, symbols are ranked by their 12-month return skipping the last month,
separately within stocks and within ETFs. The top quantile (default decile)
fires. Ranking at row t uses only row t.
"""
from __future__ import annotations

import pandas as pd

from ..data import MarketBundle
from ..indicators import total_return
from .base import Strategy, StrategyOutput


class MomentumStrategy(Strategy):
    name = "momentum"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        close = bundle.prices.close
        ret = total_return(close, int(p.get("lookback_days", 252)), int(p.get("skip_days", 21)))
        q = float(p.get("top_quantile", 0.10))
        min_n = int(p.get("min_group_size", 5))
        entry = pd.DataFrame(False, index=close.index, columns=close.columns)
        score = pd.DataFrame(float("nan"), index=close.index, columns=close.columns)
        for is_etf in (False, True):
            cols = [s for s in close.columns if bool(bundle.is_etf.get(s, False)) == is_etf]
            if not cols:
                continue
            sub = ret[cols]
            n_valid = sub.notna().sum(axis=1)
            rank = sub.rank(axis=1, pct=True, ascending=True)
            # top quantile; with small groups at least the single best name
            thresh = (1.0 - q)
            fires = (rank > thresh) | (sub.rank(axis=1, ascending=False) <= 1)
            fires = fires & (n_valid >= min_n).to_numpy()[:, None] & (sub > 0)
            entry[cols] = fires.fillna(False)
            score[cols] = rank
        return StrategyOutput(self.name, score=score, entry=self._bool(entry))
