"""Clean stubs for modules that need paid data (documented, always unavailable).

* PEADStrategy - post-earnings announcement drift (Bernard & Thomas 1989): needs a
  point-in-time earnings-surprise history (actual vs consensus EPS with announcement
  timestamps). Free SEC data has actual EPS but no consensus.
* AnalystRevisionStrategy - estimate revision momentum: needs point-in-time analyst
  estimates (e.g. I/B/E/S, Zacks, FactSet).

To implement: provide a long CSV (symbol, known_at, value) and compute a
cross-sectional rank exactly like quality_value.point_in_time() does, counting a
value only from `known_at`.
"""
from __future__ import annotations

from ..data import MarketBundle
from .base import Strategy, StrategyOutput


class PEADStrategy(Strategy):
    name = "pead"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        return self.unavailable(bundle, "stub: PEAD needs paid earnings-surprise data")


class AnalystRevisionStrategy(Strategy):
    name = "analyst_revisions"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        return self.unavailable(bundle, "stub: analyst revisions need paid estimate data")
