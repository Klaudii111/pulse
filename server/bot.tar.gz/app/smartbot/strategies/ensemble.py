"""Ensemble per horizon track: BUY only when >= N available strategies agree."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from ..data import MarketBundle
from . import build_strategy
from .base import StrategyOutput

log = logging.getLogger(__name__)


@dataclass
class TrackSignals:
    """Precomputed (causal) signal matrices for one track; arrays are (T, N)."""

    track: str
    dates: pd.DatetimeIndex
    symbols: list[str]
    entry: np.ndarray            # bool: ensemble BUY condition
    agree: np.ndarray            # int: number of available strategies firing
    rank_score: np.ndarray       # float: mean cross-sectional pct rank of available scores
    strat_entry: dict[str, np.ndarray]
    strat_exit: dict[str, np.ndarray]
    available: list[str]
    required: int
    raw_count: np.ndarray        # (T,) number of ensemble candidates per day
    notes: dict[str, str] = field(default_factory=dict)
    exp_r: np.ndarray | None = None          # (T, N) expected R of today's candidates (causal estimate)
    strat_exp_r: dict[str, np.ndarray] = field(default_factory=dict)  # (T,) per strategy


def required_agreement(min_agree: int, n_available: int, allow_fewer: bool) -> int | None:
    """Number of agreeing strategies needed for BUY, or None when signals are impossible."""
    if n_available <= 0:
        return None
    if n_available < min_agree:
        return n_available if allow_fewer else None
    return max(1, min_agree)


def combine(outputs: list[StrategyOutput], min_agree: int, allow_fewer: bool, tradable: np.ndarray,
            track: str, dates: pd.DatetimeIndex, symbols: list[str]) -> TrackSignals:
    avail = [o for o in outputs if o.available]
    T, N = len(dates), len(symbols)
    agree = np.zeros((T, N), dtype=np.int16)
    ranks = []
    for o in avail:
        agree += o.entry.reindex(index=dates, columns=symbols).fillna(False).to_numpy(dtype=bool)
        ranks.append(o.score.reindex(index=dates, columns=symbols).rank(axis=1, pct=True).to_numpy())
    req = required_agreement(min_agree, len(avail), allow_fewer)
    if req is None:
        entry = np.zeros((T, N), dtype=bool)
    else:
        entry = (agree >= req) & tradable[None, :]
    if ranks:
        with np.errstate(all="ignore"):
            stack = np.stack(ranks)
            cnt = np.isfinite(stack).sum(axis=0)
            rank_score = np.where(cnt > 0, np.nansum(stack, axis=0) / np.maximum(cnt, 1), 0.0)
    else:
        rank_score = np.zeros((T, N))
    notes = {o.name: o.note for o in outputs if not o.available}
    if req is None:
        notes["_ensemble"] = f"only {len(avail)} strategies available < min_agree {min_agree}: no BUY signals"
    return TrackSignals(
        track=track, dates=dates, symbols=symbols, entry=entry, agree=agree.astype(int),
        rank_score=rank_score,
        strat_entry={o.name: o.entry.reindex(index=dates, columns=symbols).fillna(False).to_numpy(dtype=bool) for o in avail},
        strat_exit={o.name: o.exit.reindex(index=dates, columns=symbols).fillna(False).to_numpy(dtype=bool)
                    for o in avail if o.exit is not None},
        available=[o.name for o in avail], required=req or 0, raw_count=entry.sum(axis=1), notes=notes,
    )


def expected_r_series(entry: np.ndarray, open_: np.ndarray, close: np.ndarray, atr: np.ndarray,
                      stop_mult: float, horizon: int, window: int = 252, min_obs: int = 20,
                      prior: float = 0.0) -> np.ndarray:
    """Causal estimate of a strategy's expected R per signal.

    For each past signal at day k (entry next open k+1, time exit at close k+H) the
    outcome in R units is (close[k+H] / open[k+1] - 1) / (stop_mult * ATR_k / close_k).
    That outcome becomes known at the close of k+H, so it is added to the estimate only
    from day k+H on. Returns the trailing-`window` mean (prior when < min_obs signals).
    Stops/targets are ignored (time-exit proxy) - it is a ranking aid, not a forecast.
    """
    T, N = entry.shape
    H = max(1, int(horizon))
    out = np.full(T, prior)
    if T <= H + 1:
        return out
    with np.errstate(all="ignore"):
        dist = stop_mult * atr / close
        fwd = np.full((T, N), np.nan)
        fwd[:T - H] = close[H:] / open_[1:T - H + 1] - 1.0
        rr = fwd / dist
    ok = entry & np.isfinite(rr)
    s_k = np.where(ok, rr, 0.0).sum(axis=1)
    n_k = ok.sum(axis=1).astype(float)
    # shift so that the outcome of day k is available at k + H
    s_av = np.concatenate([np.zeros(H), s_k[:T - H]])
    n_av = np.concatenate([np.zeros(H), n_k[:T - H]])
    cs, cn = np.cumsum(s_av), np.cumsum(n_av)
    lo = np.arange(T) - window
    s_w = cs - np.where(lo >= 0, cs[np.clip(lo, 0, None)], 0.0)
    n_w = cn - np.where(lo >= 0, cn[np.clip(lo, 0, None)], 0.0)
    est = np.where(n_w >= min_obs, s_w / np.maximum(n_w, 1.0), prior)
    return np.clip(est, -3.0, 3.0)


def attach_expected_r(ts: TrackSignals, bundle: MarketBundle, atr: np.ndarray, stop_mult: float, horizon: int) -> None:
    px = bundle.prices
    o = px.open.to_numpy(dtype=float)
    c = px.close.to_numpy(dtype=float)
    exp = np.full(ts.entry.shape, np.nan)
    for name, ent in ts.strat_entry.items():
        e = expected_r_series(ent, o, c, atr, stop_mult, horizon)
        ts.strat_exp_r[name] = e
        cand = ent & ts.entry
        exp = np.where(cand, np.fmax(exp, e[:, None]), exp)
    ts.exp_r = exp


def build_track_signals(bundle: MarketBundle, cfg: dict[str, Any], track: str,
                        cache: dict[str, StrategyOutput] | None = None,
                        track_overrides: dict[str, Any] | None = None) -> TrackSignals:
    tcfg = dict(cfg["tracks"][track])
    if track_overrides:
        tcfg.update(track_overrides)
    outs: list[StrategyOutput] = []
    for name in tcfg["strategies"]:
        if not cfg["strategies"].get(name, {}).get("enabled", True):
            continue
        if cache is not None and name in cache:
            outs.append(cache[name])
            continue
        o = build_strategy(name, cfg).compute(bundle)
        if cache is not None:
            cache[name] = o
        outs.append(o)
    from ..data import index_cfd_underlyings

    # cash proxies never get BUY signals; with index CFDs enabled the signal goes to the CFD symbol
    no_sig = set(cfg["universe"].get("no_signal_symbols", [])) | index_cfd_underlyings(cfg)
    syms = bundle.prices.symbols
    tradable = np.array([s not in no_sig for s in syms])
    ts = combine(outs, int(tcfg.get("min_agree", 2)), bool(tcfg.get("allow_fewer_available", False)),
                 tradable, track, bundle.prices.dates, syms)
    from ..indicators import atr as _atr  # local import avoids a cycle

    atr = _atr(bundle.prices.high, bundle.prices.low, bundle.prices.close,
               int(cfg["risk"]["stops"].get("atr_days", 14))).to_numpy(dtype=float)
    attach_expected_r(ts, bundle, atr, float(tcfg.get("stop_atr_mult", 2.0)), int(tcfg.get("horizon_days", 5)))
    for k, v in ts.notes.items():
        log.info("[%s] %s: %s", track, k, v)
    return ts
