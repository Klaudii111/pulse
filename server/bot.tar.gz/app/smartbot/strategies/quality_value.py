"""Quality/value (v2 placeholder, DISABLED by default).

Uses SEC XBRL companyfacts (https://data.sec.gov/api/xbrl/companyfacts/CIK##########.json),
which carries a `filed` date for every value, so the data can be used
point-in-time. `sec.fetch_fundamentals()` writes a long CSV:

    symbol, filed, gross_profit, assets, net_income, shares_outstanding

Score = average of cross-sectional percentile ranks of
  * gross profitability  GP / Assets   (Novy-Marx 2013)
  * earnings yield        NI / (shares * close_t)
Fires for the top `top_quantile` of stocks. A value counts only from
`filed` + effective_lag_days trading days.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..data import MarketBundle
from .base import Strategy, StrategyOutput


def point_in_time(fund: pd.DataFrame, dates: pd.DatetimeIndex, symbols: list[str], column: str,
                  lag_days: int = 1) -> pd.DataFrame:
    """Forward-fill each symbol's latest value from its effective date (filed + lag)."""
    out = pd.DataFrame(np.nan, index=dates, columns=symbols)
    if fund is None or fund.empty or column not in fund.columns:
        return out
    f = fund.dropna(subset=[column]).copy()
    f["filed"] = pd.to_datetime(f["filed"])
    for sym, g in f.groupby("symbol"):
        if sym not in out.columns:
            continue
        g = g.sort_values("filed")
        idx = dates.searchsorted(g["filed"].to_numpy(), side="right") + max(0, lag_days - 1)
        s = pd.Series(np.nan, index=range(len(dates) + 1))
        for i, v in zip(idx, g[column].to_numpy()):
            if i < len(dates):
                s.iloc[i] = v
        out[sym] = s.iloc[:len(dates)].ffill().to_numpy()
    return out


class QualityValueStrategy(Strategy):
    name = "quality_value"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        fund = bundle.fundamentals
        if fund is None or fund.empty:
            return self.unavailable(bundle, "no fundamentals file")
        dates = bundle.prices.dates
        stocks = [s for s in bundle.prices.symbols if not bundle.is_etf.get(s, False)]
        lag = int(p.get("effective_lag_days", 1))
        gp = point_in_time(fund, dates, stocks, "gross_profit", lag)
        assets = point_in_time(fund, dates, stocks, "assets", lag)
        ni = point_in_time(fund, dates, stocks, "net_income", lag)
        sh = point_in_time(fund, dates, stocks, "shares_outstanding", lag)
        close = bundle.prices.close[stocks]
        gpa = gp / assets.where(assets > 0)
        ey = ni / (sh * close).where(sh > 0)
        score_s = pd.concat([gpa.rank(axis=1, pct=True), ey.rank(axis=1, pct=True)]).groupby(level=0).mean()
        score_s = score_s.reindex(dates)
        n_valid = score_s.notna().sum(axis=1)
        q = float(p.get("top_quantile", 0.30))
        fires = (score_s.rank(axis=1, pct=True) > 1 - q) & (n_valid >= int(p.get("min_group_size", 20))).to_numpy()[:, None]
        score = pd.DataFrame(np.nan, index=dates, columns=bundle.prices.symbols)
        entry = pd.DataFrame(False, index=dates, columns=bundle.prices.symbols)
        score[stocks] = score_s
        entry[stocks] = fires.fillna(False)
        if not entry.to_numpy().any():
            return self.unavailable(bundle, "fundamentals do not cover enough of the universe")
        return StrategyOutput(self.name, score=score, entry=self._bool(entry))
