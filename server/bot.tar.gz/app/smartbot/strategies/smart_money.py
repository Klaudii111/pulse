"""Smart money: SEC 13F holdings of a configurable list of superinvestors.

Point-in-time rule (CRITICAL, no look-ahead): a 13F is filed up to 45 days
after quarter end. A holding counts only from its FILING date (+ lag), never
from the report/period date. A fund's last filing expires after
`max_filing_age_days` (fund stopped filing).

holdings DataFrame columns (see sec.py): fund_cik, filing_date, report_date,
ticker, shares [, form, put_call].

score = number of funds holding + increase_bonus * number of funds that opened
or increased the position in their latest filing. Fires when holders >= min_funds.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..data import MarketBundle
from .base import Strategy, StrategyOutput


def holdings_matrices(holdings: pd.DataFrame, dates: pd.DatetimeIndex, symbols: list[str],
                      effective_lag_days: int = 1, max_filing_age_days: int = 200,
                      exclude_options: bool = True) -> tuple[np.ndarray, np.ndarray]:
    """Return (holders_count, increasers_count) arrays of shape (T, N)."""
    T, N = len(dates), len(symbols)
    count = np.zeros((T, N), dtype=float)
    inc = np.zeros((T, N), dtype=float)
    if holdings is None or holdings.empty:
        return count, inc
    h = holdings.copy()
    h["filing_date"] = pd.to_datetime(h["filing_date"])
    if "form" in h.columns:
        h = h[h["form"].astype(str).str.upper().isin(["13F-HR", "13F"])]  # amendments ignored (documented)
    if exclude_options and "put_call" in h.columns:
        h = h[h["put_call"].isna() | (h["put_call"].astype(str).str.strip() == "")]
    h = h[h["ticker"].notna()]
    col = {s: j for j, s in enumerate(symbols)}
    lag = max(0, int(effective_lag_days))
    for _, g in h.groupby(h["fund_cik"].astype(str)):
        filings = sorted(g.groupby("filing_date"), key=lambda x: x[0])
        prev: dict[str, float] = {}
        eff_idx = []
        for fdate, _ in filings:
            side = "right" if lag >= 1 else "left"
            eff_idx.append(int(dates.searchsorted(pd.Timestamp(fdate), side=side)) + max(0, lag - 1))
        for k, (fdate, fg) in enumerate(filings):
            start = eff_idx[k]
            expiry = int(dates.searchsorted(pd.Timestamp(fdate) + pd.Timedelta(days=max_filing_age_days), side="right"))
            end = min(eff_idx[k + 1] if k + 1 < len(filings) else T, expiry, T)
            shares = fg.groupby("ticker")["shares"].sum()
            if start < end:
                for tic, sh in shares.items():
                    j = col.get(str(tic))
                    if j is None or sh <= 0:
                        continue
                    count[start:end, j] += 1.0
                    if sh > prev.get(str(tic), 0.0):
                        inc[start:end, j] += 1.0
            prev = {str(t): float(v) for t, v in shares.items()}
    return count, inc


class SmartMoneyStrategy(Strategy):
    name = "smart_money"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        h = bundle.holdings
        if h is None or h.empty:
            return self.unavailable(bundle, "no 13F holdings file (run update-data)")
        dates, syms = bundle.prices.dates, bundle.prices.symbols
        count, inc = holdings_matrices(h, dates, syms, int(p.get("effective_lag_days", 1)),
                                       int(p.get("max_filing_age_days", 200)), bool(p.get("exclude_options", True)))
        if count.sum() == 0:
            return self.unavailable(bundle, "13F holdings do not map to the universe (CUSIP mapping?)")
        score = pd.DataFrame(count + float(p.get("increase_bonus", 0.5)) * inc, index=dates, columns=syms)
        entry = pd.DataFrame(count >= int(p.get("min_funds", 1)), index=dates, columns=syms)
        return StrategyOutput(self.name, score=score.where(score > 0), entry=entry)
