"""Additional evidence-based modules (free data).

* SectorRotationStrategy  - 11 SPDR sector ETFs, top 3 by blended 3/6/12m momentum, above 200d SMA.
* InsiderClusterStrategy  - SEC Form 4 cluster buying: >= 3 distinct insiders with open-market
                            purchases (code P) within 30 days, counted from the FILING date.
* CalendarEffectsStrategy - turn-of-month and pre-holiday long SPY/QQQ (1-day holding).
* WeeklyReversalStrategy  - Lehmann (1990) 1-week reversal on large caps, risk-on only.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .. import tradingcal
from ..data import MarketBundle
from ..indicators import dollar_volume, sma, total_return
from .base import Strategy, StrategyOutput


def _col_mask(close: pd.DataFrame, allowed: list[str]) -> pd.DataFrame:
    m = close.columns.isin(allowed)[None, :]
    return pd.DataFrame(np.repeat(m, len(close), axis=0), index=close.index, columns=close.columns)


class SectorRotationStrategy(Strategy):
    name = "sector_rotation"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        close = bundle.prices.close
        allowed = [s for s in p.get("symbols", []) if s in close.columns]
        if len(allowed) < 3:
            return self.unavailable(bundle, "sector ETFs missing from price data")
        sub = close[allowed]
        moms = [total_return(sub, int(lb), 0) for lb in p.get("lookbacks", [63, 126, 252])]
        blend = sum(moms) / len(moms)
        rank = blend.rank(axis=1, ascending=False)
        above = sub > sma(sub, int(p.get("sma_days", 200)))
        top = (rank <= int(p.get("top_n", 3))) & above & (blend > 0)
        score = pd.DataFrame(np.nan, index=close.index, columns=close.columns)
        entry = pd.DataFrame(False, index=close.index, columns=close.columns)
        score[allowed] = blend
        entry[allowed] = top.fillna(False)
        exit_ = pd.DataFrame(False, index=close.index, columns=close.columns)
        exit_[allowed] = ((rank > int(p.get("top_n", 3)) + 2) | ~above).fillna(False)
        return StrategyOutput(self.name, score=score, entry=self._bool(entry), exit=self._bool(exit_))


def insider_cluster_counts(trades: pd.DataFrame, dates: pd.DatetimeIndex, symbols: list[str],
                           window_days: int = 30, lag_days: int = 1, min_value: float = 0.0) -> np.ndarray:
    """(T, N) number of distinct insiders with open-market purchases whose Form 4 became
    known (filing date + lag sessions) within the last `window_days` calendar days."""
    T, N = len(dates), len(symbols)
    out = np.zeros((T, N))
    if trades is None or trades.empty:
        return out
    t = trades.copy()
    t = t[t["code"].astype(str).str.upper() == "P"]
    if "acq_disp" in t.columns:
        t = t[t["acq_disp"].astype(str).str.upper().isin(["A", "NAN", "NONE", ""])]
    if min_value > 0 and {"shares", "price"} <= set(t.columns):
        t = t[(t["shares"].astype(float) * t["price"].astype(float)) >= min_value]
    t["filing_date"] = pd.to_datetime(t["filing_date"])
    col = {s: j for j, s in enumerate(symbols)}
    side = "right" if lag_days >= 1 else "left"
    for sym, g in t.groupby("symbol"):
        j = col.get(str(sym))
        if j is None:
            continue
        fd = pd.DatetimeIndex(g["filing_date"])
        start = dates.searchsorted(fd, side=side) + max(0, lag_days - 1)
        # active while date_i - window <= filing_date  <=>  date_i <= filing_date + window
        end = dates.searchsorted(fd + pd.Timedelta(days=window_days), side="right")
        for owner, idx in g.groupby(g["owner_cik"].astype(str)).indices.items():
            active = np.zeros(T, dtype=bool)
            for k in idx:
                if start[k] < end[k]:
                    active[start[k]:end[k]] = True
            out[:, j] += active
    return out


class InsiderClusterStrategy(Strategy):
    name = "insider_cluster"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        tr = bundle.insider
        if tr is None or tr.empty:
            return self.unavailable(bundle, "no Form 4 insider trades file (run update-data --insiders)")
        dates, syms = bundle.prices.dates, bundle.prices.symbols
        cnt = insider_cluster_counts(tr, dates, syms, int(p.get("window_days", 30)), int(p.get("effective_lag_days", 1)),
                                     float(p.get("min_value_usd", 0)))
        if cnt.sum() == 0:
            return self.unavailable(bundle, "insider trades do not map to the universe")
        score = pd.DataFrame(cnt, index=dates, columns=syms)
        entry = score >= int(p.get("min_insiders", 3))
        return StrategyOutput(self.name, score=score.where(score > 0), entry=self._bool(entry))


def calendar_flags(dates: pd.DatetimeIndex, tom_last: int = 1, tom_first: int = 3,
                   pre_holiday: bool = True) -> np.ndarray:
    """bool (T,): True at close t when the NEXT NYSE session is a turn-of-month or pre-holiday day.

    Uses only the exchange calendar (known in advance), never prices.
    """
    if len(dates) == 0:
        return np.zeros(0, dtype=bool)
    sess = tradingcal.trading_days(dates[0] - pd.Timedelta(days=40), dates[-1] + pd.Timedelta(days=60))
    nxt_pos = sess.searchsorted(dates, side="right")
    flags = np.zeros(len(dates), dtype=bool)
    months = sess.to_period("M")
    for k, pos in enumerate(nxt_pos):
        if pos >= len(sess) - 5:
            continue
        d1 = sess[pos]
        m1 = months[pos]
        # position within month
        first_idx = pos
        while first_idx > 0 and months[first_idx - 1] == m1:
            first_idx -= 1
        last_idx = pos
        while last_idx + 1 < len(sess) and months[last_idx + 1] == m1:
            last_idx += 1
        is_tom = (pos - first_idx) < tom_first or (last_idx - pos) < tom_last
        is_pre = False
        if pre_holiday:
            d2 = sess[pos + 1]
            gap = pd.bdate_range(d1 + pd.Timedelta(days=1), d2 - pd.Timedelta(days=1))
            is_pre = len(gap) > 0  # a weekday holiday follows d1
        flags[k] = is_tom or is_pre
    return flags


class CalendarEffectsStrategy(Strategy):
    name = "calendar_effects"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        close = bundle.prices.close
        allowed = [s for s in p.get("symbols", ["SPY", "QQQ"]) if s in close.columns]
        if not allowed:
            return self.unavailable(bundle, "SPY/QQQ missing")
        f = calendar_flags(close.index, int(p.get("tom_last_days", 1)), int(p.get("tom_first_days", 3)),
                           bool(p.get("pre_holiday", True)))
        mask = _col_mask(close, allowed)
        entry = mask & pd.DataFrame(np.repeat(f[:, None], close.shape[1], axis=1), index=close.index,
                                    columns=close.columns) & close.notna()
        score = mask.astype(float).where(mask)
        return StrategyOutput(self.name, score=score, entry=self._bool(entry))


class WeeklyReversalStrategy(Strategy):
    name = "weekly_reversal"

    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        p = self.params
        px = bundle.prices
        close = px.close
        bench = "SPY" if "SPY" in close.columns else close.columns[0]
        risk_on = (close[bench] > sma(close[[bench]], int(p.get("sma_days", 200)))[bench]).to_numpy()
        stocks = [s for s in close.columns if not bundle.is_etf.get(s, False)]
        big = (dollar_volume(close[stocks], px.volume[stocks], 20) >= float(p.get("min_dollar_volume", 3e8)))
        r5 = total_return(close[stocks], int(p.get("lookback_days", 5)), 0).where(big)
        rank = r5.rank(axis=1, pct=True)
        fires = (rank <= float(p.get("bottom_quantile", 0.10))) & (r5 < 0) & (close[stocks] > 5.0)
        fires = fires & risk_on[:, None] & (big.sum(axis=1) >= 10).to_numpy()[:, None]
        score = pd.DataFrame(np.nan, index=close.index, columns=close.columns)
        entry = pd.DataFrame(False, index=close.index, columns=close.columns)
        score[stocks] = 1.0 - rank
        entry[stocks] = fires.fillna(False)
        return StrategyOutput(self.name, score=score, entry=self._bool(entry))
