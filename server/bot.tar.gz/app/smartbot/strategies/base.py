"""Strategy interface.

A strategy turns a `MarketBundle` into three dates x symbols matrices:
  * score : float, higher = stronger (used for ranking)
  * entry : bool, the strategy "fires" (BUY condition) at the close of t
  * exit  : bool or None, strategy-specific exit condition at the close of t
Row t may only use information available at the close of day t.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

import pandas as pd

from ..data import MarketBundle


@dataclass
class StrategyOutput:
    name: str
    score: pd.DataFrame
    entry: pd.DataFrame
    exit: pd.DataFrame | None = None
    available: bool = True
    note: str = ""


class Strategy(ABC):
    name: str = "base"

    def __init__(self, params: dict[str, Any] | None = None, name: str | None = None) -> None:
        self.params = dict(params or {})
        if name:
            self.name = name  # the same class can be configured twice under different names

    @abstractmethod
    def compute(self, bundle: MarketBundle) -> StrategyOutput:
        """Compute score/entry/exit matrices for the whole history (causally)."""

    @staticmethod
    def _bool(df: pd.DataFrame) -> pd.DataFrame:
        return df.fillna(False).astype(bool)

    def unavailable(self, bundle: MarketBundle, note: str) -> StrategyOutput:
        idx, cols = bundle.prices.dates, bundle.prices.symbols
        empty_f = pd.DataFrame(float("nan"), index=idx, columns=cols)
        empty_b = pd.DataFrame(False, index=idx, columns=cols)
        return StrategyOutput(self.name, empty_f, empty_b, None, available=False, note=note)
