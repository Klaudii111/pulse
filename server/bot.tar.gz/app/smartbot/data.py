"""Price data: provider interface (Alpaca, yfinance, Stooq), local cache, universe.

All prices are split- and dividend-adjusted daily bars. Data is stored per
symbol in `data/cache/prices/<SYMBOL>.(parquet|csv)` and assembled into a
`PriceData` panel (wide DataFrames: dates x symbols) aligned to the benchmark's
trading calendar.
"""
from __future__ import annotations

import io
import logging
import time as _time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Protocol

import numpy as np
import pandas as pd

from .config import Secrets, resolve_path

log = logging.getLogger(__name__)

FIELDS = ("open", "high", "low", "close", "volume")


# ---------------------------------------------------------------------------
# Containers
# ---------------------------------------------------------------------------
@dataclass
class PriceData:
    """Wide OHLCV panel. Every frame has the same DatetimeIndex and columns."""

    open: pd.DataFrame
    high: pd.DataFrame
    low: pd.DataFrame
    close: pd.DataFrame
    volume: pd.DataFrame

    @property
    def dates(self) -> pd.DatetimeIndex:
        return pd.DatetimeIndex(self.close.index)

    @property
    def symbols(self) -> list[str]:
        return list(self.close.columns)

    def frames(self) -> dict[str, pd.DataFrame]:
        return {f: getattr(self, f) for f in FIELDS}

    def truncate(self, end: pd.Timestamp | str) -> "PriceData":
        """Data available up to and including `end` (used by no-look-ahead tests)."""
        end = pd.Timestamp(end)
        return PriceData(**{f: df.loc[:end].copy() for f, df in self.frames().items()})

    def select(self, symbols: Iterable[str]) -> "PriceData":
        cols = [s for s in symbols if s in self.close.columns]
        return PriceData(**{f: df[cols].copy() for f, df in self.frames().items()})

    @classmethod
    def from_symbol_frames(cls, frames: dict[str, pd.DataFrame], calendar: pd.DatetimeIndex | None = None) -> "PriceData":
        """Build a panel from {symbol: DataFrame[open,high,low,close,volume]}."""
        if not frames:
            raise ValueError("no price frames")
        if calendar is None:
            calendar = pd.DatetimeIndex(sorted(set().union(*[set(df.index) for df in frames.values()])))
        out: dict[str, pd.DataFrame] = {}
        for f in FIELDS:
            out[f] = pd.DataFrame({s: df[f].reindex(calendar) for s, df in frames.items()}, index=calendar).astype(float)
        return cls(**out)


@dataclass
class MarketBundle:
    """Everything the engine needs about the market."""

    prices: PriceData
    sectors: dict[str, str]
    asset_classes: dict[str, str]          # equity | index_major | index_non_major | gold | commodity
    is_etf: dict[str, bool]
    names: dict[str, str] = field(default_factory=dict)
    holdings: pd.DataFrame | None = None   # 13F holdings (see sec.py)
    fundamentals: pd.DataFrame | None = None
    earnings: pd.DataFrame | None = None   # columns symbol, date
    insider: pd.DataFrame | None = None    # Form 4: symbol, filing_date, owner_cik, code, shares, price
    vix: pd.DataFrame | None = None        # index date, columns vix, vix3m
    synthetic: bool = False

    def truncate(self, end: pd.Timestamp | str) -> "MarketBundle":
        return MarketBundle(
            prices=self.prices.truncate(end), sectors=self.sectors, asset_classes=self.asset_classes,
            is_etf=self.is_etf, names=self.names, holdings=self.holdings, fundamentals=self.fundamentals,
            earnings=self.earnings, insider=self.insider,
            vix=self.vix.loc[:pd.Timestamp(end)] if self.vix is not None else None, synthetic=self.synthetic,
        )


@dataclass
class Universe:
    stocks: list[str]
    etfs: list[str]
    sectors: dict[str, str]
    asset_classes: dict[str, str]
    names: dict[str, str]
    ciks: dict[str, str] = field(default_factory=dict)

    @property
    def symbols(self) -> list[str]:
        return list(dict.fromkeys(self.etfs + self.stocks))

    @property
    def is_etf(self) -> dict[str, bool]:
        return {s: s in set(self.etfs) for s in self.symbols}


# ---------------------------------------------------------------------------
# Universe
# ---------------------------------------------------------------------------
def load_universe(cfg: dict[str, Any], refresh: bool = False, http_get: Any = None) -> Universe:
    """S&P 500 constituents CSV (datasets/s-and-p-500-companies) + core ETFs.

    NOTE: current constituents only -> survivorship bias in long backtests.
    """
    ucfg = cfg["universe"]
    etf_cfg: dict[str, dict[str, Any]] = ucfg.get("etfs", {})
    etfs = list(etf_cfg)
    sectors = {s: str(v.get("sector", "ETF")) for s, v in etf_cfg.items()}
    classes = {s: str(v.get("class", "equity")) for s, v in etf_cfg.items()}
    names = {s: str(v.get("name", s)) for s, v in etf_cfg.items()}
    stocks: list[str] = []
    ciks: dict[str, str] = {}
    if ucfg.get("include_sp500", True):
        cache = resolve_path(cfg, ucfg["sp500_cache"])
        if refresh or not cache.exists():
            get = http_get or _requests_get
            text = get(ucfg["sp500_csv_url"]).text
            cache.parent.mkdir(parents=True, exist_ok=True)
            cache.write_text(text, encoding="utf-8")
        if cache.exists():
            df = pd.read_csv(cache, dtype=str)
            for _, row in df.iterrows():
                sym = str(row.get("Symbol", "")).strip().upper()
                if not sym or sym in etf_cfg:
                    continue
                stocks.append(sym)
                sectors[sym] = str(row.get("GICS Sector", "Unknown") or "Unknown")
                classes[sym] = "equity"
                names[sym] = str(row.get("Security", sym))
                cik = row.get("CIK")
                if isinstance(cik, str) and cik.strip():
                    ciks[sym] = cik.strip().zfill(10)
        else:
            log.warning("S&P 500 constituents not available; universe = ETFs + extra symbols only")
    for sym in ucfg.get("extra_symbols", []) or []:
        sym = sym.upper()
        if sym not in stocks and sym not in etf_cfg:
            stocks.append(sym)
            sectors.setdefault(sym, "Unknown")
            classes.setdefault(sym, "equity")
            names.setdefault(sym, sym)
    return Universe(stocks=stocks, etfs=etfs, sectors=sectors, asset_classes=classes, names=names, ciks=ciks)


def _requests_get(url: str, headers: dict[str, str] | None = None, timeout: float = 30.0) -> Any:
    import requests

    r = requests.get(url, headers=headers or {"User-Agent": "smartbot/1.0"}, timeout=timeout)
    r.raise_for_status()
    return r


# ---------------------------------------------------------------------------
# Providers
# ---------------------------------------------------------------------------
class PriceProvider(Protocol):
    name: str

    def fetch(self, symbols: list[str], start: str, end: str | None) -> dict[str, pd.DataFrame]:
        """Return {symbol: DataFrame[open,high,low,close,volume]} with a tz-naive DatetimeIndex."""
        ...


def _normalize_frame(df: pd.DataFrame) -> pd.DataFrame:
    df = df.rename(columns={c: str(c).lower() for c in df.columns})
    df = df[[c for c in FIELDS if c in df.columns]].copy()
    idx = pd.DatetimeIndex(pd.to_datetime(df.index))
    if idx.tz is not None:
        idx = idx.tz_convert("America/New_York").tz_localize(None)
    df.index = idx.normalize()
    df = df[~df.index.duplicated(keep="last")].sort_index()
    df = df.astype(float)
    df = df[(df["close"] > 0) & np.isfinite(df["close"])]
    return df


class AlpacaProvider:
    """Alpaca market data v2 daily bars, adjustment=all (splits + dividends).

    Free accounts: history from 2016; SIP feed allowed for data older than 15 min.
    """

    name = "alpaca"

    def __init__(self, secrets: Secrets, feed: str = "sip", chunk: int = 100) -> None:
        if not (secrets.alpaca_key_id and secrets.alpaca_secret_key):
            raise RuntimeError("ALPACA_KEY_ID / ALPACA_SECRET_KEY not set")
        from alpaca.data.historical import StockHistoricalDataClient

        self._client = StockHistoricalDataClient(secrets.alpaca_key_id, secrets.alpaca_secret_key)
        self.feed = feed
        self.chunk = chunk

    def fetch(self, symbols: list[str], start: str, end: str | None) -> dict[str, pd.DataFrame]:
        from alpaca.data.enums import Adjustment, DataFeed
        from alpaca.data.requests import StockBarsRequest
        from alpaca.data.timeframe import TimeFrame

        out: dict[str, pd.DataFrame] = {}
        for i in range(0, len(symbols), self.chunk):
            batch = symbols[i:i + self.chunk]
            req = StockBarsRequest(
                symbol_or_symbols=batch, timeframe=TimeFrame.Day, start=pd.Timestamp(start).to_pydatetime(),
                end=pd.Timestamp(end).to_pydatetime() if end else None, adjustment=Adjustment.ALL,
                feed=DataFeed(self.feed),
            )
            bars = self._client.get_stock_bars(req).df
            if bars is None or bars.empty:
                continue
            for sym, g in bars.groupby(level=0):
                g = g.droplevel(0)
                out[str(sym)] = _normalize_frame(g)
        return out


class YFinanceProvider:
    """Yahoo Finance via yfinance (unofficial; auto_adjust=True)."""

    name = "yfinance"

    @staticmethod
    def to_yahoo(sym: str) -> str:
        return sym.replace(".", "-")

    def fetch(self, symbols: list[str], start: str, end: str | None) -> dict[str, pd.DataFrame]:
        import yfinance as yf

        out: dict[str, pd.DataFrame] = {}
        ymap = {self.to_yahoo(s): s for s in symbols}
        tickers = list(ymap)
        for i in range(0, len(tickers), 50):
            batch = tickers[i:i + 50]
            raw = yf.download(batch, start=start, end=end, auto_adjust=True, group_by="ticker",
                              progress=False, threads=True)
            if raw is None or raw.empty:
                continue
            for yt in batch:
                try:
                    df = raw[yt] if isinstance(raw.columns, pd.MultiIndex) else raw
                except KeyError:
                    continue
                df = df.dropna(how="all")
                if not df.empty:
                    out[ymap[yt]] = _normalize_frame(df)
        return out


class StooqProvider:
    """Stooq CSV (https://stooq.com/q/d/l/?s=aapl.us&i=d).

    [UNCERTAIN] Stooq adjusts for splits; dividend adjustment and current access
    rules (captcha / API key) must be verified on the real PC.
    """

    name = "stooq"

    def __init__(self, pause: float = 0.5) -> None:
        self.pause = pause

    def fetch(self, symbols: list[str], start: str, end: str | None) -> dict[str, pd.DataFrame]:
        out: dict[str, pd.DataFrame] = {}
        for s in symbols:
            url = f"https://stooq.com/q/d/l/?s={s.lower().replace('.', '-')}.us&i=d"
            try:
                txt = _requests_get(url).text
                if not txt.lower().startswith("date"):
                    continue
                df = pd.read_csv(io.StringIO(txt), parse_dates=["Date"], index_col="Date")
                df = _normalize_frame(df)
                df = df.loc[pd.Timestamp(start): pd.Timestamp(end) if end else None]
                if not df.empty:
                    out[s] = df
            except Exception as exc:  # noqa: BLE001 - provider errors must not abort the run
                log.warning("stooq %s failed: %s", s, exc)
            _time.sleep(self.pause)
        return out


def make_providers(cfg: dict[str, Any], secrets: Secrets) -> list[PriceProvider]:
    provs: list[PriceProvider] = []
    for name in cfg["data"].get("providers", []):
        try:
            if name == "alpaca":
                provs.append(AlpacaProvider(secrets, feed=cfg["data"].get("alpaca_feed", "sip")))
            elif name == "yfinance":
                import yfinance  # noqa: F401

                provs.append(YFinanceProvider())
            elif name == "stooq":
                provs.append(StooqProvider())
        except Exception as exc:  # noqa: BLE001
            log.warning("provider %s unavailable: %s", name, exc)
    return provs


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------
class PriceCache:
    def __init__(self, directory: Path, fmt: str = "auto") -> None:
        self.dir = Path(directory) / "prices"
        self.dir.mkdir(parents=True, exist_ok=True)
        if fmt == "auto":
            try:
                import pyarrow  # noqa: F401

                fmt = "parquet"
            except ImportError:
                fmt = "csv"
        self.fmt = fmt

    def _path(self, sym: str, fmt: str | None = None) -> Path:
        safe = sym.replace("/", "_").replace("\\", "_")
        return self.dir / f"{safe}.{fmt or self.fmt}"

    def load(self, sym: str) -> pd.DataFrame | None:
        for fmt in (self.fmt, "csv", "parquet"):
            p = self._path(sym, fmt)
            if p.exists():
                if fmt == "parquet":
                    df = pd.read_parquet(p)
                else:
                    df = pd.read_csv(p, index_col=0, parse_dates=True)
                df.index = pd.DatetimeIndex(df.index)
                return df
        return None

    def save(self, sym: str, df: pd.DataFrame) -> None:
        p = self._path(sym)
        if self.fmt == "parquet":
            df.to_parquet(p)
        else:
            df.to_csv(p)


def update_prices(cfg: dict[str, Any], secrets: Secrets, symbols: list[str], full: bool = False,
                  providers: list[PriceProvider] | None = None) -> dict[str, str]:
    """Download/refresh the local cache. Returns {symbol: provider or 'failed'}."""
    cache = PriceCache(resolve_path(cfg, cfg["data"]["cache_dir"]), cfg["data"].get("cache_format", "auto"))
    provs = providers if providers is not None else make_providers(cfg, secrets)
    if not provs:
        raise RuntimeError("no data provider available (check .env and installed packages)")
    start_all = cfg["data"].get("history_start", "2005-01-01")
    tol = float(cfg["data"].get("refetch_on_mismatch_pct", 0.002))
    existing = {s: (None if full else cache.load(s)) for s in symbols}
    status: dict[str, str] = {}
    # incremental groups: symbols with a cache start a few days before the last bar
    pending = list(symbols)
    for prov in provs:
        if not pending:
            break
        full_syms = [s for s in pending if existing.get(s) is None]
        inc_syms = [s for s in pending if existing.get(s) is not None]
        got: dict[str, pd.DataFrame] = {}
        try:
            if full_syms:
                got.update(prov.fetch(full_syms, start_all, None))
            if inc_syms:
                inc_start = min(existing[s].index[-1] for s in inc_syms) - pd.Timedelta(days=10)  # type: ignore[union-attr]
                got.update(prov.fetch(inc_syms, str(inc_start.date()), None))
        except Exception as exc:  # noqa: BLE001
            log.warning("provider %s failed: %s", prov.name, exc)
            continue
        refetch: list[str] = []
        for s, df in got.items():
            old = existing.get(s)
            if old is not None and not df.empty:
                overlap = old.index.intersection(df.index)
                if len(overlap):
                    diff = (df.loc[overlap, "close"] / old.loc[overlap, "close"] - 1).abs().max()
                    if diff > tol:  # history was re-adjusted (dividend/split) -> full refetch
                        refetch.append(s)
                        continue
                df = pd.concat([old[~old.index.isin(df.index)], df]).sort_index()
            cache.save(s, df)
            status[s] = prov.name
        if refetch:
            try:
                for s, df in prov.fetch(refetch, start_all, None).items():
                    cache.save(s, df)
                    status[s] = prov.name + ":full"
            except Exception as exc:  # noqa: BLE001
                log.warning("full refetch failed: %s", exc)
        pending = [s for s in pending if s not in status]
    for s in pending:
        status[s] = "failed"
    return status


def load_price_data(cfg: dict[str, Any], symbols: list[str], benchmark: str,
                    start: str | None = None, end: str | None = None) -> PriceData:
    """Assemble a panel from the cache aligned to the benchmark calendar."""
    cache = PriceCache(resolve_path(cfg, cfg["data"]["cache_dir"]), cfg["data"].get("cache_format", "auto"))
    frames: dict[str, pd.DataFrame] = {}
    for s in dict.fromkeys([benchmark] + list(symbols)):
        df = cache.load(s)
        if df is not None and not df.empty:
            frames[s] = df
    if benchmark not in frames:
        raise RuntimeError(f"benchmark {benchmark} not in cache - run `python -m smartbot update-data`")
    cal = frames[benchmark].index
    if start:
        cal = cal[cal >= pd.Timestamp(start)]
    if end:
        cal = cal[cal <= pd.Timestamp(end)]
    pdata = PriceData.from_symbol_frames(frames, calendar=pd.DatetimeIndex(cal))
    max_missing = float(cfg["data"].get("max_missing_frac_symbol", 0.10))
    keep = []
    for s in pdata.symbols:
        c = pdata.close[s]
        first = c.first_valid_index()
        if first is None:
            continue
        live = c.loc[first:c.last_valid_index()]
        if live.isna().mean() <= max_missing or s == benchmark:
            keep.append(s)
        else:
            log.warning("dropping %s: %.1f%% missing bars", s, 100 * live.isna().mean())
    return pdata.select(keep)


def apply_index_cfds(bundle: MarketBundle, cfg: dict[str, Any]) -> MarketBundle:
    """Add the explicit index-CFD instruments (e.g. US500, US100) as SEPARATE symbols.

    Prices are a proxy copied from the underlying ETF; asset class from config (index_major = ESMA 20:1).
    Signals are then issued on the CFD symbol and the underlying ETF is excluded from signals
    (see index_cfd_underlyings). Disabled by default: every ETF stays a share CFD (5:1).
    """
    ic = cfg.get("index_cfds", {}) or {}
    if not ic.get("enabled", False):
        return bundle
    px = bundle.prices
    frames = {f: df.copy() for f, df in px.frames().items()}
    sectors, classes, is_etf, names = dict(bundle.sectors), dict(bundle.asset_classes), dict(bundle.is_etf), dict(bundle.names)
    for alias, spec in (ic.get("instruments") or {}).items():
        und = spec["underlying"]
        if und not in px.symbols or alias in px.symbols:
            continue
        for f in frames:
            frames[f][alias] = frames[f][und]
        sectors[alias] = f"Index CFD {alias}"
        classes[alias] = str(spec.get("class", "index_major"))
        is_etf[alias] = True          # ranked with the ETF group
        names[alias] = str(spec.get("name", alias))
    return MarketBundle(prices=PriceData(**frames), sectors=sectors, asset_classes=classes, is_etf=is_etf, names=names,
                        holdings=bundle.holdings, fundamentals=bundle.fundamentals, earnings=bundle.earnings,
                        insider=bundle.insider, vix=bundle.vix, synthetic=bundle.synthetic)


def index_cfd_underlyings(cfg: dict[str, Any]) -> set[str]:
    ic = cfg.get("index_cfds", {}) or {}
    if not ic.get("enabled", False):
        return set()
    return {str(v["underlying"]) for v in (ic.get("instruments") or {}).values()}


def load_bundle(cfg: dict[str, Any], start: str | None = None, end: str | None = None,
                universe: Universe | None = None) -> MarketBundle:
    """Real-data bundle from the local cache (+13F holdings, fundamentals, earnings if present)."""
    uni = universe or load_universe(cfg)
    bench = cfg["universe"]["benchmark"]
    prices = load_price_data(cfg, uni.symbols, bench, start=start, end=end)
    holdings = _read_optional_csv(resolve_path(cfg, cfg["strategies"]["smart_money"]["holdings_file"]),
                                  ["filing_date", "report_date"])
    fundamentals = _read_optional_csv(resolve_path(cfg, cfg["strategies"]["quality_value"]["fundamentals_file"]),
                                      ["filed"])
    earnings = _read_optional_csv(resolve_path(cfg, cfg["risk"]["earnings"]["calendar_csv"]), ["date"])
    insider = _read_optional_csv(resolve_path(cfg, cfg["strategies"]["insider_cluster"]["trades_file"]),
                                 ["filing_date", "trade_date"])
    vix = None
    vpath = resolve_path(cfg, cfg["risk"]["regime"]["vix_term"]["file"])
    if vpath.exists():
        vix = pd.read_csv(vpath, index_col=0, parse_dates=True)
    return apply_index_cfds(MarketBundle(prices=prices, sectors=uni.sectors, asset_classes=uni.asset_classes, is_etf=uni.is_etf,
                        names=uni.names, holdings=holdings, fundamentals=fundamentals, earnings=earnings,
                        insider=insider, vix=vix), cfg)


def _read_optional_csv(path: Path, date_cols: list[str]) -> pd.DataFrame | None:
    if not path.exists():
        return None
    try:
        df = pd.read_csv(path, dtype={"cusip": str, "fund_cik": str, "owner_cik": str})
        for c in date_cols:
            if c in df.columns:
                df[c] = pd.to_datetime(df[c])
        return df
    except Exception as exc:  # noqa: BLE001
        log.warning("cannot read %s: %s", path, exc)
        return None
