"""`run-daily`: end-of-day pipeline (data -> sanity -> signals -> journal -> Discord -> paper).

The model portfolio of each track is persisted in the journal `state` table. Each
run replays the engine from the last processed session to the newest bar, so
pending orders, stops, targets and time exits are processed exactly as in the
backtest (same code path). Missed sessions are journaled with published=0.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

import pandas as pd

from . import tradingcal
from .config import Secrets, resolve_path
from .data import apply_index_cfds, MarketBundle, load_bundle, load_universe
from .engine import Decision, Engine, MarketArrays, Profile, build_market
from .journal import Journal
from .notify import DiscordNotifier, format_alert, format_decision
from .risk import RiskSettings, check_staleness
from .strategies.base import StrategyOutput
from .strategies.ensemble import build_track_signals
from .synthetic import SyntheticSpec, generate_bundle

log = logging.getLogger(__name__)


@dataclass
class DailyResult:
    date: str
    decisions: dict[str, Decision] = field(default_factory=dict)
    messages: dict[str, list[str]] = field(default_factory=dict)
    alerts: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    paper_orders: list[str] = field(default_factory=list)


def synthetic_bundle(cfg: dict[str, Any], asof: str | None = None) -> MarketBundle:
    sc = cfg.get("backtest", {}).get("synthetic", {})
    b = generate_bundle(SyntheticSpec(int(sc.get("n_stocks", 80)), str(sc.get("start", "2009-01-02")),
                                      int(sc.get("years", 16)), int(sc.get("seed", 7))))
    b = apply_index_cfds(b, cfg)
    return b.truncate(asof) if asof else b


def live_tracks(cfg: dict[str, Any]) -> list[str]:
    return [t for t, tc in cfg["tracks"].items() if tc.get("enabled", False)]


def state_symbols(journal: Journal, tracks: list[str]) -> set[str]:
    """Symbols held or with pending orders in the saved model state of `tracks`."""
    out: set[str] = set()
    for tr in tracks:
        st = journal.load_state(tr) or {}
        out |= set(st.get("positions", {}))
        out |= {str(o.get("symbol")) for o in st.get("pending", []) if o.get("symbol")}
    return out


def process_track(cfg: dict[str, Any], bundle: MarketBundle, market: MarketArrays, rs: RiskSettings, journal: Journal,
                  track: str, start_i: int | None, end_i: int, cache: dict[str, StrategyOutput],
                  force: bool = False, simulated: bool = False) -> tuple[Engine, Decision | None, list[str]]:
    """Advance the track's model portfolio to `end_i`, journaling signals/outcomes/NAV."""
    notes: list[str] = []
    sig = build_track_signals(bundle, cfg, track, cache)
    prof = Profile.from_config(cfg, cfg["general"].get("model_risk_profile"), cfg["general"].get("model_leverage_profile"))
    eng = Engine(market, sig, cfg["tracks"][track], rs, prof, float(cfg["general"].get("initial_capital", 100_000)), track)
    st = journal.load_state(track)
    if st and start_i is None:
        notes += eng.load_state(st)
        start = (eng.last_i + 1) if eng.last_i is not None else end_i
    else:
        start = end_i if start_i is None else start_i
    if start > end_i:
        # Re-stepping an already processed session would execute the pending orders (meant for the NEXT
        # open) at this session's past open, charge financing twice and journal a duplicate NAV row.
        # --force therefore never re-processes a session that is already in the saved state.
        msg = f"{track}: already processed {market.dates[end_i].date()}"
        if force:
            msg += " (--force cannot re-run a processed session: it would double-fill pending orders)"
        return eng, None, notes + [msg]
    dec: Decision | None = None
    n_trades = 0
    meta = {"simulated": True} if simulated else {}
    # Benchmark as a TOTAL-RETURN index: chained from the previous journaled value with returns of the
    # CURRENT (dividend/split-adjusted) closes, so later back-adjustments by the provider cannot turn it
    # into a price-return series (that would bias the "beats the index" gate in favour of the bot).
    bench_prev_val: float | None = None
    bench_prev_i: int | None = None
    last_nav = journal.con.execute("SELECT date, bench_close FROM nav WHERE track=? ORDER BY id DESC LIMIT 1",
                                   (track,)).fetchone()
    if last_nav is not None and last_nav["bench_close"] is not None:
        k = int(market.dates.searchsorted(pd.Timestamp(last_nav["date"])))
        if k < len(market.dates) and market.dates[k] == pd.Timestamp(last_nav["date"]):
            bench_prev_val, bench_prev_i = float(last_nav["bench_close"]), k
    for i in range(start, end_i + 1):
        dec = eng.step(i)
        nav = eng.nav[-1]
        px = float(market.close_ff[i, market.bench_col])
        if bench_prev_i is not None and bench_prev_val is not None and market.close_ff[bench_prev_i, market.bench_col] > 0:
            bench_val = bench_prev_val * px / float(market.close_ff[bench_prev_i, market.bench_col])
        else:
            bench_val = px
        bench_prev_val, bench_prev_i = bench_val, i
        # simulated runs stamp rows with the session close time (UTC) instead of the wall clock
        ts = (pd.Timestamp(market.dates[i]).tz_localize("America/New_York") + pd.Timedelta(hours=16, minutes=20)
              ).tz_convert("UTC").isoformat() if simulated else None
        journal.record_nav(track, str(market.dates[i].date()), nav["equity"], nav["gross"], nav["regime"],
                           nav["breaker"], bench_val, created_utc=ts)
        for t in eng.trades[n_trades:]:
            journal.record_outcome(t, created_utc=ts)
        n_trades = len(eng.trades)
        final = i == end_i
        if dec is None:
            continue
        if dec.kill:
            journal.record_alert(track, dec.date, "kill_switch", dec.kill)
            continue
        publish = final or simulated
        for s in dec.signals:
            journal.record_signal(s, name=market.names.get(s.symbol, s.symbol), published=publish,
                                  meta={**meta, "backfill": not publish, "is_etf": bool(market.is_etf[market.col[s.symbol]])},
                                  created_utc=ts)
    journal.save_state(track, eng.to_state())
    return eng, dec, notes


def run_daily(cfg: dict[str, Any], secrets: Secrets, dry_run: bool = True, paper: bool = False,
              synthetic: bool = False, asof: str | None = None, force: bool = False,
              journal_path: str | None = None, printer: Callable[[str], None] = print,
              notifier_factory: Callable[[str], DiscordNotifier] | None = None,
              bundle: MarketBundle | None = None, persist: bool | None = None) -> DailyResult:
    """End-of-day run. `dry_run` prints instead of sending AND (by default) writes nothing: the journal and
    the saved model state are processed in a throw-away in-memory copy, so the real run of the same
    session afterwards still processes and sends it. `persist` overrides that (tests only)."""
    jpath = journal_path or str(resolve_path(cfg, cfg["general"]["journal_db"]))
    persist = (not dry_run) if persist is None else bool(persist)
    journal = Journal(jpath) if persist else Journal.in_memory_copy(jpath)
    if bundle is None and not synthetic:
        # keep symbols the model still holds / has pending in the universe even after they left the
        # S&P 500 constituents list (update-data refreshes it), otherwise they could never be exited
        uni = load_universe(cfg)
        for sym in sorted(state_symbols(journal, live_tracks(cfg)) - set(uni.symbols)):
            uni.stocks.append(sym)
            uni.sectors.setdefault(sym, "Unknown")
            uni.asset_classes.setdefault(sym, "equity")
            uni.names.setdefault(sym, sym)
        bundle = load_bundle(cfg, end=asof, universe=uni)
    bundle = bundle or synthetic_bundle(cfg, asof)
    rs = RiskSettings.from_config(cfg)
    market = build_market(bundle, cfg, rs)
    end_i = len(market.dates) - 1
    d_iso = str(market.dates[end_i].date())
    res = DailyResult(date=d_iso)

    def notifier(track: str) -> DiscordNotifier:
        if notifier_factory:
            return notifier_factory(track)
        return DiscordNotifier(secrets.webhook_for(track), dry_run=dry_run, printer=printer)

    if not synthetic and not asof:
        expected = tradingcal.expected_last_session(tz=cfg["general"]["timezone"])
        stale = check_staleness(market.dates[end_i], expected, int(rs.kill.get("max_stale_trading_days", 1)))
        if stale is None and market.dates[end_i] > expected:
            # newest bar is from a session that has not closed yet (run before 16:30 New York):
            # processing it would journal signals from an incomplete daily bar and consume the session
            stale = (f"incomplete bar: last bar {market.dates[end_i].date()} is newer than the last closed "
                     f"session {pd.Timestamp(expected).date()} - run after the US close")
        if stale:
            journal.record_alert(None, d_iso, "kill_switch", stale)
            for tr in live_tracks(cfg):
                notifier(tr).send([format_alert(tr, d_iso, stale, cfg)])
            res.alerts.append(stale)
            journal.close()
            return res
    cache: dict[str, StrategyOutput] = {}
    for tr in live_tracks(cfg):
        eng, dec, notes = process_track(cfg, bundle, market, rs, journal, tr, None, end_i, cache, force)
        for n in notes:
            log.info(n)
        if dec is None:
            res.skipped.append(tr)
            continue
        res.decisions[tr] = dec
        if dec.kill:
            msg = format_alert(tr, d_iso, dec.kill, cfg)
            notifier(tr).send([msg])
            res.alerts.append(f"{tr}: {dec.kill}")
            continue
        chunks = format_decision(dec, cfg, rs)
        notifier(tr).send(chunks)
        res.messages[tr] = chunks
    if paper:
        res.paper_orders = run_paper(cfg, secrets, res, market, dry_run=dry_run)
    journal.close()
    return res


def run_paper(cfg: dict[str, Any], secrets: Secrets, res: DailyResult, market: MarketArrays,
              dry_run: bool = True, executor: Any = None) -> list[str]:
    from .paper import AlpacaPaperExecutor, plan_orders

    pc = cfg.get("paper", {})
    tr = pc.get("track", "MESIC")
    dec = res.decisions.get(tr)
    if dec is None or dec.kill:
        return []
    try:
        ex = executor or AlpacaPaperExecutor(secrets)
    except Exception as exc:  # noqa: BLE001 - no orders are placed when the executor cannot start
        log.error("paper executor not started: %s", exc)
        return [f"paper skipped: {exc}"]
    eq = ex.account_equity()
    pos = ex.positions()
    nxt = str(tradingcal.add_trading_days(pd.Timestamp(dec.date), 1).date())
    sigs = [s for s in dec.signals if s.sleeve == "core" or pc.get("include_defensive", False)]
    plan = plan_orders(sigs, eq, pos, float(pc.get("max_leverage", 1.0)), nxt, bool(pc.get("use_bracket_orders", True)))
    return ex.execute(plan, dry_run=dry_run)
