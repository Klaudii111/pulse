"""Synthetic market generator (for tests and offline verification only).

Produces a `MarketBundle` with:
  * a regime-switching market factor (bull / bear / chop) plus injected crash
    periods (2008-like slow bear, 2020-like fast crash, 2022-like stock+bond bear)
  * 11 GICS sector factors
  * stocks = beta * market + sector + idiosyncratic + slowly mean-reverting
    drift (creates persistent trends, i.e. momentum exists), some IPOs/delistings,
    some sub-$5 or illiquid names
  * core ETFs with stylised behaviour (bonds/gold hedge in crashes, cash ~ flat)
  * synthetic 13F filings (quarterly, filed 30-45 days after quarter end)
  * synthetic quarterly earnings dates and point-in-time fundamentals

Results on this data say NOTHING about real-world performance.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from . import tradingcal
from .data import MarketBundle, PriceData

GICS = ["Information Technology", "Health Care", "Financials", "Consumer Discretionary", "Communication Services",
        "Industrials", "Consumer Staples", "Energy", "Utilities", "Real Estate", "Materials"]

ETF_SPEC = {
    # symbol: (class, sector, beta, idio_vol, drift, crash_beta); ETFs are share CFDs (equity, 5:1)
    "SPY": ("equity", "ETF US Large Cap", 1.00, 0.010, 0.000, 0.0),
    "QQQ": ("equity", "ETF US Growth", 1.20, 0.060, 0.020, 0.0),
    "IWM": ("equity", "ETF US Small Cap", 1.15, 0.080, -0.010, 0.0),
    "EFA": ("equity", "ETF Intl Developed", 0.85, 0.080, -0.020, 0.0),
    "EEM": ("equity", "ETF Emerging", 1.10, 0.120, -0.010, 0.0),
    "TLT": ("equity", "ETF Long Treasury", -0.10, 0.130, 0.025, -0.35),
    "IEF": ("equity", "ETF Mid Treasury", -0.04, 0.055, 0.020, -0.15),
    "GLD": ("equity", "ETF Gold", 0.05, 0.150, 0.045, -0.15),
    "DBC": ("equity", "ETF Commodities", 0.40, 0.170, 0.000, 0.10),
    "VNQ": ("equity", "ETF Real Estate", 1.10, 0.120, 0.000, 0.0),
    "SHY": ("equity", "ETF Cash", 0.00, 0.012, 0.018, -0.01),
    "BIL": ("equity", "ETF Cash", 0.00, 0.003, 0.015, 0.0),
    "UUP": ("equity", "ETF US Dollar", -0.05, 0.075, 0.005, -0.10),
}

SECTOR_ETF = {"Information Technology": "XLK", "Health Care": "XLV", "Financials": "XLF",
              "Consumer Discretionary": "XLY", "Communication Services": "XLC", "Industrials": "XLI",
              "Consumer Staples": "XLP", "Energy": "XLE", "Utilities": "XLU", "Real Estate": "XLRE",
              "Materials": "XLB"}

FUND_CIKS = ["0001067983", "0001336528", "0001536411", "0001656456", "0001061768", "0001079114", "0001709323"]


@dataclass
class SyntheticSpec:
    n_stocks: int = 80
    start: str = "2009-01-02"
    years: int = 16
    seed: int = 7


def _crash_windows(n: int) -> list[tuple[int, int, float, str]]:
    """(start, length, annualised market drift, kind) injected regimes."""
    out = []
    if n > 600:
        out.append((int(n * 0.10), 260, -0.45, "slow_bear"))      # 2008-like
    if n > 2000:
        out.append((int(n * 0.62), 25, -3.20, "fast_crash"))      # 2020-like
        out.append((int(n * 0.62) + 25, 80, 0.90, "rebound"))
    if n > 3000:
        out.append((int(n * 0.84), 200, -0.30, "stock_bond_bear"))  # 2022-like
    return out


def generate_bundle(spec: SyntheticSpec | None = None) -> MarketBundle:
    spec = spec or SyntheticSpec()
    rng = np.random.default_rng(spec.seed)
    n_days = int(spec.years * 252)
    # NYSE sessions (holidays excluded) so calendar-based rules match the data index
    dates = tradingcal.trading_days(spec.start, pd.Timestamp(spec.start) + pd.Timedelta(days=int(n_days * 1.5) + 30))[:n_days]
    T = len(dates)
    dt = 1.0 / 252.0

    # ---- market factor: Markov regimes + injected crashes ------------------
    regimes = {"bull": (0.13, 0.13), "bear": (-0.18, 0.26), "chop": (0.02, 0.18)}
    trans = {"bull": [0.996, 0.002, 0.002], "bear": [0.012, 0.982, 0.006], "chop": [0.006, 0.004, 0.990]}
    names = list(regimes)
    st = "bull"
    mu = np.zeros(T)
    sig = np.zeros(T)
    for t in range(T):
        mu[t], sig[t] = regimes[st]
        st = names[rng.choice(3, p=trans[st])]
    kind = np.array([""] * T, dtype=object)
    for s0, ln, drift, k in _crash_windows(T):
        e = min(T, s0 + ln)
        mu[s0:e] = drift
        sig[s0:e] = 0.55 if k == "fast_crash" else (0.30 if drift < 0 else 0.25)
        kind[s0:e] = k
    eps = rng.standard_t(5, T) / np.sqrt(5 / 3)
    r_m = mu * dt + sig * np.sqrt(dt) * eps
    stress = (mu < 0).astype(float)
    sector_f = rng.normal(0, 0.10 * np.sqrt(dt), (T, len(GICS)))
    # persistent sector drifts (rotation exists)
    phi_s = np.exp(-1 / 250.0)
    sd = rng.normal(0, 0.08, len(GICS))
    for t in range(T):
        sd = sd * phi_s + rng.normal(0, 0.08 * np.sqrt(1 - phi_s ** 2), len(GICS))
        sector_f[t] += sd * dt

    rets: dict[str, np.ndarray] = {}
    meta: dict[str, tuple[str, str, bool]] = {}
    # ---- ETFs ----------------------------------------------------------------
    for sym, (cls, sector, beta, ivol, drift, crash_beta) in ETF_SPEC.items():
        b = np.full(T, beta)
        if crash_beta:
            b = np.where(stress > 0, crash_beta, beta)
        d = np.full(T, drift)
        if sym in ("TLT", "IEF"):
            d = np.where(kind == "stock_bond_bear", -0.35 if sym == "TLT" else -0.15, d)
            b = np.where(kind == "stock_bond_bear", 0.3, b)
        if sym == "UUP":
            d = np.where(stress > 0, 0.08, d)
        noise = rng.normal(0, ivol * np.sqrt(dt), T)
        rets[sym] = d * dt + b * r_m + noise
        meta[sym] = (cls, sector, True)
    rets["QQQ"] = rets["QQQ"] + 0.5 * sector_f[:, 0]
    for k_s, sec_name in enumerate(GICS):
        etf = SECTOR_ETF[sec_name]
        rets[etf] = r_m * rng.uniform(0.8, 1.2) + sector_f[:, k_s] + rng.normal(0, 0.04 * np.sqrt(dt), T)
        meta[etf] = ("equity", f"ETF Sector {sec_name}", True)

    # ---- stocks --------------------------------------------------------------
    for k in range(spec.n_stocks):
        sym = f"S{k:03d}"
        sec = k % len(GICS)
        beta = rng.uniform(0.6, 1.5)
        ivol = rng.uniform(0.15, 0.45)
        phi = np.exp(-1 / 200.0)
        alpha = np.zeros(T)
        a = rng.normal(0, 0.15)
        shocks = rng.normal(0, 0.15 * np.sqrt(1 - phi ** 2), T)
        for t in range(T):
            a = a * phi + shocks[t]
            alpha[t] = a
        r = alpha * dt + beta * r_m + sector_f[:, sec] + rng.normal(0, ivol * np.sqrt(dt), T)
        # occasional earnings-like jumps
        jumps = rng.random(T) < 1 / 63
        r = r + jumps * rng.normal(0, 0.04, T)
        rets[sym] = r
        meta[sym] = ("equity", GICS[sec], False)

    syms = list(rets)
    O = np.full((T, len(syms)), np.nan)
    Hh, L, C, V = O.copy(), O.copy(), O.copy(), O.copy()
    for jj, sym in enumerate(syms):
        r = rets[sym]
        is_etf = meta[sym][2]
        p0 = 100.0 if is_etf else rng.uniform(8, 200)
        if sym == "BIL":
            p0 = 91.5
        if not is_etf and jj % 23 == 7:
            p0 = rng.uniform(2.5, 6.0)  # penny-ish name to exercise the $5 filter
        close = p0 * np.exp(np.cumsum(r))
        dv = max(1e-4, float(np.std(r)))
        gap = r * rng.uniform(0.2, 0.5) + rng.normal(0, 0.15 * dv, T)
        prev = np.concatenate([[p0], close[:-1]])
        open_ = prev * np.exp(gap)
        hi = np.maximum(open_, close) * np.exp(np.abs(rng.normal(0, 0.5 * dv, T)))
        lo = np.minimum(open_, close) * np.exp(-np.abs(rng.normal(0, 0.5 * dv, T)))
        base_dv = 5e8 if sym in ("SPY", "QQQ") else (1.5e8 if is_etf else np.exp(rng.normal(np.log(1.2e8), 0.9)))
        if not is_etf and jj % 17 == 3:
            base_dv = 8e6  # illiquid
        vol_sh = base_dv / close * np.exp(rng.normal(0, 0.25, T))
        O[:, jj], Hh[:, jj], L[:, jj], C[:, jj], V[:, jj] = open_, hi, lo, close, vol_sh
        if not is_etf and jj % 19 == 5:     # IPO later
            cut = int(T * rng.uniform(0.2, 0.5))
            for arr in (O, Hh, L, C, V):
                arr[:cut, jj] = np.nan
        if not is_etf and jj % 29 == 11:    # delisting
            cut = int(T * rng.uniform(0.5, 0.8))
            for arr in (O, Hh, L, C, V):
                arr[cut:, jj] = np.nan
    mk = lambda a: pd.DataFrame(a, index=dates, columns=syms)  # noqa: E731
    prices = PriceData(open=mk(O), high=mk(Hh), low=mk(L), close=mk(C), volume=mk(V))

    holdings = _synthetic_13f(prices, [s for s in syms if not meta[s][2]], rng)
    earnings = _synthetic_earnings(dates, [s for s in syms if not meta[s][2]], rng)
    fundamentals = _synthetic_fundamentals(dates, [s for s in syms if not meta[s][2]], prices, rng)
    insider = _synthetic_insider(dates, [s for s in syms if not meta[s][2]], rng)
    vix = _synthetic_vix(dates, sig, r_m, rng)
    return MarketBundle(
        prices=prices, insider=insider, vix=vix,
        sectors={s: meta[s][1] for s in syms},
        asset_classes={s: meta[s][0] for s in syms},
        is_etf={s: meta[s][2] for s in syms},
        names={s: (f"Synthetic {s}" if not meta[s][2] else f"Synthetic ETF {s}") for s in syms},
        holdings=holdings, fundamentals=fundamentals, earnings=earnings, synthetic=True,
    )


def _synthetic_13f(prices: PriceData, stocks: list[str], rng: np.random.Generator) -> pd.DataFrame:
    """Quarterly 13F-HR filings, filed 30-45 days after quarter end; picks use past returns only."""
    close = prices.close[stocks]
    qends = pd.date_range(prices.dates[0], prices.dates[-1], freq="QE")
    rows = []
    for f_i, cik in enumerate(FUND_CIKS):
        book: dict[str, float] = {}
        for q in qends:
            hist = close.loc[:q]
            if len(hist) < 130:
                continue
            past = (hist.iloc[-1] / hist.iloc[-126] - 1).dropna()
            if past.empty:
                continue
            # keep ~75%, add names tilted toward past winners (known at q)
            keep = {s: v for s, v in book.items() if s in past.index and rng.random() < 0.75}
            pool = past.sort_values(ascending=False).index[: max(10, len(past) // 3)]
            want = min(12 + f_i % 5, len(set(pool) | set(keep)))
            while len(keep) < want:
                s = str(rng.choice(pool))
                keep.setdefault(s, float(rng.integers(1_000, 100_000)))
            book = {s: v * (rng.uniform(0.8, 1.3)) for s, v in keep.items()}
            filed = q + pd.Timedelta(days=int(rng.integers(30, 46)))
            for s, sh in book.items():
                rows.append({"fund_cik": cik, "fund_name": f"Fund {f_i}", "form": "13F-HR", "filing_date": filed,
                             "report_date": q, "accession": f"{cik}-{q.date()}", "cusip": f"SYN{s}",
                             "ticker": s, "shares": round(sh), "value": 0.0, "put_call": None})
    return pd.DataFrame(rows)


def _synthetic_earnings(dates: pd.DatetimeIndex, stocks: list[str], rng: np.random.Generator) -> pd.DataFrame:
    rows = []
    for s in stocks:
        off = int(rng.integers(20, 50))
        for q in pd.date_range(dates[0], dates[-1], freq="QE"):
            d = q + pd.Timedelta(days=off)
            if d <= dates[-1]:
                rows.append({"symbol": s, "date": d})
    return pd.DataFrame(rows)


def _synthetic_fundamentals(dates: pd.DatetimeIndex, stocks: list[str], prices: PriceData,
                            rng: np.random.Generator) -> pd.DataFrame:
    rows = []
    for s in stocks:
        assets = rng.uniform(1e9, 5e10)
        gpa = rng.uniform(0.05, 0.6)
        shares = rng.uniform(1e8, 2e9)
        for y in range(dates[0].year, dates[-1].year + 1):
            filed = pd.Timestamp(f"{y}-02-20") + pd.Timedelta(days=int(rng.integers(0, 30)))
            gpa = float(np.clip(gpa + rng.normal(0, 0.05), 0.0, 0.9))
            rows.append({"symbol": s, "filed": filed, "gross_profit": gpa * assets, "assets": assets,
                         "net_income": gpa * assets * rng.uniform(0.1, 0.4), "shares_outstanding": shares})
    return pd.DataFrame(rows)


def _synthetic_insider(dates: pd.DatetimeIndex, stocks: list[str], rng: np.random.Generator) -> pd.DataFrame:
    """Random Form 4 open-market purchases, occasionally clustered (3-5 insiders within ~2 weeks)."""
    rows = []
    for s in stocks:
        n_clusters = int(rng.integers(0, 6))
        for _ in range(n_clusters):
            base = dates[int(rng.integers(260, len(dates) - 5))]
            for k in range(int(rng.integers(2, 6))):
                td = base + pd.Timedelta(days=int(rng.integers(0, 14)))
                rows.append({"symbol": s, "trade_date": td, "filing_date": td + pd.Timedelta(days=int(rng.integers(1, 3))),
                             "owner_cik": f"{s}-{k}", "code": "P", "acq_disp": "A",
                             "shares": float(rng.integers(500, 20000)), "price": 50.0})
        for _ in range(int(rng.integers(5, 20))):   # unrelated sales (code S) are ignored by the strategy
            td = dates[int(rng.integers(0, len(dates)))]
            rows.append({"symbol": s, "trade_date": td, "filing_date": td + pd.Timedelta(days=2),
                         "owner_cik": f"{s}-x", "code": "S", "acq_disp": "D", "shares": 1000.0, "price": 50.0})
    return pd.DataFrame(rows)


def _synthetic_vix(dates: pd.DatetimeIndex, sig: np.ndarray, r_m: np.ndarray, rng: np.random.Generator) -> pd.DataFrame:
    """VIX ~ forward-looking-ish vol level; VIX3M smoother -> backwardation in crashes."""
    rv = pd.Series(r_m, index=dates).rolling(10, min_periods=2).std().bfill().to_numpy() * np.sqrt(252) * 100
    vix = 0.6 * rv + 0.4 * sig * 100 + rng.normal(0, 1.0, len(dates))
    vix = np.clip(vix, 9, 90)
    vix3m = pd.Series(vix, index=dates).ewm(span=60).mean().to_numpy() * 1.05 + 2.0
    return pd.DataFrame({"vix": vix, "vix3m": vix3m}, index=dates)
