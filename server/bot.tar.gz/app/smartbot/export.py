"""Static JSON export for the PWA (`export`) and intraday price refresh (`refresh-prices`).

Contract (UTF-8, ISO dates):
  signals.json      {"generated_at", "mode", "regime": {...}, "tracks": {"DEN","DNY","TYDEN","MESIC": [Signal]}}
  history.json      {"signals": [Signal]}  closed, newest first
  performance.json  {"as_of", "equity": [{"date","bot","spy"}] (indexed to 100), "by_horizon": {...}}
                    "spy" is the SPY TOTAL-RETURN index (dividends included), like the bot's equity.

Bilingual (export.reasons_format = "bilingual", default): "reasons" is a list of {"cs","en"} labels and
every signal has "explanation": {"cs","en"} (why + what invalidates it). "plain" keeps reasons as [str].

Unit conventions: *_pct fields are PERCENT (1.0 = 1 %); result_pct = position return %;
risk_pct_account / target_pct_account = % of the model account; win_rate is a fraction 0-1;
avg_r = expectancy_r = mean R per closed trade (expectancy expressed in R).
status: open | target | stop | time_exit  ("time_exit" also covers every other rule-based exit:
signal exit, regime change, circuit breaker, data). Defensive-sleeve allocations (dual momentum /
cash proxy, no target) are not exported.

Intraday rule (refresh-prices): when a 15-minute refresh sees the price touch the target or the
stop, the signal gets intraday_hit = "target"|"stop" and hit_at immediately (first touch wins; if
both levels were touched within one interval STOP is assumed first) and result_pct/result_r are
computed at the level price. The daily close run remains authoritative for `status`.
"""
from __future__ import annotations

import json
import math
import os
import tempfile
import time as _time
from datetime import datetime, time, timezone
from pathlib import Path
from typing import Any, Callable
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from . import tradingcal
from .config import HORIZONS
from .journal import Journal
from .portfolio import combine_sleeves

STATUS_MAP = {"target": "target", "stop": "stop", "margin_stop_out": "stop"}

# Bilingual strategy templates: (short label, plain-language "why")
REASON_TEXT: dict[str, dict[str, tuple[str, str]]] = {
    "trend": {"cs": ("Trend (12 měsíců)", "cena roste déle než rok a drží se nad 200denním průměrem"),
              "en": ("Trend (12 months)", "the price has risen over the past year and holds above its 200-day average")},
    "momentum": {"cs": ("Momentum (top 10 %)", "patří mezi nejsilnější tituly za posledních 12 měsíců"),
                 "en": ("Momentum (top 10%)", "it is among the strongest names over the last 12 months")},
    "smart_money": {"cs": ("Smart money (13F)", "drží ho uznávaní investoři podle posledních hlášení 13F"),
                    "en": ("Smart money (13F)", "respected investors hold it according to their latest 13F filings")},
    "quality_value": {"cs": ("Kvalita/hodnota", "vysoká ziskovost a rozumné ocenění"),
                      "en": ("Quality/value", "high profitability at a reasonable valuation")},
    "sector_rotation": {"cs": ("Rotace sektorů", "sektor je mezi 3 nejsilnějšími a nad 200denním průměrem"),
                        "en": ("Sector rotation", "the sector is among the 3 strongest and above its 200-day average")},
    "insider_cluster": {"cs": ("Nákupy insiderů", "alespoň 3 manažeři firmy nakoupili akcie za posledních 30 dní"),
                        "en": ("Insider buying", "at least 3 company insiders bought shares in the last 30 days")},
    "swing_pullback": {"cs": ("Pullback v trendu", "krátkodobý pokles (RSI(2) < 10) uvnitř dlouhodobého růstu"),
                       "en": ("Pullback in uptrend", "a short-term dip (RSI(2) < 10) inside a long-term uptrend")},
    "breakout": {"cs": ("Průraz (20 dní)", "cena prorazila nad maximum posledních 20 dní"),
                 "en": ("Breakout (20 days)", "the price broke above its 20-day high")},
    "weekly_reversal": {"cs": ("Týdenní obrat", "velká firma výrazně klesla za týden, často následuje odraz"),
                        "en": ("Weekly reversal", "a large cap fell sharply this week; a rebound often follows")},
    "mean_reversion_1d": {"cs": ("Odraz ode dna dne", "zavření u denního minima v rostoucím trendu"),
                          "en": ("Intraday-low bounce", "it closed near the day's low within an uptrend")},
    "mean_reversion_3d": {"cs": ("Krátký odraz", "přeprodanost (RSI(2)/IBS) v rostoucím trendu"),
                          "en": ("Short bounce", "oversold (RSI(2)/IBS) within an uptrend")},
    "pullback_10d_low": {"cs": ("10denní minimum v trendu", "cena je na 10denním minimu, ale dlouhodobý trend roste"),
                         "en": ("10-day low in uptrend", "the price is at a 10-day low while the long-term trend is up")},
    "short_breakout": {"cs": ("Krátký průraz ETF", "ETF prorazilo 10denní maximum nad 50denním průměrem"),
                       "en": ("Short ETF breakout", "the ETF broke its 10-day high above its 50-day average")},
    "calendar_effects": {"cs": ("Kalendářní efekt", "přelom měsíce nebo den před svátkem bývá pro index silnější"),
                         "en": ("Calendar effect", "turn of the month or the day before a holiday tends to be stronger")},
    "volatile_oversold": {"cs": ("Přeprodaný odraz", "silná akcie v rostoucím trendu prudce spadla (RSI(2) < 10) ve chvíli zvýšeného strachu na trhu (VIX nad 18); bot prodá, jakmile cena odrazí nad 5denní průměr"),
                          "en": ("Oversold bounce", "a strong stock in an uptrend dropped hard (RSI(2) < 10) while market fear is elevated (VIX above 18); the bot sells as soon as the price bounces above its 5-day average")},
    "rsi_vix": {"cs": ("Pokles ve strachu", "krátký pokles (RSI(2) < 5) v rostoucím trendu, když je VIX nad 18"),
                "en": ("Dip in fear", "a short dip (RSI(2) < 5) in an uptrend while VIX is above 18")},
    "deep_pullback": {"cs": ("Hluboký pokles v trendu", "cena spadla o více než 3 denní rozpětí (ATR) pod 5denní maximum, trend roste a VIX je nad 18"),
                      "en": ("Deep pullback in uptrend", "the price fell more than 3 daily ranges (ATR) below its 5-day high while the trend is up and VIX is above 18")},
    "deep_pullback_hold": {"cs": ("Hluboký pokles, týden", "cena spadla o více než 3 denní rozpětí (ATR) pod 5denní maximum v rostoucím trendu a při zvýšeném strachu (VIX nad 18); drží se celý týden"),
                           "en": ("Deep pullback, one week", "the price fell more than 3 daily ranges (ATR) below its 5-day high in an uptrend while fear is elevated (VIX above 18); held for the full week")},
    "crisis_trend": {"cs": ("Krizový trend", "obranné aktivum (dluhopisy/zlato/dolar) je v rostoucím trendu"),
                     "en": ("Crisis trend", "a defensive asset (bonds/gold/dollar) is in an uptrend")},
    "dual_momentum": {"cs": ("Obranná alokace", "trh je v risk-off, kapitál jde do nejsilnějšího obranného aktiva"),
                      "en": ("Defensive allocation", "the market is risk-off; capital moves to the strongest defensive asset")},
    "cash_proxy": {"cs": ("Hotovost", "trh je v risk-off nebo je aktivní jistič ztrát"),
                   "en": ("Cash", "the market is risk-off or the loss circuit breaker is active")},
}


def reason_obj(code: str) -> dict[str, str]:
    t = REASON_TEXT.get(code)
    if t is None:
        return {"cs": code, "en": code}
    return {"cs": t["cs"][0], "en": t["en"][0]}


def explanation(codes: list[str], stop: float | None, exit_date: str | None, roll: bool = False) -> dict[str, str]:
    """Short plain-language why + what invalidates the signal, from the strategy templates."""
    whys_cs = [REASON_TEXT[c]["cs"][1] for c in codes if c in REASON_TEXT] or ["splněna pravidla strategie"]
    whys_en = [REASON_TEXT[c]["en"][1] for c in codes if c in REASON_TEXT] or ["the strategy rules are met"]
    st = f"{stop:.2f}" if stop is not None else "-"
    d = exit_date or "-"
    if roll:
        tail_cs = "(pak se pozice zavře, nebo prodlouží, pokud signál stále platí)"
        tail_en = "(the position is then closed, or extended if the signal still holds)"
    else:
        tail_cs, tail_en = "(pak se pozice zavře)", "(the position is then closed)"
    cs = f"Proč: {'; '.join(whys_cs)}. Neplatí, pokud cena klesne na stop {st} nebo do {d} nedosáhne cíle {tail_cs}."
    en = (f"Why: {'; '.join(whys_en)}. Invalidated if the price falls to the stop {st}, or if the target is not "
          f"reached by {d} {tail_en}.")
    return {"cs": cs, "en": en}
NY = ZoneInfo("America/New_York")


def _iso_utc(s: str | None) -> str | None:
    if not s:
        return None
    ts = pd.Timestamp(s)
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    return ts.isoformat()


def _close_iso(date: str) -> str:
    """ISO timestamp of the US close (16:00 New York) on `date`."""
    d = pd.Timestamp(date).date()
    return datetime.combine(d, time(16, 0), NY).isoformat()


def _num(x: Any, nd: int = 4) -> float | None:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return round(v, nd) if math.isfinite(v) else None


def atomic_write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(obj, fh, ensure_ascii=False, indent=1)
        os.chmod(tmp, 0o644)   # readable by the web server serving the PWA
        for attempt in range(10):
            try:
                os.replace(tmp, path)  # atomic on Windows and POSIX
                break
            except PermissionError:  # Windows: target briefly open by a reader (web server / AV scanner)
                if attempt == 9:
                    raise
                _time.sleep(0.2)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def _asset_class(row: dict[str, Any], etf_label: str) -> str:
    if str(row.get("asset_class", "")).startswith("index"):
        return "index"            # explicit index CFD instrument (US500, US100, ...)
    meta = json.loads(row.get("meta") or "{}")
    if meta.get("is_etf"):
        return "index" if etf_label == "index" else "etf"
    return "stock"


def progress_of(last: float, entry: float, stop: float, target: float | None) -> float:
    """-1 at stop, 0 at entry, +1 at target (clamped)."""
    if last >= entry:
        if not target or target <= entry:
            return 0.0
        return float(max(-1.0, min(1.0, (last - entry) / (target - entry))))
    if entry <= stop:
        return 0.0
    return float(max(-1.0, min(1.0, -(entry - last) / (entry - stop))))


def build_export(journal: Journal, cfg: dict[str, Any], prices: pd.DataFrame | None = None,
                 previous: dict[str, Any] | None = None, now: datetime | None = None) -> dict[str, Any]:
    """Build the three JSON documents from the journal (+ optional close prices for price paths)."""
    now = now or datetime.now(timezone.utc)
    etf_label = cfg.get("export", {}).get("etf_asset_class", "etf")
    bilingual = cfg.get("export", {}).get("reasons_format", "bilingual") == "bilingual"
    sig = journal.frame("signals", "published=1 AND sleeve='core'")
    out = journal.frame("outcomes")
    nav = journal.frame("nav")
    prev_by_id = {}
    for lst in (previous or {}).get("tracks", {}).values():
        for s in lst:
            prev_by_id[s["id"]] = s
    states = {t: (journal.load_state(t) or {}) for t in HORIZONS}
    tracks: dict[str, list[dict[str, Any]]] = {h: [] for h in HORIZONS}
    history: list[dict[str, Any]] = []
    buys = sig[sig["action"] == "BUY"] if len(sig) else sig
    outcome_by_sig = {int(r["signal_id"]): r for _, r in out.iterrows() if pd.notna(r["signal_id"])} if len(out) else {}
    last_date = {t: (nav[nav["track"] == t]["date"].max() if len(nav) else None) for t in HORIZONS}
    for _, b in buys.iterrows():
        tr = b["track"]
        if tr not in HORIZONS:
            continue
        sid = int(b["id"])
        codes = json.loads(b["reasons"] or "[]")
        rec: dict[str, Any] = {
            "id": f"{tr}-{b['signal_date']}-{b['symbol']}-{sid}", "symbol": b["symbol"], "name": b["name"] or b["symbol"],
            "asset_class": _asset_class(dict(b), etf_label), "horizon": tr, "action": "BUY",
            "created_at": _iso_utc(b["created_utc"]), "entry": _num(b["ref_price"]), "stop": _num(b["stop"]),
            "target": _num(b["target"]), "exit_date": b["exit_due"], "risk_pct_account": _num((b["risk_pct"] or 0) * 100, 3),
            "target_pct_account": _num((b["reward_pct"] or 0) * 100, 3), "rr": _num(b["rr"], 2),
            "max_leverage": _num(b["max_leverage"], 1), "reasons": codes,
            "status": "open", "result_r": None, "result_pct": None, "closed_at": None,
            "intraday_hit": None, "hit_at": None,
        }
        if bilingual:
            rec["reasons"] = [reason_obj(c) for c in codes]
            rec["explanation"] = explanation(codes, _num(b["stop"]), b["exit_due"],
                                             bool(cfg["tracks"].get(tr, {}).get("roll_on_time_exit", False)))
        o = outcome_by_sig.get(sid)
        if o is not None:
            rec["status"] = STATUS_MAP.get(str(o["exit_reason"]), "time_exit")
            rec["result_r"] = _num(o["r_multiple"], 3)
            rec["result_pct"] = _num((o["return_pct"] or 0) * 100, 3)
            rec["closed_at"] = _close_iso(o["exit_date"])
            p = prev_by_id.get(rec["id"])
            if p:
                rec["intraday_hit"], rec["hit_at"] = p.get("intraday_hit"), p.get("hit_at")
            history.append(rec)
            if o["exit_date"] == last_date.get(tr):  # closed today -> also announce as SELL
                tracks[tr].append({**rec, "action": "SELL"})
            continue
        pos = states.get(tr, {}).get("positions", {}).get(b["symbol"])
        pend = [x for x in states.get(tr, {}).get("pending", []) if x.get("symbol") == b["symbol"] and x.get("action") == "BUY"]
        if pos is None and not pend:
            continue  # never filled (e.g. gap through stop) -> not an open signal
        if pos is not None and pos.get("signal_date") != b["signal_date"]:
            continue
        last = float(pos["last_close"]) if pos else float(b["ref_price"])
        last_at = _close_iso(pos["last_close_date"]) if pos else _close_iso(b["signal_date"])
        entry, stop, target = float(b["ref_price"]), float(b["stop"]), (float(b["target"]) if pd.notna(b["target"]) else None)
        path = []
        if prices is not None and b["symbol"] in prices.columns:
            ser = prices[b["symbol"]].loc[pd.Timestamp(b["signal_date"]):].dropna()
            path = [{"t": _close_iso(str(d.date())), "p": _num(v, 4)} for d, v in ser.items()]
        if not path:
            path = [{"t": _close_iso(b["signal_date"]), "p": _num(entry)}]
            if last_at != path[0]["t"]:
                path.append({"t": last_at, "p": _num(last)})
        p = prev_by_id.get(rec["id"], {})
        rec.update({
            "last_price": _num(last), "last_price_at": last_at,
            "pnl_pct_position": _num((last / entry - 1) * 100, 3),
            "pnl_r": _num((last - entry) / (entry - stop), 3) if entry > stop else None,
            "progress": _num(progress_of(last, entry, stop, target), 3), "price_path": path,
            "intraday_hit": p.get("intraday_hit"), "hit_at": p.get("hit_at"),
        })
        if p.get("intraday_hit"):
            rec["result_pct"], rec["result_r"] = p.get("result_pct"), p.get("result_r")
        tracks[tr].append(rec)
    history.sort(key=lambda r: r["closed_at"] or "", reverse=True)
    history = history[: int(cfg.get("export", {}).get("history_limit", 500))]
    # regime from the LATEST regime state (newest NAV session), not from whichever signal row came last
    regime = {"state": "risk_off", "spy_vs_sma200_pct": None, "note": ""}
    if len(nav):
        latest = nav[nav["date"] == nav["date"].max()]
        on = latest["regime"].dropna()
        regime["state"] = "risk_on" if len(on) and int(on.iloc[-1]) == 1 else "risk_off"
    if prices is not None and "SPY" in prices.columns:
        spy = prices["SPY"].dropna()
        if len(spy) >= 200:
            regime["spy_vs_sma200_pct"] = _num((spy.iloc[-1] / spy.iloc[-200:].mean() - 1) * 100, 2)
    regime["note"] = ("Risk-on: SPY nad 200denním průměrem." if regime["state"] == "risk_on"
                      else "Risk-off: snížená expozice, páka omezena na 1x.")
    perf = build_performance(journal, cfg, nav, out)
    signals_doc = {"generated_at": now.replace(microsecond=0).isoformat(), "mode": cfg["general"].get("mode", "paper"),
                   "regime": regime, "tracks": tracks}
    return {"signals": signals_doc, "history": {"signals": history}, "performance": perf}


def build_performance(journal: Journal, cfg: dict[str, Any], nav: pd.DataFrame, out: pd.DataFrame) -> dict[str, Any]:
    by: dict[str, Any] = {}
    eqs: dict[str, pd.Series] = {}
    for tr in HORIZONS:
        n = nav[nav["track"] == tr].drop_duplicates("date", keep="last") if len(nav) else nav
        o = out[(out["track"] == tr) & (out["sleeve"] == "core")] if len(out) else out
        if len(n):
            e = pd.Series(n["equity"].to_numpy(dtype=float), index=pd.to_datetime(n["date"]))
            eqs[tr] = e
        by[tr] = _stats(o, eqs.get(tr))
    spy = None
    if len(nav):
        # bench_close is a per-track chained total-return index: take ONE track's series (the longest)
        counts = nav.groupby("track")["date"].nunique()
        ref = counts.idxmax()
        b = nav[nav["track"] == ref].drop_duplicates("date", keep="last")
        spy = pd.Series(b["bench_close"].to_numpy(dtype=float), index=pd.to_datetime(b["date"])).sort_index()
    combined = None
    live = [t for t in eqs if cfg["tracks"].get(t, {}).get("enabled", False)] or list(eqs)
    if live:
        combined = combine_sleeves({t: eqs[t] for t in live}, cfg)[0] if len(live) > 1 else eqs[live[0]]
    o_all = out[(out["track"].isin(live)) & (out["sleeve"] == "core")] if len(out) else out
    by["ALL"] = _stats(o_all, combined)
    eq_rows = []
    if combined is not None and len(combined):
        c = combined / combined.iloc[0] * 100
        s = spy.reindex(c.index).ffill() if spy is not None else None
        s = s / s.dropna().iloc[0] * 100 if s is not None and s.notna().any() else None
        for d, v in c.items():
            eq_rows.append({"date": str(d.date()), "bot": _num(v, 3),
                            "spy": _num(s.loc[d], 3) if s is not None else None})
    as_of = str(combined.index[-1].date()) if combined is not None and len(combined) else None
    return {"as_of": as_of, "equity": eq_rows, "by_horizon": by}


def _stats(o: pd.DataFrame, eq: pd.Series | None) -> dict[str, Any]:
    n = int(len(o))
    r = o["r_multiple"].astype(float).replace([np.inf, -np.inf], np.nan).dropna() if n else pd.Series(dtype=float)
    win = float((o["pnl"] > 0).mean()) if n else 0.0
    dd = ret = 0.0
    if eq is not None and len(eq) > 1:
        dd = float((eq / eq.cummax() - 1).min() * 100)
        ret = float((eq.iloc[-1] / eq.iloc[0] - 1) * 100)
    mean_r = float(r.mean()) if len(r) else 0.0
    return {"trades": n, "win_rate": round(win, 4), "avg_r": round(mean_r, 3), "expectancy_r": round(mean_r, 3),
            "max_dd_pct": round(dd, 2), "return_pct": round(ret, 2)}


def write_export(docs: dict[str, Any], out_dir: Path) -> list[Path]:
    paths = []
    for name in ("signals", "history", "performance"):
        p = Path(out_dir) / f"{name}.json"
        atomic_write_json(p, docs[name])
        paths.append(p)
    return paths


# --------------------------------------------------------------------------- refresh-prices
Quote = dict[str, Any]  # {"last": float, "high": float, "low": float, "ts": ISO}


def market_open(now: datetime | None = None) -> bool:
    now = (now or datetime.now(NY)).astimezone(NY)
    return tradingcal.is_trading_day(pd.Timestamp(now.date())) and time(9, 30) <= now.time() <= time(16, 0)


def refresh_prices(out_dir: Path, fetch: Callable[[str, str | None], Quote | None], journal: Journal | None = None,
                   now: datetime | None = None, force: bool = False, max_path: int = 400) -> dict[str, Any]:
    """Update open signals in signals.json with intraday prices; mark first intraday stop/target touch."""
    now = now or datetime.now(timezone.utc)
    if not force and not market_open(now):
        return {"updated": 0, "skipped": "market closed"}
    path = Path(out_dir) / "signals.json"
    doc = json.loads(path.read_text(encoding="utf-8"))
    updated = hits = 0
    for tr, lst in doc.get("tracks", {}).items():
        for s in lst:
            if s.get("status") != "open" or s.get("action") != "BUY":
                continue
            q = fetch(s["symbol"], s.get("last_price_at"))
            if not q or q.get("last") is None:
                continue
            last, hi, lo, ts = float(q["last"]), float(q.get("high", q["last"])), float(q.get("low", q["last"])), q["ts"]
            entry, stop, target = float(s["entry"]), float(s["stop"]), s.get("target")
            s["last_price"], s["last_price_at"] = round(last, 4), ts
            s["pnl_pct_position"] = round((last / entry - 1) * 100, 3)
            s["pnl_r"] = round((last - entry) / (entry - stop), 3) if entry > stop else None
            s["progress"] = round(progress_of(last, entry, stop, target), 3)
            s.setdefault("price_path", []).append({"t": ts, "p": round(last, 4)})
            s["price_path"] = s["price_path"][-max_path:]
            if not s.get("intraday_hit"):
                hit_stop = lo <= stop
                hit_tgt = target is not None and hi >= float(target)
                kind = "stop" if hit_stop else ("target" if hit_tgt else None)  # both -> STOP first (conservative)
                if kind:
                    level = stop if kind == "stop" else float(target)
                    s["intraday_hit"], s["hit_at"] = kind, ts
                    s["result_pct"] = round((level / entry - 1) * 100, 3)
                    s["result_r"] = round((level - entry) / (entry - stop), 3) if entry > stop else None
                    hits += 1
                    if journal is not None:
                        sid = int(str(s["id"]).rsplit("-", 1)[-1])
                        journal.append("intraday_events", {"track": tr, "signal_id": sid, "symbol": s["symbol"],
                                                           "kind": kind, "level_price": level, "hit_at": ts,
                                                           "last_price": last})
            updated += 1
    doc["generated_at"] = now.replace(microsecond=0).isoformat()
    atomic_write_json(path, doc)
    return {"updated": updated, "hits": hits}


def make_quote_fetcher(secrets: Any) -> Callable[[str, str | None], Quote | None]:
    """Alpaca free IEX 1-minute bars since the last refresh, fallback yfinance 1m bars."""
    alpaca = None
    if getattr(secrets, "alpaca_key_id", None) and getattr(secrets, "alpaca_secret_key", None):
        try:
            from alpaca.data.historical import StockHistoricalDataClient

            alpaca = StockHistoricalDataClient(secrets.alpaca_key_id, secrets.alpaca_secret_key)
        except Exception:  # noqa: BLE001
            alpaca = None

    def fetch(symbol: str, since: str | None) -> Quote | None:
        start = pd.Timestamp(since) if since else pd.Timestamp.now(tz="UTC") - pd.Timedelta(minutes=20)
        if start.tzinfo is None:
            start = start.tz_localize("UTC")
        if alpaca is not None:
            try:
                from alpaca.data.enums import DataFeed
                from alpaca.data.requests import StockBarsRequest
                from alpaca.data.timeframe import TimeFrame

                bars = alpaca.get_stock_bars(StockBarsRequest(symbol_or_symbols=symbol, timeframe=TimeFrame.Minute,
                                                              start=start.to_pydatetime(), feed=DataFeed.IEX)).df
                if bars is not None and not bars.empty:
                    return {"last": float(bars["close"].iloc[-1]), "high": float(bars["high"].max()),
                            "low": float(bars["low"].min()), "ts": pd.Timestamp(bars.index[-1][1]).isoformat()}
            except Exception:  # noqa: BLE001
                pass
        try:
            import yfinance as yf

            df = yf.download(symbol.replace(".", "-"), period="1d", interval="1m", progress=False, auto_adjust=False)
            if df is not None and not df.empty:
                idx = df.index.tz_convert("UTC") if df.index.tz is not None else df.index.tz_localize("UTC")
                df.index = idx
                df = df[df.index > start]
                if df.empty:
                    return None
                col = (lambda c: df[c].iloc[:, 0] if isinstance(df[c], pd.DataFrame) else df[c])
                return {"last": float(col("Close").iloc[-1]), "high": float(col("High").max()),
                        "low": float(col("Low").min()), "ts": df.index[-1].isoformat()}
        except Exception:  # noqa: BLE001
            return None
        return None

    return fetch
