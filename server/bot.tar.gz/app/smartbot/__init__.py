"""SmartBot - daily end-of-day signal bot for US stocks and ETFs (signals + paper trading only)."""
__version__ = "1.0.0"
