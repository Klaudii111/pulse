"""NYSE trading calendar (rule-based, no network).

Used to compute future time-exit dates (exit_due) and the expected latest bar
date for the staleness kill switch. Rules cover the regular NYSE holidays;
one-off closures (national days of mourning, hurricanes) are not included,
so the live staleness check allows a tolerance of one trading day.
"""
from __future__ import annotations

from datetime import date, datetime, time, timedelta
from functools import lru_cache
from zoneinfo import ZoneInfo

import pandas as pd
from pandas.tseries.holiday import (
    AbstractHolidayCalendar,
    GoodFriday,
    Holiday,
    USLaborDay,
    USMartinLutherKingJr,
    USMemorialDay,
    USPresidentsDay,
    USThanksgivingDay,
    nearest_workday,
)


class NYSEHolidayCalendar(AbstractHolidayCalendar):
    rules = [
        Holiday("NewYearsDay", month=1, day=1, observance=nearest_workday),
        USMartinLutherKingJr,
        USPresidentsDay,
        GoodFriday,
        USMemorialDay,
        Holiday("Juneteenth", month=6, day=19, start_date="2022-01-01", observance=nearest_workday),
        Holiday("IndependenceDay", month=7, day=4, observance=nearest_workday),
        USLaborDay,
        USThanksgivingDay,
        Holiday("Christmas", month=12, day=25, observance=nearest_workday),
    ]


@lru_cache(maxsize=4)
def _holidays(start_year: int, end_year: int) -> frozenset[pd.Timestamp]:
    hol = NYSEHolidayCalendar().holidays(start=f"{start_year}-01-01", end=f"{end_year}-12-31")
    # NYSE does not observe New Year's Day on the preceding Friday (Dec 31).
    return frozenset(d for d in hol if not (d.month == 12 and d.day == 31))


def trading_days(start: str | date | pd.Timestamp, end: str | date | pd.Timestamp) -> pd.DatetimeIndex:
    s, e = pd.Timestamp(start).normalize(), pd.Timestamp(end).normalize()
    hol = _holidays(s.year - 1, e.year + 1)
    days = pd.bdate_range(s, e)
    return pd.DatetimeIndex([d for d in days if d not in hol])


def is_trading_day(d: str | date | pd.Timestamp) -> bool:
    ts = pd.Timestamp(d).normalize()
    return ts.weekday() < 5 and ts not in _holidays(ts.year - 1, ts.year + 1)


def add_trading_days(d: str | date | pd.Timestamp, n: int, known: pd.DatetimeIndex | None = None) -> pd.Timestamp:
    """Return the trading day n sessions after d (n >= 0). Uses `known` dates first."""
    ts = pd.Timestamp(d).normalize()
    if n <= 0:
        return ts
    if known is not None and len(known):
        pos = known.searchsorted(ts, side="right")
        if pos + n - 1 < len(known):
            return pd.Timestamp(known[pos + n - 1])
        # continue from the last known date
        consumed = len(known) - pos
        if consumed > 0:
            ts, n = pd.Timestamp(known[-1]), n - consumed
    days = trading_days(ts + timedelta(days=1), ts + timedelta(days=int(n * 2 + 15)))
    return pd.Timestamp(days[n - 1])


def expected_last_session(now: datetime | None = None, tz: str = "America/New_York",
                          ready_after: time = time(16, 30)) -> pd.Timestamp:
    """Latest session whose daily bar should be available at `now`."""
    zone = ZoneInfo(tz)
    now = (now or datetime.now(zone)).astimezone(zone)
    d = pd.Timestamp(now.date())
    if not (is_trading_day(d) and now.time() >= ready_after):
        d = d - timedelta(days=1)
    while not is_trading_day(d):
        d = d - timedelta(days=1)
    return d


def trading_days_between(a: pd.Timestamp, b: pd.Timestamp) -> int:
    """Number of trading sessions in (a, b]."""
    if b <= a:
        return 0
    return len(trading_days(a + timedelta(days=1), b))
