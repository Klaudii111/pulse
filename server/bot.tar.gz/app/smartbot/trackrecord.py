"""`report`: live/paper track record from the journal + phase-gate check (HTML)."""
from __future__ import annotations

import html
from pathlib import Path
from typing import Any

import pandas as pd

from . import metrics as M
from .config import HORIZONS
from .journal import Journal
from .report import DISCLAIMER, equity_chart


def gate_check(nav: pd.DataFrame, outcomes: pd.DataFrame, cfg: dict[str, Any]) -> dict[str, Any]:
    """Phase gate: >= 6 months data, >= 100 signals, beats the index after costs, max DD < 15 %."""
    if nav.empty:
        return {"months": 0.0, "signals": 0, "beats_index": False, "max_dd": 0.0, "pass": False}
    e = pd.Series(nav["equity"].to_numpy(float), index=pd.to_datetime(nav["date"]))
    b = pd.Series(nav["bench_close"].to_numpy(float), index=pd.to_datetime(nav["date"]))
    months = (e.index[-1] - e.index[0]).days / 30.4
    ret, bret = e.iloc[-1] / e.iloc[0] - 1, b.iloc[-1] / b.iloc[0] - 1
    mdd = M.max_drawdown(e)
    # defensive-sleeve rebalances (cash proxy / dual momentum) are not signals with stop/target
    core = outcomes[outcomes["sleeve"] == "core"] if "sleeve" in outcomes.columns else outcomes
    n = int(len(core))
    ok = months >= 6 and n >= 100 and ret > bret and mdd > -0.15
    return {"months": months, "signals": n, "return": ret, "index_return": bret, "beats_index": ret > bret,
            "max_dd": mdd, "pass": bool(ok)}


def write_trackrecord(journal: Journal, cfg: dict[str, Any], out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    nav = journal.frame("nav")
    out = journal.frame("outcomes")
    chain = journal.verify()
    parts = [f"<p>Hash chain intact: {html.escape(str(chain))}</p>", f"<p>{html.escape(DISCLAIMER)}</p>"]
    for tr in HORIZONS + ("KRIZE",):
        n = nav[nav["track"] == tr].drop_duplicates("date", keep="last")
        o = out[(out["track"] == tr) & (out["sleeve"].fillna("core") == "core")]   # defensive sleeve excluded
        if n.empty:
            continue
        g = gate_check(n, o, cfg)
        ts = M.trade_stats(o.assign(holding_days=0)) if len(o) else {}
        e = pd.Series(n["equity"].to_numpy(float), index=pd.to_datetime(n["date"]))
        b = pd.Series(n["bench_close"].to_numpy(float), index=pd.to_datetime(n["date"]))
        img = equity_chart({tr: e}, {"SPY": b}, str(e.index[0].date()), f"{tr} track record")
        parts.append(f"<h2>{tr}</h2><img src='data:image/png;base64,{img}' style='max-width:100%'>"
                     f"<p>Months {g['months']:.1f} | closed signals {g['signals']} | return {g.get('return', 0):.2%} vs SPY "
                     f"{g.get('index_return', 0):.2%} | max DD {g['max_dd']:.2%} | hit rate {ts.get('hit_rate', 0):.1%} | "
                     f"expectancy {ts.get('expectancy_r', float('nan')):.2f} R | <b>gate {'PASSED' if g['pass'] else 'NOT passed'}</b></p>")
    doc = ("<!doctype html><html lang=cs><head><meta charset=utf-8><title>SmartBot track record</title>"
           "<style>body{font:14px system-ui;max-width:1000px;margin:auto;padding:16px;background:#fcfcfb;color:#0b0b0b}</style>"
           "</head><body><h1>SmartBot track record</h1>" + "".join(parts) + "</body></html>")
    p = out_dir / "track_record.html"
    p.write_text(doc, encoding="utf-8")
    return p
