"""Configuration and secrets loading.

`config.yaml` holds every tunable parameter; secrets come only from environment
variables / a `.env` file (python-dotenv). Nothing secret is ever stored in code.
"""
from __future__ import annotations

import copy
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config.yaml"

HORIZONS = ("DEN", "DNY", "TYDEN", "MESIC")   # published horizon tracks (PWA export)
TRACKS = HORIZONS + ("KRIZE",)                 # + defensive crisis sleeve


class ConfigError(ValueError):
    """Raised for an invalid configuration."""


def load_config(path: str | Path | None = None, overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    """Load YAML config, apply optional deep-merged overrides and validate it."""
    p = Path(path) if path else DEFAULT_CONFIG_PATH
    with p.open("r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh) or {}
    if overrides:
        cfg = deep_merge(cfg, overrides)
    cfg["_root"] = str(p.resolve().parent)
    validate_config(cfg)
    return cfg


def deep_merge(base: dict[str, Any], upd: dict[str, Any]) -> dict[str, Any]:
    """Return a new dict = base recursively updated with upd."""
    out = copy.deepcopy(base)
    for k, v in upd.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def resolve_path(cfg: dict[str, Any], rel: str | Path) -> Path:
    """Resolve a config-relative path (Windows/Linux safe)."""
    p = Path(rel)
    if p.is_absolute():
        return p
    return Path(cfg.get("_root", PROJECT_ROOT)) / p


def validate_config(cfg: dict[str, Any]) -> None:
    for key in ("general", "universe", "strategies", "tracks", "risk", "risk_profiles", "leverage", "costs"):
        if key not in cfg:
            raise ConfigError(f"config section missing: {key}")
    for name, tr in cfg["tracks"].items():
        if name not in TRACKS:
            raise ConfigError(f"unknown track {name}; allowed: {TRACKS}")
        if int(tr.get("horizon_days", 0)) < 1:
            raise ConfigError(f"track {name}: horizon_days must be >= 1")
        for s in tr.get("strategies", []):
            if s not in cfg["strategies"]:
                raise ConfigError(f"track {name}: unknown strategy {s}")
    profs = cfg["risk_profiles"]["profiles"]
    for pname, p in profs.items():
        r = float(p["risk_per_trade"])
        if not 0 < r <= 0.05:
            raise ConfigError(f"risk profile {pname}: risk_per_trade must be in (0, 5%]")
        if float(p.get("reward_risk", 2.0)) <= 0:
            raise ConfigError(f"risk profile {pname}: reward_risk must be > 0")
    esma = cfg["leverage"]["esma_max"]
    for lname, lp in cfg["leverage"]["profiles"].items():
        if float(lp["leverage"]) < 1:
            raise ConfigError(f"leverage profile {lname}: leverage must be >= 1")
        if lp.get("instrument") not in ("cash", "cfd"):
            raise ConfigError(f"leverage profile {lname}: instrument must be cash|cfd")
    for cls in ("equity", "index_major", "index_non_major", "gold", "commodity"):
        if cls not in esma:
            raise ConfigError(f"leverage.esma_max missing class {cls}")
    # M7: higher ESMA caps only for explicit index-CFD instruments; every ETF is a share CFD (5:1)
    idx_syms = set((cfg.get("index_cfds", {}) or {}).get("instruments", {}) or {})
    for sym, spec in (cfg["universe"].get("etfs") or {}).items():
        cls = spec.get("class", "equity")
        if cls != "equity" and sym not in idx_syms:
            raise ConfigError(f"ETF {sym}: class {cls} not allowed - ETFs are share CFDs (class equity, 5:1); "
                              f"use an explicit index_cfds instrument (e.g. US500) for index leverage")
    for sym, spec in ((cfg.get("index_cfds", {}) or {}).get("instruments", {}) or {}).items():
        if sym in (cfg["universe"].get("etfs") or {}):
            raise ConfigError(f"index CFD {sym} must use a symbol distinct from the ETFs")
        if spec.get("class") not in esma:
            raise ConfigError(f"index CFD {sym}: unknown class {spec.get('class')}")
    if cfg["general"].get("mode") not in ("paper", "live"):
        raise ConfigError("general.mode must be paper|live")


@dataclass(frozen=True)
class Secrets:
    """Secrets loaded from the environment / .env (never from code or config)."""

    alpaca_key_id: str | None = None
    alpaca_secret_key: str | None = None
    alpaca_base_url: str | None = None
    discord_webhook_url: str | None = None
    discord_webhooks: dict[str, str] = field(default_factory=dict)
    sec_user_agent: str | None = None
    openfigi_api_key: str | None = None

    def webhook_for(self, horizon: str) -> str | None:
        """Per-horizon webhook (DISCORD_WEBHOOK_URL_<HORIZON>) with fallback to the default."""
        return self.discord_webhooks.get(horizon) or self.discord_webhook_url

    def masked(self) -> dict[str, str]:
        def m(v: str | None) -> str:
            if not v:
                return "<not set>"
            return v[:4] + "..." if len(v) > 8 else "***"
        return {
            "ALPACA_KEY_ID": m(self.alpaca_key_id),
            "ALPACA_SECRET_KEY": m(self.alpaca_secret_key),
            "DISCORD_WEBHOOK_URL": m(self.discord_webhook_url),
            "SEC_USER_AGENT": self.sec_user_agent or "<not set>",
        }


def load_secrets(env_file: str | Path | None = None) -> Secrets:
    """Load secrets from a .env file (if present) and the process environment."""
    try:
        from dotenv import load_dotenv
    except ImportError:  # pragma: no cover - dependency is in requirements
        load_dotenv = None
    if load_dotenv is not None:
        path = Path(env_file) if env_file else PROJECT_ROOT / ".env"
        if path.exists():
            load_dotenv(path, override=False)
    hooks = {}
    for h in TRACKS:
        v = os.environ.get(f"DISCORD_WEBHOOK_URL_{h}")
        if v:
            hooks[h] = v.strip()

    def env(name: str) -> str | None:
        v = os.environ.get(name)
        return v.strip() if v and v.strip() else None

    return Secrets(
        alpaca_key_id=env("ALPACA_KEY_ID"),
        alpaca_secret_key=env("ALPACA_SECRET_KEY"),
        alpaca_base_url=env("ALPACA_BASE_URL"),
        discord_webhook_url=env("DISCORD_WEBHOOK_URL"),
        discord_webhooks=hooks,
        sec_user_agent=env("SEC_USER_AGENT"),
        openfigi_api_key=env("OPENFIGI_API_KEY"),
    )
