"""Causal technical indicators on wide DataFrames (dates x symbols).

Every function's value at row t depends only on rows <= t, which is what the
no-look-ahead tests verify.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def sma(df: pd.DataFrame, n: int) -> pd.DataFrame:
    return df.rolling(n, min_periods=n).mean()


def total_return(close: pd.DataFrame, lookback: int, skip: int = 0) -> pd.DataFrame:
    """Return from t-lookback to t-skip (e.g. 12-1 momentum: lookback=252, skip=21)."""
    return close.shift(skip) / close.shift(lookback) - 1.0


def true_range(high: pd.DataFrame, low: pd.DataFrame, close: pd.DataFrame) -> pd.DataFrame:
    prev = close.shift(1)
    a = high - low
    b = (high - prev).abs()
    c = (low - prev).abs()
    tr = np.fmax(np.fmax(a.to_numpy(), b.to_numpy()), c.to_numpy())  # fmax ignores NaN prev close
    return pd.DataFrame(tr, index=close.index, columns=close.columns).where(close.notna())


def atr(high: pd.DataFrame, low: pd.DataFrame, close: pd.DataFrame, n: int = 14) -> pd.DataFrame:
    """Simple-average ATR (exactly causal under truncation)."""
    tr = true_range(high, low, close)
    return tr.rolling(n, min_periods=n).mean()


def log_returns(close: pd.DataFrame) -> pd.DataFrame:
    return np.log(close / close.shift(1))


def realized_vol(close: pd.DataFrame, n: int) -> pd.DataFrame:
    """Annualised close-to-close volatility."""
    return log_returns(close).rolling(n, min_periods=max(5, int(n * 0.8))).std() * np.sqrt(252.0)


def rsi(close: pd.DataFrame, n: int = 2) -> pd.DataFrame:
    """Wilder RSI (recursive smoothing; causal)."""
    d = close.diff()
    up = d.clip(lower=0.0)
    dn = (-d).clip(lower=0.0)
    au = up.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()
    ad = dn.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()
    rs = au / ad.replace(0.0, np.nan)
    out = 100.0 - 100.0 / (1.0 + rs)
    out = out.where(~((ad == 0) & (au > 0)), 100.0)
    return out.where(close.notna())


def ibs(high: pd.DataFrame, low: pd.DataFrame, close: pd.DataFrame) -> pd.DataFrame:
    """Internal bar strength: (C - L) / (H - L), 0.5 when H == L."""
    rng = (high - low)
    out = (close - low) / rng.replace(0.0, np.nan)
    return out.fillna(0.5).where(close.notna())


def donchian_high(high: pd.DataFrame, n: int) -> pd.DataFrame:
    """Highest high of the previous n days (excluding today)."""
    return high.shift(1).rolling(n, min_periods=n).max()


def donchian_low(low: pd.DataFrame, n: int) -> pd.DataFrame:
    return low.shift(1).rolling(n, min_periods=n).min()


def dollar_volume(close: pd.DataFrame, volume: pd.DataFrame, n: int = 20) -> pd.DataFrame:
    return (close * volume).rolling(n, min_periods=max(5, int(n * 0.8))).mean()


def pct_rank_rows(df: pd.DataFrame) -> pd.DataFrame:
    """Cross-sectional percentile rank per row (uses only that row)."""
    return df.rank(axis=1, pct=True)
