"""Risk layer - the part whose job is to REDUCE LOSSES.

Rules (all configurable in config.yaml -> risk):
  a. market regime filter         regime_on(), select_defensive()
  b. volatility targeting         risk-based sizing (stop distance is ATR based) + portfolio_vol() scaler
  c. ATR stops / trailing / target initial_stop(), trail_stop(), target_price(), resolve_intraday_exit()
  d. position / sector / count caps position_notional(), sector check in the engine
  e. correlation filter           correlated_with()
  f. drawdown circuit breaker     CircuitBreaker
  g. liquidity filter             liquidity_mask()
  h. earnings blackout            earnings_blackout_matrix()
  i. cooldown, max new entries    engine (uses RiskSettings.cooldown_days)
  j. kill switch / sanity checks  KillSwitch, check_staleness()
  +  leverage caps (ESMA), open-risk cap, daily/weekly loss limits (LossLimits)
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from . import tradingcal

# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------


@dataclass
class RiskSettings:
    regime_sma: int = 200
    regime_hysteresis: float = 0.0
    risk_off_max_gross: float = 0.30
    risk_off_max_leverage: float = 1.0
    defensive_assets: tuple[str, ...] = ("TLT", "GLD", "IEF")
    defensive_lookback: int = 252
    defensive_top_n: int = 1
    defensive_max_weight: float = 0.70
    target_vol: float = 0.11
    vol_windows: tuple[int, int] = (20, 60)
    cov_window: int = 60
    max_position_pct: float = 0.25
    min_position_pct: float = 0.01
    max_sector_pct: float = 0.25
    max_positions: int = 15
    rebalance_band: float = 0.25
    atr_days: int = 14
    skip_gap_through_stop: bool = True
    corr_window: int = 60
    max_corr: float = 0.80
    halve_dd: float = -0.10
    cash_dd: float = -0.15
    halve_reset_dd: float = -0.05
    min_days_in_cash: int = 10
    reentry_sma_days: int = 20
    reentry_max_loss: float = 0.03
    hard_stop_dd: float = -0.20
    min_price: float = 5.0
    min_dollar_volume: float = 20e6
    liquidity_window: int = 20
    earnings_enabled: bool = True
    earnings_blackout_days: int = 3
    cooldown_days: int = 10
    max_open_risk_r: float = 3.0
    daily_loss_r: float = 2.0
    weekly_loss_r: float = 4.0
    breadth: dict[str, Any] = field(default_factory=dict)
    vix_term: dict[str, Any] = field(default_factory=dict)
    ec_filter: bool = True
    ec_sma_days: int = 50
    ec_cut: float = 0.5
    kill: dict[str, float] = field(default_factory=dict)
    esma_max: dict[str, float] = field(default_factory=lambda: {
        "equity": 5, "index_major": 20, "index_non_major": 10, "gold": 20, "commodity": 10})
    margin_stop_out_level: float = 0.50

    @classmethod
    def from_config(cls, cfg: dict[str, Any]) -> "RiskSettings":
        r = cfg["risk"]
        reg, siz, cb, liq = r["regime"], r["sizing"], r["circuit_breaker"], r["liquidity"]
        vw = siz.get("vol_windows", [20, 60])
        return cls(
            regime_sma=int(reg.get("sma_days", 200)),
            regime_hysteresis=float(reg.get("hysteresis_pct", 0.0)),
            risk_off_max_gross=float(reg.get("risk_off_max_gross", 0.30)),
            risk_off_max_leverage=float(reg.get("risk_off_max_leverage", 1.0)),
            defensive_assets=tuple(reg.get("defensive_assets", ["TLT", "GLD", "IEF"])),
            defensive_lookback=int(reg.get("defensive_lookback_days", 252)),
            defensive_top_n=int(reg.get("defensive_top_n", 1)),
            defensive_max_weight=float(reg.get("defensive_max_weight", 0.70)),
            target_vol=float(siz.get("target_vol_annual", 0.11)),
            vol_windows=(int(vw[0]), int(vw[1])),
            cov_window=int(siz.get("cov_window", 60)),
            max_position_pct=float(siz.get("max_position_pct", 0.25)),
            min_position_pct=float(siz.get("min_position_pct", 0.01)),
            max_sector_pct=float(siz.get("max_sector_pct", 0.25)),
            max_positions=int(siz.get("max_positions", 15)),
            rebalance_band=float(siz.get("rebalance_band", 0.25)),
            atr_days=int(r["stops"].get("atr_days", 14)),
            skip_gap_through_stop=bool(r["stops"].get("skip_entry_if_gap_through_stop", True)),
            corr_window=int(r["correlation"].get("window", 60)),
            max_corr=float(r["correlation"].get("max_corr", 0.8)),
            halve_dd=float(cb.get("halve_dd", -0.10)),
            cash_dd=float(cb.get("cash_dd", -0.15)),
            halve_reset_dd=float(cb.get("halve_reset_dd", -0.05)),
            min_days_in_cash=int(cb.get("min_days_in_cash", 10)),
            reentry_sma_days=int(cb.get("reentry_sma_days", 20)),
            reentry_max_loss=float(cb.get("reentry_max_loss", 0.03)),
            hard_stop_dd=float(cb.get("hard_stop_dd", -0.20)),
            min_price=float(liq.get("min_price", 5.0)),
            min_dollar_volume=float(liq.get("min_dollar_volume", 20e6)),
            liquidity_window=int(liq.get("window", 20)),
            earnings_enabled=bool(r["earnings"].get("enabled", True)),
            earnings_blackout_days=int(r["earnings"].get("blackout_days", 3)),
            cooldown_days=int(r["cooldown"].get("days_after_stop", 10)),
            max_open_risk_r=float(r["open_risk"].get("max_open_risk_r", 3.0)),
            daily_loss_r=float(r["loss_limits"].get("daily_r", 2.0)),
            weekly_loss_r=float(r["loss_limits"].get("weekly_r", 4.0)),
            breadth=dict(reg.get("breadth", {}) or {}),
            vix_term=dict(reg.get("vix_term", {}) or {}),
            ec_filter=bool(r.get("equity_curve_filter", {}).get("enabled", False)),
            ec_sma_days=int(r.get("equity_curve_filter", {}).get("sma_days", 50)),
            ec_cut=float(r.get("equity_curve_filter", {}).get("cut", 0.5)),
            kill={k: float(v) for k, v in r["kill_switch"].items()},
            esma_max={k: float(v) for k, v in cfg["leverage"]["esma_max"].items()},
            margin_stop_out_level=float(cfg["leverage"].get("margin_stop_out_level", 0.5)),
        )


# ---------------------------------------------------------------------------
# a. Regime
# ---------------------------------------------------------------------------
def regime_on(bench_close: pd.Series, sma_days: int = 200) -> pd.Series:
    """True when benchmark close > its SMA (risk-on). Warm-up / missing => risk-off."""
    ma = bench_close.rolling(sma_days, min_periods=sma_days).mean()
    return (bench_close > ma).fillna(False)


def breadth_stats(close: pd.DataFrame, stock_cols: list[str], sma_days: int = 200,
                  nh_days: int = 252) -> pd.DataFrame:
    """Market breadth: % of stocks above their SMA and (new highs - new lows) / valid stocks."""
    c = close[stock_cols] if stock_cols else close
    valid_ma = c.rolling(sma_days, min_periods=sma_days).mean()
    have = valid_ma.notna() & c.notna()
    above = ((c > valid_ma) & have).sum(axis=1) / have.sum(axis=1).replace(0, np.nan)
    hi = c.rolling(nh_days, min_periods=nh_days).max()
    lo = c.rolling(nh_days, min_periods=nh_days).min()
    have_h = hi.notna() & c.notna()
    nh = ((c >= hi) & have_h).sum(axis=1)
    nl = ((c <= lo) & have_h).sum(axis=1)
    nhnl = (nh - nl).rolling(10, min_periods=1).mean() / have_h.sum(axis=1).replace(0, np.nan)
    return pd.DataFrame({"pct_above": above, "nhnl": nhnl})


def hysteresis_regime(gap: np.ndarray, band: float) -> np.ndarray:
    """risk-on when gap > +band, risk-off when gap < -band, otherwise keep the previous state.

    Path-dependent but causal (depends only on past values). NaN (warm-up) => risk-off.
    """
    out = np.zeros(len(gap), dtype=bool)
    state = False
    for k, g in enumerate(gap):
        if not np.isfinite(g):
            state = False
        elif g > band:
            state = True
        elif g < -band:
            state = False
        out[k] = state
    return out


def composite_regime(bench_close: pd.Series, sma_days: int, breadth: pd.DataFrame | None = None,
                     breadth_cfg: dict[str, Any] | None = None, vix: pd.DataFrame | None = None,
                     vix_cfg: dict[str, Any] | None = None, hysteresis: float = 0.0) -> pd.DataFrame:
    """SPY-vs-SMA regime, weakened/strengthened by breadth and the VIX term structure.

    * breadth weakens: SPY above SMA but pct_above < weaken_below            -> risk-off
    * breadth strengthens: SPY within strengthen_max_gap below SMA, pct_above
      > strengthen_above and NH-NL > 0                                        -> risk-on
    * VIX backwardation (VIX / VIX3M > ratio)                                -> risk-off
    Missing inputs degrade gracefully to the plain SPY rule.
    """
    ma = bench_close.rolling(sma_days, min_periods=sma_days).mean()
    gap = bench_close / ma - 1.0
    base = hysteresis_regime(gap.to_numpy(dtype=float), hysteresis)
    base = pd.Series(base, index=bench_close.index)
    out = pd.DataFrame({"spy_on": base, "gap": gap}, index=bench_close.index)
    reg = base.copy()
    bc = breadth_cfg or {}
    if breadth is not None and bc.get("enabled", False):
        b = breadth.reindex(bench_close.index)
        weak = b["pct_above"] < float(bc.get("weaken_below", 0.40))
        strong = (b["pct_above"] > float(bc.get("strengthen_above", 0.65))) & (b["nhnl"] > 0) & \
            (gap >= float(bc.get("strengthen_max_gap", -0.02))) & ma.notna()
        reg = (reg & ~weak.fillna(False)) | strong.fillna(False)
        out["breadth_pct_above"] = b["pct_above"]
        out["breadth_nhnl"] = b["nhnl"]
    vc = vix_cfg or {}
    if vix is not None and vc.get("enabled", False) and {"vix", "vix3m"} <= set(vix.columns):
        v = vix.reindex(bench_close.index).ffill(limit=3)
        back = (v["vix"] / v["vix3m"]) > float(vc.get("backwardation_ratio", 1.0))
        reg = reg & ~back.fillna(False)
        out["vix_ratio"] = v["vix"] / v["vix3m"]
    out["regime_on"] = reg.astype(bool)
    return out


def select_defensive(ret_12m: dict[str, float], cash_ret_12m: float, top_n: int = 1) -> list[str]:
    """Antonacci dual momentum: best assets by 12m return that also beat cash (T-bills)."""
    ranked = sorted(((r, s) for s, r in ret_12m.items() if r is not None and math.isfinite(r)), reverse=True)
    cash = cash_ret_12m if math.isfinite(cash_ret_12m) else 0.0
    return [s for r, s in ranked[:top_n] if r > cash]


# ---------------------------------------------------------------------------
# c. Stops and targets
# ---------------------------------------------------------------------------
def initial_stop(entry_ref: float, atr_value: float, mult: float) -> float:
    return entry_ref - mult * atr_value


def trail_stop(current_stop: float, highest_close: float, atr_value: float, mult: float) -> float:
    """Chandelier trailing stop; it can only move UP."""
    if not math.isfinite(atr_value):
        return current_stop
    return max(current_stop, highest_close - mult * atr_value)


def target_price(entry_ref: float, stop: float, rr: float | None) -> float | None:
    if rr is None or rr <= 0:
        return None
    return entry_ref + rr * (entry_ref - stop)


def resolve_intraday_exit(open_: float, high: float, low: float, stop: float,
                          target: float | None) -> tuple[str, float] | None:
    """Resting stop (sell-stop) and target (sell-limit) orders on one daily bar.

    * gap below stop  -> filled at the open (worse than the stop)
    * gap above target -> filled at the open (better than the target)
    * both inside the bar's range -> STOP assumed first (conservative)
    """
    if not (math.isfinite(open_) and math.isfinite(low) and math.isfinite(high)):
        return None
    if open_ <= stop:
        return ("stop", open_)
    if target is not None and open_ >= target:
        return ("target", open_)
    hit_stop = low <= stop
    hit_target = target is not None and high >= target
    if hit_stop:
        return ("stop", stop)
    if hit_target:
        return ("target", float(target))  # type: ignore[arg-type]
    return None


# ---------------------------------------------------------------------------
# b/d. Sizing and leverage
# ---------------------------------------------------------------------------
def effective_leverage(profile_leverage: float, regime_is_on: bool, risk_off_cap: float = 1.0) -> float:
    """Leverage profile, auto-capped (default 1x) in the risk-off regime."""
    return profile_leverage if regime_is_on else min(profile_leverage, risk_off_cap)


def asset_leverage_cap(asset_class: str, lev_eff: float, esma_max: dict[str, float]) -> float:
    """Never exceed the ESMA cap of the asset class."""
    return min(lev_eff, float(esma_max.get(asset_class, 5.0)))


def position_notional(risk_per_trade: float, entry: float, stop: float, lev_eff_asset: float,
                      max_position_pct: float) -> float:
    """Notional (fraction of equity) so that loss at the stop <= risk_per_trade.

    Capped by max_position_pct x (asset-capped) effective leverage.
    Returns 0 when the stop is invalid.
    """
    if not (math.isfinite(entry) and math.isfinite(stop)) or entry <= 0 or stop >= entry:
        return 0.0
    dist = (entry - stop) / entry
    return float(min(risk_per_trade / dist, max_position_pct * lev_eff_asset))


def leverage_line(risk_per_trade: float, entry: float, stop: float, target: float | None, leverage: float,
                  asset_class: str, esma_max: dict[str, float], max_position_pct: float,
                  regime_is_on: bool, risk_off_cap: float = 1.0) -> dict[str, float]:
    """Per-signal sizing for a given account leverage (used in Discord/export)."""
    lev = asset_leverage_cap(asset_class, effective_leverage(leverage, regime_is_on, risk_off_cap), esma_max)
    n = position_notional(risk_per_trade, entry, stop, lev, max_position_pct)
    dist = (entry - stop) / entry if entry > 0 else 0.0
    gain = ((target - entry) / entry) if (target and entry > 0) else 0.0
    return {"leverage": leverage, "effective_leverage": lev, "notional_pct": n, "loss_at_stop_pct": n * dist,
            "gain_at_target_pct": n * gain}


def portfolio_vol(weights: np.ndarray, rets: np.ndarray) -> float:
    """Annualised vol of a weight vector given a (window, k) daily return matrix.

    Falls back to the conservative sum(|w| * sigma) (correlation 1) when data is short.
    """
    w = np.asarray(weights, dtype=float)
    if w.size == 0:
        return 0.0
    r = rets[np.all(np.isfinite(rets), axis=1)] if rets.size else rets
    if r.shape[0] < 20 or w.size == 1:
        sig = np.nanstd(rets, axis=0) * np.sqrt(252.0) if rets.size else np.zeros_like(w)
        sig = np.where(np.isfinite(sig), sig, 0.5)
        return float(np.sum(np.abs(w) * sig))
    cov = np.cov(r, rowvar=False) * 252.0
    return float(np.sqrt(max(w @ cov @ w, 0.0)))


# ---------------------------------------------------------------------------
# e. Correlation
# ---------------------------------------------------------------------------
def correlated_with(candidate: np.ndarray, holdings: dict[str, np.ndarray], max_corr: float) -> str | None:
    """Return the first holding whose return correlation with the candidate exceeds max_corr."""
    if not holdings:
        return None
    for sym, r in holdings.items():
        m = np.isfinite(candidate) & np.isfinite(r)
        n = int(m.sum())
        if n < 20:
            continue
        a, b = candidate[m], r[m]
        a = a - a.mean()
        b = b - b.mean()
        den = math.sqrt(float(a @ a) * float(b @ b))
        if den <= 0:
            continue
        if float(a @ b) / den > max_corr:
            return sym
    return None


# ---------------------------------------------------------------------------
# f. Circuit breaker
# ---------------------------------------------------------------------------
@dataclass
class CircuitBreaker:
    """Drawdown circuit breaker with a hard cap measured from the TRUE equity peak (never reset).

    normal  -> halved   when drawdown <= halve_dd (-10 %)
    any     -> cash     when drawdown <= cash_dd (-15 %)
    halved  -> normal   when drawdown recovers above halve_reset_dd (-5 %)
    cash    -> reentry  only when ALL hold: regime risk-on, >= min_days_in_cash sessions in cash,
                        the sleeve equity >= its `reentry_sma_days` average and the benchmark is above
                        its 20d average (recovery confirmed)
    reentry -> cash     when equity falls `reentry_max_loss` (3 %) below the re-entry equity
    reentry -> normal   when drawdown from the true peak recovers above halve_reset_dd
    any     -> locked   when drawdown <= hard_stop_dd (-20 %): permanent cash, manual reset only
    `reentry` trades at half exposure. The peak is the all-time high of the sleeve equity, so the
    breaker and the reported max drawdown use the same reference.
    """

    halve_dd: float = -0.10
    cash_dd: float = -0.15
    halve_reset_dd: float = -0.05
    min_days_in_cash: int = 10
    reentry_sma_days: int = 20
    reentry_max_loss: float = 0.03
    hard_stop_dd: float = -0.20
    state: str = "normal"
    peak: float = 0.0
    days_in_state: int = 0
    reentry_equity: float = 0.0

    MULT = {"normal": 1.0, "halved": 0.5, "reentry": 0.5, "cash": 0.0, "locked": 0.0}

    @property
    def multiplier(self) -> float:
        return self.MULT[self.state]

    def update(self, equity: float, regime_is_on: bool, equity_hist: list[float] | None = None,
               bench_ok: bool = True) -> str | None:
        """Update with today's close equity; returns an event string on a state change."""
        if equity > self.peak:
            self.peak = equity
        dd = equity / self.peak - 1.0 if self.peak > 0 else 0.0
        old = self.state
        self.days_in_state += 1
        if self.state == "locked" or dd <= self.hard_stop_dd:
            # HARD cap: the track has lost more than allowed from its true peak -> stays in cash until a
            # human resets it (delete the track's saved state); the phase gate is failed anyway
            self.state = "locked"
        elif self.state == "cash":
            hist = equity_hist or []
            n = self.reentry_sma_days
            ec_ok = len(hist) >= n and equity >= (sum(hist[-n:]) / n) * (1.0 - 1e-9)  # flat cash == average
            if regime_is_on and bench_ok and ec_ok and self.days_in_state >= self.min_days_in_cash:
                self.state = "reentry"
                self.reentry_equity = equity
        elif self.state == "reentry":
            if equity <= self.reentry_equity * (1.0 - self.reentry_max_loss):
                self.state = "cash"
            elif dd > self.halve_reset_dd:
                self.state = "normal"
        elif dd <= self.cash_dd:
            self.state = "cash"
        elif self.state == "normal" and dd <= self.halve_dd:
            self.state = "halved"
        elif self.state == "halved" and dd > self.halve_reset_dd:
            self.state = "normal"
        if self.state != old:
            self.days_in_state = 0
            return f"circuit_breaker {old}->{self.state} (dd {dd:.1%})"
        return None

    def to_dict(self) -> dict[str, Any]:
        return {"state": self.state, "peak": self.peak, "days_in_state": self.days_in_state,
                "reentry_equity": self.reentry_equity}

    def load(self, d: dict[str, Any]) -> None:
        self.state = d.get("state", "normal")
        self.peak = float(d.get("peak", 0.0))
        self.days_in_state = int(d.get("days_in_state", 0))
        self.reentry_equity = float(d.get("reentry_equity", 0.0))


# ---------------------------------------------------------------------------
# Equity-curve filter
# ---------------------------------------------------------------------------
def equity_curve_multiplier(equity_hist: list[float], sma_days: int = 50, cut: float = 0.5) -> float:
    """`cut` when the sleeve's equity is below its own `sma_days` average, else 1.0."""
    if len(equity_hist) < sma_days:
        return 1.0
    avg = sum(equity_hist[-sma_days:]) / sma_days
    return cut if equity_hist[-1] < avg else 1.0


# ---------------------------------------------------------------------------
# Daily / weekly loss limits
# ---------------------------------------------------------------------------
@dataclass
class LossLimits:
    daily_r: float = 2.0
    weekly_r: float = 4.0
    week_key: str = ""
    week_start_equity: float = 0.0
    prev_equity: float = 0.0
    blocked_until_week: str = ""

    def update(self, date: pd.Timestamp, equity: float, risk_per_trade: float) -> tuple[bool, str | None]:
        """Call at each close. Returns (block_new_entries_for_next_session, reason)."""
        iso = date.isocalendar()
        key = f"{iso[0]}-W{iso[1]:02d}"
        if key != self.week_key:
            self.week_key = key
            self.week_start_equity = self.prev_equity if self.prev_equity > 0 else equity
        reason = None
        day_pnl = equity / self.prev_equity - 1.0 if self.prev_equity > 0 else 0.0
        week_pnl = equity / self.week_start_equity - 1.0 if self.week_start_equity > 0 else 0.0
        self.prev_equity = equity
        if week_pnl <= -self.weekly_r * risk_per_trade:
            self.blocked_until_week = key
        if self.blocked_until_week == key:
            reason = f"weekly loss limit ({week_pnl:.2%})"
        elif day_pnl <= -self.daily_r * risk_per_trade:
            reason = f"daily loss limit ({day_pnl:.2%})"
        return reason is not None, reason

    def to_dict(self) -> dict[str, Any]:
        return dict(week_key=self.week_key, week_start_equity=self.week_start_equity,
                    prev_equity=self.prev_equity, blocked_until_week=self.blocked_until_week)

    def load(self, d: dict[str, Any]) -> None:
        for k, v in d.items():
            setattr(self, k, v)


# ---------------------------------------------------------------------------
# g. Liquidity, h. earnings
# ---------------------------------------------------------------------------
def liquidity_mask(close: pd.DataFrame, volume: pd.DataFrame, min_price: float, min_dollar_volume: float,
                   window: int = 20) -> pd.DataFrame:
    dv = (close * volume).rolling(window, min_periods=max(5, int(window * 0.8))).mean()
    return ((close > min_price) & (dv > min_dollar_volume)).fillna(False)


def earnings_blackout_matrix(earnings: pd.DataFrame | None, dates: pd.DatetimeIndex, symbols: list[str],
                             blackout_days: int) -> np.ndarray | None:
    """bool (T, N): True when an earnings date falls within the next `blackout_days` sessions.

    Earnings dates are scheduled in advance, so this is known at t. Returns None when no
    calendar is available (rule degrades gracefully).
    """
    if earnings is None or earnings.empty:
        return None
    T, N = len(dates), len(symbols)
    out = np.zeros((T, N), dtype=bool)
    col = {s: j for j, s in enumerate(symbols)}
    for sym, d in zip(earnings["symbol"].astype(str), pd.to_datetime(earnings["date"])):
        j = col.get(sym)
        if j is None:
            continue
        if d > dates[-1]:  # beyond the data: count future NYSE sessions (known calendar)
            k = T - 1 + tradingcal.trading_days_between(dates[-1], pd.Timestamp(d))
        else:
            k = int(dates.searchsorted(d))  # index of earnings session (or next session)
        lo = max(0, k - blackout_days)
        if lo < T:
            out[lo:min(k, T), j] = True   # entries on t in [k-3, k-1] would hold through earnings
    return out


# ---------------------------------------------------------------------------
# j. Kill switch / sanity checks
# ---------------------------------------------------------------------------
@dataclass
class KillSwitch:
    """Data sanity checks. When triggered: send NO signals, alert instead."""

    missing_window: int = 20
    max_missing_frac: float = 0.05
    absurd_jump: float = 0.50
    max_quarantined_frac: float = 0.02
    benchmark_max_jump: float = 0.15
    spike_lookback: int = 20
    spike_mult: float = 4.0
    spike_min_frac: float = 0.15
    spike_min_count: int = 10
    min_symbols: int = 5

    @classmethod
    def from_settings(cls, s: RiskSettings) -> "KillSwitch":
        k = s.kill
        return cls(
            missing_window=int(k.get("missing_window", 20)), max_missing_frac=k.get("max_missing_frac", 0.05),
            absurd_jump=k.get("absurd_jump", 0.5), max_quarantined_frac=k.get("max_quarantined_frac", 0.02),
            benchmark_max_jump=k.get("benchmark_max_jump", 0.15), spike_lookback=int(k.get("spike_lookback", 20)),
            spike_mult=k.get("spike_mult", 4.0), spike_min_frac=k.get("spike_min_frac", 0.15),
            spike_min_count=int(k.get("spike_min_count", 10)),
            min_symbols=int(k.get("min_symbols", 5)),
        )

    def precompute(self, close: np.ndarray, bench_col: int) -> dict[str, np.ndarray]:
        """Vectorised daily diagnostics (causal)."""
        T, N = close.shape
        valid = np.isfinite(close)
        with np.errstate(all="ignore"):
            prev = np.vstack([np.full((1, N), np.nan), close[:-1]])
            jump = np.abs(close / prev - 1.0)
        quarantine = np.nan_to_num(jump, nan=0.0) > self.absurd_jump
        # missing: among symbols alive W days ago and still alive later, fraction of NaN cells in (t-W, t]
        W = self.missing_window
        cs = np.vstack([np.zeros((1, N)), np.cumsum(~valid, axis=0)])
        missing_frac = np.zeros(T)
        ever = np.maximum.accumulate(valid, axis=0)
        for t in range(T):
            a = max(0, t - W + 1)
            alive = ever[a]  # had data at or before window start
            if alive.sum() == 0:
                continue
            miss = cs[t + 1] - cs[a]
            # ignore symbols that have permanently stopped (delisted): their misses are not data errors
            stopped = ~valid[a:t + 1].any(axis=0)
            cols = alive & ~stopped
            if cols.sum():
                missing_frac[t] = miss[cols].sum() / (cols.sum() * (t - a + 1))
        bench_jump = np.nan_to_num(jump[:, bench_col], nan=0.0)
        # today's bar missing for symbols that had one yesterday (a one-day download outage is diluted
        # below the threshold by the window average above: 100 % missing today / 20 days = 5 %)
        had = np.vstack([np.zeros((1, N), dtype=bool), valid[:-1]])
        with np.errstate(all="ignore"):
            missing_today = np.where(had.sum(axis=1) > 0, (had & ~valid).sum(axis=1) / had.sum(axis=1), 0.0)
        return {"quarantine": quarantine, "missing_frac": missing_frac, "bench_jump": bench_jump,
                "n_valid": valid.sum(axis=1), "missing_today": missing_today}

    def check(self, t: int, diag: dict[str, np.ndarray], raw_count: np.ndarray | None,
              n_universe: int) -> str | None:
        """Return a reason string when signals must be suppressed on day t."""
        if diag["n_valid"][t] < self.min_symbols:
            return f"only {int(diag['n_valid'][t])} symbols with data"
        if diag["missing_frac"][t] > self.max_missing_frac:
            return f"missing bars {diag['missing_frac'][t]:.1%} > {self.max_missing_frac:.0%}"
        mt = diag.get("missing_today")
        if mt is not None and mt[t] > self.max_missing_frac:
            return f"missing bars today {mt[t]:.1%} > {self.max_missing_frac:.0%}"
        if diag["bench_jump"][t] > self.benchmark_max_jump:
            return f"benchmark moved {diag['bench_jump'][t]:.1%} in one day"
        nq = int(diag["quarantine"][t].sum())
        if n_universe and nq / n_universe > self.max_quarantined_frac:
            return f"{nq} symbols with absurd price jumps"
        if raw_count is not None and t > 0:
            hist = raw_count[max(0, t - self.spike_lookback):t]
            med = float(np.median(hist)) if len(hist) else 0.0
            today = int(raw_count[t])
            if today > max(self.spike_mult * med, self.spike_min_frac * n_universe, self.spike_min_count):
                return f"signal count spike {today} vs median {med:.0f}"
        return None


def check_staleness(last_bar: pd.Timestamp, expected: pd.Timestamp, max_stale_trading_days: int = 1) -> str | None:
    """Live only: kill when the newest bar is older than expected by > tolerance sessions."""
    lag = tradingcal.trading_days_between(pd.Timestamp(last_bar), pd.Timestamp(expected))
    if lag > max_stale_trading_days:
        return f"stale data: last bar {pd.Timestamp(last_bar).date()} expected {pd.Timestamp(expected).date()}"
    return None
