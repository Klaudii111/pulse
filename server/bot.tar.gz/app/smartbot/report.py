"""Self-contained HTML backtest report (matplotlib PNGs base64-embedded) + CSV exports."""
from __future__ import annotations

import base64
import html
import io
import math
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from .backtest import BacktestOutput  # noqa: E402
from .config import HORIZONS  # noqa: E402

# reference categorical palette (fixed order) + neutral for benchmarks
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
NEUTRAL = "#8a8985"
NEUTRAL2 = "#52514e"
SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
GRID = "#e4e3df"

DISCLAIMER = ("Minulé výsledky ani backtest nezaručují budoucí výsledky. Žádná strategie nemůže zaručit "
              "trvale rostoucí kapitál. Automaticky generovaný výstup, nejde o investiční doporučení na míru. "
              "CFD/páka: většina retailových účtů s pákou prodělává.")


def _style(ax: Any) -> None:
    ax.set_facecolor(SURFACE)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    for sp in ("left", "bottom"):
        ax.spines[sp].set_color(GRID)
    ax.tick_params(colors=INK2, labelsize=8)
    ax.grid(True, color=GRID, linewidth=0.6)
    ax.set_axisbelow(True)


def _png(fig: Any) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, bbox_inches="tight", facecolor=SURFACE)
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def equity_chart(series: dict[str, pd.Series], bench: dict[str, pd.Series], split: str, title: str) -> str:
    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(9.5, 5.2), sharex=True, gridspec_kw={"height_ratios": [3, 1.2]})
    fig.patch.set_facecolor(SURFACE)
    for k, (name, s) in enumerate(series.items()):
        s = s.dropna()
        if s.empty:
            continue
        ax.plot(s.index, s / s.iloc[0] * 100, color=SERIES[k % len(SERIES)], linewidth=1.6, label=name)
        dd = s / s.cummax() - 1
        ax2.plot(dd.index, dd * 100, color=SERIES[k % len(SERIES)], linewidth=1.0)
    for k, (name, s) in enumerate(bench.items()):
        s = s.dropna()
        ax.plot(s.index, s / s.iloc[0] * 100, color=NEUTRAL if k == 0 else NEUTRAL2, linewidth=1.2,
                linestyle="--" if k else "-", label=name)
    ax.set_yscale("log")
    from matplotlib.ticker import NullFormatter, ScalarFormatter

    ax.yaxis.set_major_formatter(ScalarFormatter())
    ax.yaxis.set_minor_formatter(NullFormatter())
    for a in (ax, ax2):
        _style(a)
        a.axvline(pd.Timestamp(split), color=INK2, linewidth=0.8, linestyle=":")
    ax.text(pd.Timestamp(split), ax.get_ylim()[1], "  out-of-sample", color=INK2, fontsize=8, va="top")
    ax.set_title(title, color=INK, fontsize=11, loc="left")
    ax.set_ylabel("index (start = 100, log)", color=INK2, fontsize=8)
    ax2.set_ylabel("drawdown %", color=INK2, fontsize=8)
    ax.legend(frameon=False, fontsize=8, ncol=3, loc="upper left")
    return _png(fig)


def weights_chart(w: pd.DataFrame, title: str) -> str:
    fig, ax = plt.subplots(figsize=(9.5, 2.6))
    fig.patch.set_facecolor(SURFACE)
    cols = list(w.columns)
    ax.stackplot(w.index, [w[c].to_numpy() for c in cols], labels=cols,
                 colors=[SERIES[k % len(SERIES)] for k in range(len(cols))], edgecolor=SURFACE, linewidth=0.5)
    _style(ax)
    ax.set_ylim(0, 1)
    ax.set_title(title, color=INK, fontsize=11, loc="left")
    ax.legend(frameon=False, fontsize=8, ncol=len(cols), loc="upper left", bbox_to_anchor=(0, -0.12))
    return _png(fig)


def regime_chart(regime: pd.DataFrame, spy: pd.Series) -> str:
    fig, ax = plt.subplots(figsize=(9.5, 2.4))
    fig.patch.set_facecolor(SURFACE)
    s = spy.reindex(regime.index)
    ax.plot(s.index, s, color=SERIES[0], linewidth=1.2, label="SPY")
    off = ~regime["regime_on"].astype(bool)
    ax.fill_between(s.index, s.min(), s.max(), where=off.to_numpy(), color=NEUTRAL, alpha=0.18, linewidth=0,
                    label="risk-off")
    _style(ax)
    ax.set_title("Market regime (SPY vs 200d SMA + breadth + VIX term structure)", color=INK, fontsize=11, loc="left")
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    return _png(fig)


# --------------------------------------------------------------------------- tables
def _f(v: Any, kind: str = "pct") -> str:
    if v is None:
        return "-"
    try:
        x = float(v)
    except (TypeError, ValueError):
        return html.escape(str(v))
    if not math.isfinite(x):
        return "-"
    if kind == "pct":
        return f"{x * 100:.1f}%"
    if kind == "num":
        return f"{x:.2f}"
    if kind == "int":
        return f"{x:,.0f}"
    if kind == "usd":
        return f"${x:,.0f}"
    return str(x)


def _table(rows: list[dict[str, Any]], cols: list[tuple[str, str, str]]) -> str:
    head = "".join(f"<th>{html.escape(lbl)}</th>" for _, lbl, _ in cols)
    body = []
    for r in rows:
        tds = []
        for key, _, kind in cols:
            v = r.get(key)
            tds.append(f"<td>{html.escape(str(v))}</td>" if kind == "text" else f"<td class=n>{_f(v, kind)}</td>")
        body.append("<tr>" + "".join(tds) + "</tr>")
    return f"<div class=tw><table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table></div>"


PERF_COLS = [("cagr", "CAGR", "pct"), ("vol", "Vol", "pct"), ("sharpe", "Sharpe", "num"), ("sortino", "Sortino", "num"),
             ("max_dd", "Max DD", "pct"), ("calmar", "Calmar", "num"), ("worst_day", "Worst day", "pct"),
             ("worst_week", "Worst week", "pct"), ("worst_month", "Worst month", "pct"), ("worst_3m", "Worst 3M", "pct")]
SMOOTH_COLS = [("pct_pos_months", "% pos. months", "pct"), ("pct_pos_weeks", "% pos. weeks", "pct"),
               ("ulcer", "Ulcer idx", "num"), ("return_ulcer", "CAGR/Ulcer", "num"),
               ("longest_dd_days", "Longest DD (days)", "int"), ("r2", "R2 log-equity", "num")]
TRADE_COLS = [("trades", "# trades", "int"), ("hit_rate", "Hit rate", "pct"), ("expectancy_r", "Exp. R", "num"),
              ("avg_win", "Avg win", "pct"), ("avg_loss", "Avg loss", "pct"), ("exit_target", "Target", "pct"),
              ("exit_stop", "Stop", "pct"), ("exit_time", "Time", "pct"), ("exit_other", "Other", "pct"),
              ("p_5_losses", "P(5 losses in row)", "pct"), ("p_10_losses", "P(10 in row)", "pct"),
              ("max_consec_losses", "Max losing streak", "int"), ("avg_hold_days", "Avg hold (d)", "num"),
              ("defensive_trades", "Defensive trades (excluded)", "int"), ("defensive_pnl", "Defensive P&L", "usd")]
LEV_COLS = [("risk_profile", "Risk profile", "text"), ("leverage_profile", "Leverage", "text"),
            ("cagr", "CAGR", "pct"), ("max_dd", "Max DD", "pct"), ("worst_day", "Worst day", "pct"),
            ("worst_week", "Worst week", "pct"), ("p_loss_50", "P(loss>50%)", "pct"), ("p_wipe", "P(wipe)", "pct"),
            ("mc_dd_p50", "MC DD p50", "pct"), ("mc_dd_p95", "MC DD p95", "pct"), ("margin_calls", "Margin stop-outs", "int"),
            ("financing_paid", "Financing", "usd"), ("costs_paid", "Spread+slip", "usd"),
            ("oos_cagr", "OOS CAGR", "pct"), ("oos_max_dd", "OOS Max DD", "pct")]


def _row(res: Any) -> dict[str, Any]:
    r = dict(res.stats)
    r["risk_profile"] = res.profile.risk_name
    r["leverage_profile"] = res.profile.lev_name
    r["oos_cagr"] = res.stats_oos.get("cagr")
    r["oos_max_dd"] = res.stats_oos.get("max_dd")
    return r


def den_verdict(out: BacktestOutput, cfg: dict[str, Any]) -> str:
    rp = cfg["risk_profiles"].get("default")
    rows = [(k, v) for k, v in out.runs.items() if k[0] == "DEN" and k[1] == rp]
    if not rows:
        return "DEN not backtested."
    parts = []
    for (_, _, lp), res in rows:
        o = res.stats_oos
        ok = (o.get("cagr", -1) or -1) > 0 and (o.get("expectancy_r", -1) or -1) > 0
        parts.append(f"{lp}: OOS CAGR {_f(o.get('cagr'))}, OOS expectancy {_f(o.get('expectancy_r'), 'num')} R, "
                     f"costs {_f(res.stats.get('costs_paid'), 'usd')} -> {'beats costs' if ok else 'DOES NOT beat costs'}")
    return "; ".join(parts)


def write_report(out: BacktestOutput, cfg: dict[str, Any], out_dir: Path, title: str = "SmartBot backtest") -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    rp_def = cfg["risk_profiles"].get("default")
    lp_def = cfg["general"].get("model_leverage_profile", "1x")
    rps = sorted({k[1] for k in out.runs})
    lps = list(dict.fromkeys(k[2] for k in out.runs))
    tracks = list(dict.fromkeys(k[0] for k in out.runs))
    parts: list[str] = []
    if out.synthetic:
        parts.append("<div class=warn><b>SYNTHETIC DATA.</b> These results come from generated prices "
                     "(GBM + regimes + crashes). They verify that the code runs; they say nothing about real performance.</div>")
    parts.append(f"<p class=meta>Period {out.start} to {out.end}; in-sample until {out.split_date}, out-of-sample after. "
                 f"Signals at close t, execution at next open. Runtime {out.elapsed_s:.0f}s.</p>")
    parts.append(f"<p class=disc>{html.escape(DISCLAIMER)}</p>")
    bench_rows = [{"name": k, **v} for k, v in out.bench_stats.items()]
    parts.append("<h2>Benchmarks</h2>" + _table(bench_rows, [("name", "Benchmark", "text")] + PERF_COLS[:6] +
                                               [("oos_cagr", "OOS CAGR", "pct"), ("oos_max_dd", "OOS Max DD", "pct")]))
    spy = out.benchmarks.get("SPY buy&hold")
    if spy is not None and not out.regime.empty:
        parts.append(f"<img alt='regime chart' src='data:image/png;base64,{regime_chart(out.regime, spy)}'>")

    # combined
    if out.combined:
        parts.append("<h2>Combined portfolio of sleeves</h2><p>Inverse-volatility weights with a correlation penalty, "
                     "rebalanced every %s days (past returns only).</p>" % cfg.get("portfolio", {}).get("rebalance_days", 21))
        crow = []
        for (rp, lp), c in out.combined.items():
            r = {"risk_profile": rp, "leverage_profile": lp, **c["stats"], "oos_cagr": c["stats_oos"].get("cagr"),
                 "oos_max_dd": c["stats_oos"].get("max_dd")}
            crow.append(r)
        parts.append(_table(crow, LEV_COLS[:10] + [("oos_cagr", "OOS CAGR", "pct"), ("oos_max_dd", "OOS Max DD", "pct")]))
        parts.append(_table(crow, [("risk_profile", "Risk", "text"), ("leverage_profile", "Lev", "text")] + SMOOTH_COLS))
        c = out.combined.get((rp_def, lp_def)) or next(iter(out.combined.values()))
        series = {f"ALL {lp}": out.combined[(rp_def, lp)]["equity"] for lp in lps if (rp_def, lp) in out.combined}
        parts.append(f"<img alt='combined equity' src='data:image/png;base64,"
                     f"{equity_chart(series, out.benchmarks, out.split_date, f'Combined ({rp_def}) by leverage profile')}'>")
        parts.append(f"<img alt='sleeve weights' src='data:image/png;base64,{weights_chart(c['weights'], 'Sleeve weights')}'>")

    # per track
    for tr in tracks:
        label = cfg["tracks"][tr].get("label", tr)
        exp = " (EXPERIMENTAL)" if cfg["tracks"][tr].get("experimental") else ""
        live = "live: enabled" if cfg["tracks"][tr].get("enabled") else "live: DISABLED"
        parts.append(f"<h2>{html.escape(label)}{exp} - horizon {cfg['tracks'][tr]['horizon_days']} d, {live}</h2>")
        avail = out.notes.get("_available", {}).get(tr, [])
        miss = {k: v for k, v in out.notes.get(tr, {}).items()}
        parts.append(f"<p class=meta>Available strategies: {html.escape(', '.join(avail))}"
                     + (f"; unavailable: {html.escape('; '.join(f'{k}: {v}' for k, v in miss.items()))}" if miss else "")
                     + "</p>")
        if tr == "DEN":
            parts.append(f"<div class=warn><b>DEN is experimental.</b> At a 1-day horizon spread, slippage and "
                         f"financing dominate. Out-of-sample verdict: {html.escape(den_verdict(out, cfg))}.</div>")
        series = {f"{lp}": out.runs[(tr, rp_def, lp)].nav["equity"] for lp in lps if (tr, rp_def, lp) in out.runs}
        parts.append(f"<img alt='{tr} equity' src='data:image/png;base64,"
                     f"{equity_chart(series, out.benchmarks, out.split_date, f'{label} ({rp_def}) by leverage profile')}'>")
        rows = [_row(out.runs[(tr, rp, lp)]) for rp in rps for lp in lps if (tr, rp, lp) in out.runs]
        parts.append("<h3>Leverage and risk profile comparison</h3>" + _table(rows, LEV_COLS))
        parts.append("<h3>Return / risk</h3>" + _table(rows, [("risk_profile", "Risk", "text"), ("leverage_profile", "Lev", "text")] + PERF_COLS))
        parts.append("<h3>Smoothness</h3>" + _table(rows, [("risk_profile", "Risk", "text"), ("leverage_profile", "Lev", "text")] + SMOOTH_COLS))
        parts.append("<h3>Trades (R multiples, exits)</h3>" + _table(rows, [("risk_profile", "Risk", "text"), ("leverage_profile", "Lev", "text")] + TRADE_COLS))
        base = out.runs.get((tr, rp_def, lp_def))
        if base is not None:
            iso = [{"segment": "in-sample", **base.stats_is}, {"segment": "out-of-sample", **base.stats_oos}]
            parts.append(f"<h3>In-sample vs out-of-sample ({rp_def}, {lp_def})</h3>" +
                         _table(iso, [("segment", "Segment", "text")] + PERF_COLS[:6] + SMOOTH_COLS[:2] + TRADE_COLS[:3]))
    if out.rr_sweep:
        parts.append("<h2>Reward:risk sweep (default risk profile, 1x)</h2>" + _table(out.rr_sweep, [
            ("track", "Track", "text"), ("rr", "RR", "num"), ("cagr", "CAGR", "pct"), ("max_dd", "Max DD", "pct"),
            ("hit_rate", "Hit rate", "pct"), ("expectancy_r", "Exp. R", "num"), ("exit_target", "Target", "pct"),
            ("exit_stop", "Stop", "pct"), ("exit_time", "Time", "pct"), ("return_ulcer", "CAGR/Ulcer", "num"),
            ("oos_cagr", "OOS CAGR", "pct"), ("oos_max_dd", "OOS Max DD", "pct")]))
    if out.tuning:
        rows = []
        for t in out.tuning:
            b = t["best"]
            o = t.get("oos", {})
            rows.append({"track": t["track"], "objective": t["objective"], "trials": t["trials"],
                         "stop": b.get("stop_atr_mult"), "rr": b.get("reward_risk"), "is_score": b.get("score"),
                         "oos_cagr": o.get("cagr"), "oos_dd": o.get("max_dd"), "oos_ru": o.get("return_ulcer"),
                         "oos_trades": o.get("trades"), "dsr": t.get("deflated_sharpe_oos")})
        parts.append("<h2>In-sample tuning (smoothness objective) and held-out OOS</h2>"
                     "<p>The chosen combination is the one with the best in-sample objective (not return); only "
                     "its out-of-sample result is shown. The Deflated Sharpe Ratio is the probability that the true "
                     "Sharpe is above zero after accounting for the number of trials (multiple testing).</p>" +
                     _table(rows, [("track", "Track", "text"), ("objective", "Objective", "text"), ("trials", "Trials", "int"),
                                   ("stop", "Stop xATR", "num"), ("rr", "RR", "num"), ("is_score", "IS score", "num"),
                                   ("oos_cagr", "OOS CAGR", "pct"), ("oos_dd", "OOS Max DD", "pct"),
                                   ("oos_ru", "OOS CAGR/Ulcer", "num"), ("oos_trades", "OOS trades", "int"),
                                   ("dsr", "Deflated Sharpe", "pct")]))
    ev_rows = []
    for (tr, rp, lp), res in out.runs.items():
        if rp == rp_def and lp == lp_def:
            ev_rows.append({"track": tr, "kill_days": res.stats.get("kill_days"),
                            "breaker": res.stats.get("breaker_events"), "turnover": res.stats.get("turnover_x_per_year"),
                            "exposure": res.stats.get("avg_core_gross"), "time_in_market": res.stats.get("time_in_market")})
    parts.append("<h2>Risk events and exposure (default profile)</h2>" + _table(ev_rows, [
        ("track", "Track", "text"), ("kill_days", "Kill-switch days", "int"), ("breaker", "Circuit-breaker changes", "int"),
        ("turnover", "Turnover x/yr", "num"), ("exposure", "Avg core exposure", "pct"),
        ("time_in_market", "Time in market", "pct")]))
    parts.append("<h2>Method and limitations</h2><ul>"
                 "<li>No look-ahead: indicators and strategy matrices are causal (verified by tests that truncate and perturb future data).</li>"
                 "<li>Fills: next open +/- slippage; CFD adds half-spread per side and overnight financing (benchmark + markup) on full notional per calendar night.</li>"
                 "<li>Resting stop/target: gaps fill at the open; if one bar touches both, the stop is assumed first.</li>"
                 "<li>Margin stop-out is checked at the open and the close only (not intraday).</li>"
                 "<li>S&amp;P 500 universe = current constituents (survivorship bias on real data).</li>"
                 "<li>Monte Carlo: trade-order bootstrap (drawdown) and 10-day block bootstrap of daily returns (P(loss&gt;50%), P(wipe&lt;10% of start)).</li>"
                 "<li>No strategy can guarantee an always-rising equity curve.</li></ul>")
    css = """
:root{--surface:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--line:#e4e3df;--card:#ffffff;--warn:#fff4e0}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--surface:#1a1a19;--ink:#f0efec;--ink2:#c3c2b7;--line:#3a3a37;--card:#232321;--warn:#3a2f17}}
:root[data-theme="dark"]{--surface:#1a1a19;--ink:#f0efec;--ink2:#c3c2b7;--line:#3a3a37;--card:#232321;--warn:#3a2f17}
body{background:var(--surface);color:var(--ink);font:14px/1.45 system-ui,Segoe UI,sans-serif;margin:0 auto;max-width:1100px;padding:16px}
h1{font-size:22px}h2{font-size:17px;margin-top:32px;border-top:1px solid var(--line);padding-top:14px}h3{font-size:14px;color:var(--ink2)}
.tw{overflow-x:auto}table{border-collapse:collapse;font-size:12px;margin:6px 0 12px}th,td{padding:4px 8px;border-bottom:1px solid var(--line);white-space:nowrap}
th{text-align:left;color:var(--ink2);font-weight:600}td.n{text-align:right;font-variant-numeric:tabular-nums}
img{max-width:100%;background:#fcfcfb;border-radius:6px;margin:8px 0}.warn{background:var(--warn);padding:10px 12px;border-radius:6px}
.meta{color:var(--ink2)}.disc{font-size:12px;color:var(--ink2)}"""
    doc = (f"<!doctype html><html lang=cs><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
           f"<title>{html.escape(title)}</title><style>{css}</style></head><body><h1>{html.escape(title)}</h1>"
           + "".join(parts) + "</body></html>")
    path = out_dir / "backtest_report.html"
    path.write_text(doc, encoding="utf-8")
    trades = [r.trades for r in out.runs.values() if len(r.trades)]
    if trades:
        pd.concat(trades, ignore_index=True).to_csv(out_dir / "trades.csv", index=False)
    summary = []
    for (tr, rp, lp), res in out.runs.items():
        summary.append({"track": tr, "risk_profile": rp, "leverage_profile": lp, **res.stats,
                        **{f"oos_{k}": v for k, v in res.stats_oos.items()}})
    for (rp, lp), c in out.combined.items():
        summary.append({"track": "ALL", "risk_profile": rp, "leverage_profile": lp, **c["stats"],
                        **{f"oos_{k}": v for k, v in c["stats_oos"].items()}})
    pd.DataFrame(summary).to_csv(out_dir / "summary.csv", index=False)
    return path


__all__ = ["write_report", "HORIZONS"]
