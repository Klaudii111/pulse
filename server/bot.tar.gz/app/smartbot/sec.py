"""SEC EDGAR clients (free, official): 13F holdings, Form 4 insider trades, XBRL companyfacts.

EDGAR fair-access rules: a descriptive User-Agent with contact e-mail is REQUIRED
(env SEC_USER_AGENT, e.g. "SmartBot research jan.novak@example.com") and at most
10 requests/second. Responses are cached on disk.

Point-in-time: every record keeps its FILING date; strategies count a record only
from filing date + lag (a 13F is filed up to 45 days after quarter end).
"""
from __future__ import annotations

import json
import logging
import re
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Callable

import pandas as pd

log = logging.getLogger(__name__)

SUBMISSIONS = "https://data.sec.gov/submissions/CIK{cik}.json"
ARCHIVE_INDEX = "https://www.sec.gov/Archives/edgar/data/{cik}/{acc}/index.json"
ARCHIVE_FILE = "https://www.sec.gov/Archives/edgar/data/{cik}/{acc}/{name}"
COMPANY_TICKERS = "https://www.sec.gov/files/company_tickers.json"
COMPANYFACTS = "https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json"
OPENFIGI = "https://api.openfigi.com/v3/mapping"


class EdgarClient:
    def __init__(self, user_agent: str | None, cache_dir: Path, min_interval: float = 0.12,
                 http_get: Callable[..., Any] | None = None) -> None:
        if not user_agent or "@" not in user_agent:
            raise ValueError("SEC_USER_AGENT must be set to 'name email@domain' (SEC fair-access policy)")
        self.ua = user_agent
        self.cache = Path(cache_dir)
        self.cache.mkdir(parents=True, exist_ok=True)
        self.min_interval = min_interval
        self._last = 0.0
        self._get = http_get

    def _fetch(self, url: str) -> bytes:
        get = self._get
        if get is None:
            import requests

            get = requests.get
        for attempt in range(5):
            wait = self.min_interval - (time.time() - self._last)
            if wait > 0:
                time.sleep(wait)
            self._last = time.time()
            r = get(url, headers={"User-Agent": self.ua, "Accept-Encoding": "gzip, deflate"}, timeout=30)
            code = getattr(r, "status_code", 200)
            if code == 200:
                return r.content
            if code in (429, 500, 502, 503):
                time.sleep(2 ** attempt)
                continue
            raise RuntimeError(f"EDGAR HTTP {code} for {url}")
        raise RuntimeError(f"EDGAR retries exhausted for {url}")

    def get(self, url: str, cache_key: str | None = None, max_age_days: float | None = None) -> bytes:
        key = cache_key or re.sub(r"[^A-Za-z0-9_.-]", "_", url.split("://", 1)[-1])
        p = self.cache / key
        if p.exists() and (max_age_days is None or (time.time() - p.stat().st_mtime) < max_age_days * 86400):
            return p.read_bytes()
        data = self._fetch(url)
        p.write_bytes(data)
        return data

    def get_json(self, url: str, cache_key: str | None = None, max_age_days: float | None = None) -> Any:
        return json.loads(self.get(url, cache_key, max_age_days).decode("utf-8"))

    # ---------------------------------------------------------- filings
    def filings(self, cik: str, forms: tuple[str, ...], since: str | None = None) -> pd.DataFrame:
        """All filings of `forms` for a CIK (recent + older submission files)."""
        cik10 = str(cik).zfill(10)
        sub = self.get_json(SUBMISSIONS.format(cik=cik10), f"sub_{cik10}.json", max_age_days=1)
        frames = [pd.DataFrame(sub.get("filings", {}).get("recent", {}))]
        for f in sub.get("filings", {}).get("files", []):
            older = self.get_json("https://data.sec.gov/submissions/" + f["name"], f"sub_{f['name']}", max_age_days=30)
            frames.append(pd.DataFrame(older))
        df = pd.concat(frames, ignore_index=True)
        if df.empty:
            return df
        df = df[df["form"].isin(forms)].copy()
        df["filingDate"] = pd.to_datetime(df["filingDate"])
        if since:
            df = df[df["filingDate"] >= pd.Timestamp(since)]
        df["cik"] = cik10
        return df.sort_values("filingDate")

    def entity_name(self, cik: str) -> str:
        cik10 = str(cik).zfill(10)
        sub = self.get_json(SUBMISSIONS.format(cik=cik10), f"sub_{cik10}.json", max_age_days=1)
        return str(sub.get("name", ""))


# ---------------------------------------------------------------------------- 13F
def _strip_ns(tag: str) -> str:
    return tag.split("}", 1)[-1]


def parse_information_table(xml_bytes: bytes) -> pd.DataFrame:
    """Parse a 13F information table XML into rows (namespace-agnostic)."""
    root = ET.fromstring(xml_bytes)
    rows = []
    for el in root.iter():
        if _strip_ns(el.tag) != "infoTable":
            continue
        d: dict[str, Any] = {}
        for ch in el.iter():
            t = _strip_ns(ch.tag)
            if t in ("nameOfIssuer", "titleOfClass", "cusip", "value", "sshPrnamt", "sshPrnamtType", "putCall"):
                d[t] = (ch.text or "").strip()
        rows.append({"name": d.get("nameOfIssuer", ""), "title": d.get("titleOfClass", ""),
                     "cusip": d.get("cusip", "").upper(), "value": float(d.get("value") or 0),
                     "shares": float(d.get("sshPrnamt") or 0), "sh_type": d.get("sshPrnamtType", ""),
                     "put_call": d.get("putCall") or None})
    return pd.DataFrame(rows)


def _info_table_name(index_json: dict[str, Any]) -> str | None:
    items = index_json.get("directory", {}).get("item", [])
    xmls = [i for i in items if str(i.get("name", "")).lower().endswith(".xml")
            and str(i.get("name", "")).lower() != "primary_doc.xml"]
    if not xmls:
        return None
    pref = [i for i in xmls if "info" in str(i.get("name", "")).lower()]
    pick = pref or xmls
    return str(max(pick, key=lambda i: float(str(i.get("size", "0")).strip() or 0)).get("name"))


def fetch_13f_holdings(client: EdgarClient, funds: list[dict[str, str]], since: str,
                       mapper: "CusipMapper") -> pd.DataFrame:
    """Original 13F-HR filings (amendments ignored) -> holdings with tickers."""
    out = []
    for f in funds:
        cik10 = str(f["cik"]).zfill(10)
        try:
            fl = client.filings(cik10, ("13F-HR",), since)
        except Exception as exc:  # noqa: BLE001
            log.warning("13F list failed for %s: %s", f.get("name"), exc)
            continue
        for _, row in fl.iterrows():
            acc = str(row["accessionNumber"]).replace("-", "")
            cik_int = str(int(cik10))
            try:
                idx = client.get_json(ARCHIVE_INDEX.format(cik=cik_int, acc=acc), f"idx_{cik10}_{acc}.json")
                name = _info_table_name(idx)
                if not name:
                    continue
                xml = client.get(ARCHIVE_FILE.format(cik=cik_int, acc=acc, name=name), f"13f_{cik10}_{acc}.xml")
                h = parse_information_table(xml)
            except Exception as exc:  # noqa: BLE001
                log.warning("13F %s %s failed: %s", f.get("name"), acc, exc)
                continue
            if h.empty:
                continue
            h["fund_cik"] = cik10
            h["fund_name"] = f.get("name", cik10)
            h["form"] = "13F-HR"
            h["filing_date"] = row["filingDate"]
            h["report_date"] = pd.to_datetime(row.get("reportDate")) if row.get("reportDate") else pd.NaT
            h["accession"] = row["accessionNumber"]
            out.append(h)
    if not out:
        return pd.DataFrame()
    df = pd.concat(out, ignore_index=True)
    df["ticker"] = mapper.map_frame(df)
    unmapped = df["ticker"].isna().mean()
    log.info("13F rows %d, unmapped CUSIPs %.1f%% (dropped by the strategy)", len(df), unmapped * 100)
    return df


# ---------------------------------------------------------------------- CUSIP mapping
_SUFFIX = re.compile(r"\b(INC|INCORPORATED|CORP|CORPORATION|CO|COMPANY|LTD|LIMITED|PLC|HLDGS|HOLDINGS|HLDG|"
                     r"GROUP|GRP|NEW|DEL|THE|CL|CLASS|A|B|C|COM|SA|NV|AG|LP|LLC|TR|TRUST)\b")


def normalize_name(name: str) -> str:
    s = re.sub(r"[^A-Z0-9 ]", " ", str(name).upper())
    s = _SUFFIX.sub(" ", s)
    return re.sub(r"\s+", " ", s).strip()


class CusipMapper:
    """CUSIP -> ticker: manual CSV, optional OpenFIGI, then unique issuer-name match against
    SEC company_tickers.json restricted to the universe. Unmapped -> None (graceful)."""

    def __init__(self, universe: set[str], manual: dict[str, str] | None = None,
                 sec_titles: dict[str, str] | None = None, openfigi: Callable[[list[str]], dict[str, str]] | None = None):
        self.universe = universe
        self.manual = {k.upper(): v.upper() for k, v in (manual or {}).items()}
        self.openfigi = openfigi
        by_name: dict[str, set[str]] = {}
        for tic, title in (sec_titles or {}).items():
            if tic in universe:
                by_name.setdefault(normalize_name(title), set()).add(tic)
        self.by_name = {k: next(iter(v)) for k, v in by_name.items() if len(v) == 1}

    def map_frame(self, df: pd.DataFrame) -> pd.Series:
        cusips = df["cusip"].astype(str).str.upper()
        figi: dict[str, str] = {}
        if self.openfigi is not None:
            todo = sorted(set(cusips) - set(self.manual))
            try:
                figi = self.openfigi(todo)
            except Exception as exc:  # noqa: BLE001
                log.warning("OpenFIGI failed: %s", exc)
        out = []
        for c, n in zip(cusips, df.get("name", pd.Series([""] * len(df)))):
            t = self.manual.get(c) or figi.get(c) or self.by_name.get(normalize_name(n))
            out.append(t if t in self.universe else None)
        return pd.Series(out, index=df.index)


def load_sec_titles(client: EdgarClient) -> dict[str, str]:
    j = client.get_json(COMPANY_TICKERS, "company_tickers.json", max_age_days=7)
    return {str(v["ticker"]).upper().replace("-", "."): str(v["title"]) for v in j.values()}


def openfigi_lookup(api_key: str | None = None) -> Callable[[list[str]], dict[str, str]]:
    def run(cusips: list[str]) -> dict[str, str]:
        import requests

        out: dict[str, str] = {}
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["X-OPENFIGI-APIKEY"] = api_key
        step = 100 if api_key else 10
        for i in range(0, len(cusips), step):
            batch = [{"idType": "ID_CUSIP", "idValue": c, "exchCode": "US"} for c in cusips[i:i + step]]
            r = requests.post(OPENFIGI, json=batch, headers=headers, timeout=30)
            if r.status_code != 200:
                break
            for c, res in zip(cusips[i:i + step], r.json()):
                data = res.get("data") or []
                if data:
                    out[c] = str(data[0].get("ticker", "")).replace("/", ".").upper()
            time.sleep(0.25 if api_key else 2.5)
        return out
    return run


# ---------------------------------------------------------------------------- Form 4
def parse_form4(xml_bytes: bytes) -> list[dict[str, Any]]:
    """Non-derivative transactions from a Form 4 ownershipDocument."""
    root = ET.fromstring(xml_bytes)

    def find_text(el: ET.Element, path: list[str]) -> str | None:
        cur: ET.Element | None = el
        for p in path:
            nxt = None
            for ch in list(cur) if cur is not None else []:
                if _strip_ns(ch.tag) == p:
                    nxt = ch
                    break
            cur = nxt
            if cur is None:
                return None
        return (cur.text or "").strip() if cur is not None else None

    issuer = None
    owners = []
    for el in root.iter():
        t = _strip_ns(el.tag)
        if t == "issuer":
            issuer = find_text(el, ["issuerTradingSymbol"])
        elif t == "reportingOwner":
            owners.append(find_text(el, ["reportingOwnerId", "rptOwnerCik"]) or "")
    rows = []
    for el in root.iter():
        if _strip_ns(el.tag) != "nonDerivativeTransaction":
            continue
        rows.append({
            "symbol": (issuer or "").upper().replace("-", "."),
            "owner_cik": owners[0] if owners else "",
            "trade_date": find_text(el, ["transactionDate", "value"]),
            "code": find_text(el, ["transactionCoding", "transactionCode"]),
            "shares": float(find_text(el, ["transactionAmounts", "transactionShares", "value"]) or 0),
            "price": float(find_text(el, ["transactionAmounts", "transactionPricePerShare", "value"]) or 0),
            "acq_disp": find_text(el, ["transactionAmounts", "transactionAcquiredDisposedCode", "value"]),
        })
    return rows


def fetch_form4(client: EdgarClient, issuer_ciks: dict[str, str], since: str, max_filings: int = 400) -> pd.DataFrame:
    """Per-issuer Form 4 XMLs (slow: one request per filing; use since >= 1-2 years).

    For long backtests prefer the SEC "Insider Transactions Data Sets" (quarterly bulk
    files, see load_insider_bulk_tsv) - [LIKELY] available at sec.gov/dera/data.
    """
    rows: list[dict[str, Any]] = []
    for sym, cik in issuer_ciks.items():
        try:
            fl = client.filings(cik, ("4",), since).tail(max_filings)
        except Exception as exc:  # noqa: BLE001
            log.warning("Form 4 list failed for %s: %s", sym, exc)
            continue
        for _, r in fl.iterrows():
            acc = str(r["accessionNumber"]).replace("-", "")
            doc = str(r.get("primaryDocument", ""))
            doc = doc.split("/", 1)[1] if doc.startswith("xsl") and "/" in doc else doc  # raw XML, not the XSL view
            if not doc.lower().endswith(".xml"):
                continue
            try:
                xml = client.get(ARCHIVE_FILE.format(cik=str(int(cik)), acc=acc, name=doc), f"f4_{acc}.xml")
                for t in parse_form4(xml):
                    t["filing_date"] = r["filingDate"]
                    t["symbol"] = sym
                    rows.append(t)
            except Exception as exc:  # noqa: BLE001
                log.debug("Form 4 %s failed: %s", acc, exc)
    return pd.DataFrame(rows)


def load_insider_bulk_tsv(submission_tsv: Path, owner_tsv: Path, nonderiv_tsv: Path) -> pd.DataFrame:
    """SEC Insider Transactions Data Sets (SUBMISSION, REPORTINGOWNER, NONDERIV_TRANS tables)."""
    sub = pd.read_csv(submission_tsv, sep="\t", dtype=str)
    own = pd.read_csv(owner_tsv, sep="\t", dtype=str)
    nd = pd.read_csv(nonderiv_tsv, sep="\t", dtype=str)
    own1 = own.drop_duplicates("ACCESSION_NUMBER")[["ACCESSION_NUMBER", "RPTOWNERCIK"]]
    df = nd.merge(sub[["ACCESSION_NUMBER", "FILING_DATE", "ISSUERTRADINGSYMBOL", "DOCUMENT_TYPE"]], on="ACCESSION_NUMBER")
    df = df.merge(own1, on="ACCESSION_NUMBER", how="left")
    df = df[df["DOCUMENT_TYPE"].astype(str).str.startswith("4")]
    return pd.DataFrame({
        "symbol": df["ISSUERTRADINGSYMBOL"].astype(str).str.upper().str.replace("-", ".", regex=False),
        "filing_date": pd.to_datetime(df["FILING_DATE"], format="mixed", errors="coerce"),
        "trade_date": pd.to_datetime(df.get("TRANS_DATE"), format="mixed", errors="coerce"),
        "owner_cik": df["RPTOWNERCIK"], "code": df.get("TRANS_CODE"),
        "shares": pd.to_numeric(df.get("TRANS_SHARES"), errors="coerce"),
        "price": pd.to_numeric(df.get("TRANS_PRICEPERSHARE"), errors="coerce"),
        "acq_disp": df.get("TRANS_ACQUIRED_DISP_CD"),
    }).dropna(subset=["filing_date"])


# ------------------------------------------------------------------ companyfacts (v2)
def fetch_fundamentals(client: EdgarClient, issuer_ciks: dict[str, str]) -> pd.DataFrame:
    """Annual (10-K) GrossProfit, Assets, NetIncomeLoss, shares outstanding with `filed` dates."""
    rows = []
    for sym, cik in issuer_ciks.items():
        try:
            j = client.get_json(COMPANYFACTS.format(cik=str(cik).zfill(10)), f"cf_{cik}.json", max_age_days=7)
        except Exception as exc:  # noqa: BLE001
            log.debug("companyfacts %s failed: %s", sym, exc)
            continue
        facts = j.get("facts", {})

        def series(ns: str, tag: str, unit: str) -> dict[str, float]:
            out = {}
            for v in facts.get(ns, {}).get(tag, {}).get("units", {}).get(unit, []):
                if str(v.get("form", "")).startswith("10-K") and v.get("filed"):
                    out[v["filed"]] = float(v["val"])
            return out

        gp = series("us-gaap", "GrossProfit", "USD")
        at = series("us-gaap", "Assets", "USD")
        ni = series("us-gaap", "NetIncomeLoss", "USD")
        sh = series("dei", "EntityCommonStockSharesOutstanding", "shares")
        for filed in sorted(set(gp) | set(at) | set(ni)):
            rows.append({"symbol": sym, "filed": filed, "gross_profit": gp.get(filed), "assets": at.get(filed),
                         "net_income": ni.get(filed), "shares_outstanding": sh.get(filed)})
    df = pd.DataFrame(rows)
    if not df.empty:
        df["filed"] = pd.to_datetime(df["filed"])
        df = df.sort_values(["symbol", "filed"])
        df["shares_outstanding"] = df.groupby("symbol")["shares_outstanding"].ffill()
    return df
