"""Command line interface: `python -m smartbot <command>`."""
from __future__ import annotations

import argparse
import logging
import sys
import tempfile
from pathlib import Path
from typing import Any

from .config import load_config, load_secrets, resolve_path


def _cfg(args: argparse.Namespace) -> dict[str, Any]:
    over: dict[str, Any] = {}
    if getattr(args, "start", None):
        over.setdefault("backtest", {})["start"] = args.start
    if getattr(args, "end", None):
        over.setdefault("backtest", {})["end"] = args.end
    return load_config(args.config, over or None)


def cmd_backtest(args: argparse.Namespace) -> int:
    from .backtest import Backtester
    from .data import load_bundle
    from .daily import synthetic_bundle
    from .report import write_report

    cfg = _cfg(args)
    if args.synthetic:
        bundle = synthetic_bundle(cfg)
    else:
        bundle = load_bundle(cfg)
    bt = Backtester(cfg, bundle)
    rps = args.risk_profiles.split(",") if args.risk_profiles else None
    lps = args.leverage.split(",") if args.leverage else None
    tracks = args.tracks.split(",") if args.tracks else None
    out = bt.run_all(tracks, rps, lps, rr_sweep=not args.no_sweep, tune=args.tune)
    out_dir = Path(args.out) if args.out else resolve_path(cfg, cfg["general"]["report_dir"]) / (
        "synthetic" if args.synthetic else "real")
    path = write_report(out, cfg, out_dir, "SmartBot backtest" + (" - SYNTHETIC DATA" if args.synthetic else ""))
    print(f"report: {path}")
    print(f"trades: {out_dir / 'trades.csv'}  summary: {out_dir / 'summary.csv'}")
    rp = cfg["risk_profiles"]["default"]
    print(f"{'track':6} {'risk':14} {'lev':4} {'CAGR':>7} {'MaxDD':>7} {'Sharpe':>6} {'trades':>6} {'ExpR':>6} {'OOS CAGR':>8}")
    for (tr, r, lp), res in out.runs.items():
        if r != rp:
            continue
        s = res.stats
        print(f"{tr:6} {r:14} {lp:4} {s.get('cagr', 0):7.2%} {s.get('max_dd', 0):7.2%} {s.get('sharpe', 0):6.2f} "
              f"{int(s.get('trades', 0)):6d} {s.get('expectancy_r', 0):6.2f} {res.stats_oos.get('cagr', float('nan')):8.2%}")
    for (r, lp), c in out.combined.items():
        if r == rp:
            s = c["stats"]
            print(f"{'ALL':6} {r:14} {lp:4} {s.get('cagr', 0):7.2%} {s.get('max_dd', 0):7.2%} {s.get('sharpe', 0):6.2f}")
    if args.synthetic:
        print("NOTE: synthetic data - these numbers say nothing about real performance.")
    return 0


def cmd_update_data(args: argparse.Namespace) -> int:
    import pandas as pd

    from . import sec
    from .data import load_universe, update_prices

    cfg = load_config(args.config)
    secrets = load_secrets(args.env)
    uni = load_universe(cfg, refresh=True)
    symbols = list(uni.symbols)
    jpath = resolve_path(cfg, cfg["general"]["journal_db"])
    if jpath.exists():  # keep updating names the model still holds after they left the S&P 500 list
        from .daily import live_tracks, state_symbols
        from .journal import Journal

        j = Journal(jpath)
        symbols += sorted(state_symbols(j, live_tracks(cfg)) - set(symbols))
        j.close()
    st = update_prices(cfg, secrets, symbols, full=args.full)
    failed = [s for s, v in st.items() if v == "failed"]
    print(f"prices: {len(st) - len(failed)} ok, {len(failed)} failed {failed[:20]}")
    cache = resolve_path(cfg, cfg["data"]["cache_dir"])
    if not args.skip_vix:
        try:
            update_vix(cfg)
            print("VIX term structure updated")
        except Exception as exc:  # noqa: BLE001
            print(f"VIX download failed (regime degrades to SPY/breadth): {exc}")
    if args.skip_sec:
        return 0
    client = sec.EdgarClient(secrets.sec_user_agent, cache / "edgar")
    titles = sec.load_sec_titles(client)
    manual = {}
    mpath = resolve_path(cfg, cfg["strategies"]["smart_money"]["cusip_map_csv"])
    if mpath.exists():
        m = pd.read_csv(mpath, dtype=str)
        manual = dict(zip(m["cusip"], m["ticker"]))
    figi = sec.openfigi_lookup(secrets.openfigi_api_key) if cfg["strategies"]["smart_money"].get("use_openfigi") else None
    mapper = sec.CusipMapper(set(uni.symbols), manual, titles, figi)
    sm = cfg["strategies"]["smart_money"]
    h = sec.fetch_13f_holdings(client, sm["funds"], sm.get("history_start", "2013-01-01"), mapper)
    hp = resolve_path(cfg, sm["holdings_file"])
    hp.parent.mkdir(parents=True, exist_ok=True)
    if not h.empty:
        h.to_csv(hp, index=False)
    print(f"13F rows: {len(h)} -> {hp}")
    if args.insiders:
        since = (pd.Timestamp.today() - pd.Timedelta(days=int(args.insider_days))).strftime("%Y-%m-%d")
        f4 = sec.fetch_form4(client, uni.ciks, since)
        ip = resolve_path(cfg, cfg["strategies"]["insider_cluster"]["trades_file"])
        f4.to_csv(ip, index=False)
        print(f"Form 4 rows: {len(f4)} -> {ip}")
    if args.fundamentals:
        fd = sec.fetch_fundamentals(client, uni.ciks)
        fp = resolve_path(cfg, cfg["strategies"]["quality_value"]["fundamentals_file"])
        fd.to_csv(fp, index=False)
        print(f"fundamentals rows: {len(fd)} -> {fp}")
    return 0


def update_vix(cfg: dict[str, Any]) -> None:
    import io

    import pandas as pd
    import requests

    vc = cfg["risk"]["regime"]["vix_term"]
    out = {}
    for key, url in (("vix", vc["vix_url"]), ("vix3m", vc["vix3m_url"])):
        r = requests.get(url, headers={"User-Agent": "smartbot/1.0"}, timeout=30)
        r.raise_for_status()
        df = pd.read_csv(io.StringIO(r.text))
        df.columns = [c.strip().upper() for c in df.columns]
        out[key] = pd.Series(df["CLOSE"].astype(float).to_numpy(), index=pd.to_datetime(df["DATE"]))
    v = pd.DataFrame(out).dropna()
    p = resolve_path(cfg, vc["file"])
    p.parent.mkdir(parents=True, exist_ok=True)
    v.to_csv(p)


def cmd_run_daily(args: argparse.Namespace) -> int:
    from .daily import run_daily

    cfg = load_config(args.config)
    secrets = load_secrets(args.env)
    jp = args.journal
    if args.synthetic and not jp:
        jp = str(Path(tempfile.gettempdir()) / "smartbot_synthetic_journal.sqlite")
    res = run_daily(cfg, secrets, dry_run=args.dry_run, paper=args.paper, synthetic=args.synthetic, asof=args.asof,
                    force=args.force, journal_path=jp)
    print(f"date {res.date}: tracks {list(res.decisions)} skipped {res.skipped} alerts {res.alerts}")
    for line in res.paper_orders:
        print("paper:", line)
    return 0 if not res.alerts else 2


def cmd_report(args: argparse.Namespace) -> int:
    from .journal import Journal
    from .trackrecord import write_trackrecord

    cfg = load_config(args.config)
    j = Journal(args.journal or resolve_path(cfg, cfg["general"]["journal_db"]))
    p = write_trackrecord(j, cfg, Path(args.out) if args.out else resolve_path(cfg, cfg["general"]["report_dir"]))
    print(f"track record: {p}")
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    import json

    from .export import build_export, write_export
    from .journal import Journal

    cfg = load_config(args.config)
    out_dir = Path(args.out)
    prices = None
    if args.synthetic:
        from .daily import process_track, synthetic_bundle
        from .engine import build_market
        from .risk import RiskSettings

        bundle = synthetic_bundle(cfg)
        rs = RiskSettings.from_config(cfg)
        market = build_market(bundle, cfg, rs)
        jp = Path(tempfile.mkdtemp()) / "sample_journal.sqlite"
        j = Journal(jp)
        end = len(market.dates) - 1
        start = end - int(args.days)
        cache: dict[str, Any] = {}
        for tr in cfg["tracks"]:
            if tr in ("DEN", "DNY", "TYDEN", "MESIC", "KRIZE"):
                process_track(cfg, bundle, market, rs, j, tr, start, end, cache, simulated=True)
        prices = bundle.prices.close
        cfg = dict(cfg)
        cfg["general"] = {**cfg["general"], "mode": "paper"}
    else:
        j = Journal(args.journal or resolve_path(cfg, cfg["general"]["journal_db"]))
        try:
            from .data import load_price_data, load_universe

            uni = load_universe(cfg)
            prices = load_price_data(cfg, uni.symbols, cfg["universe"]["benchmark"]).close.iloc[-260:]
        except Exception:  # noqa: BLE001
            prices = None
    prev = None
    sp = out_dir / "signals.json"
    if sp.exists():
        prev = json.loads(sp.read_text(encoding="utf-8"))
    docs = build_export(j, cfg, prices, prev, now=_sample_now(prices) if args.synthetic else None)
    for p in write_export(docs, out_dir):
        print(f"wrote {p}")
    if args.synthetic:
        _sample_intraday(out_dir, j, prices)
    return 0


def _sample_now(prices: Any) -> Any:
    import pandas as pd

    d = pd.Timestamp(prices.index[-1]).tz_localize("America/New_York") + pd.Timedelta(hours=16, minutes=30)
    return d.tz_convert("UTC").to_pydatetime()


def _sample_intraday(out_dir: Path, journal: Any, prices: Any) -> None:
    """SAMPLE ONLY: simulate a few 15-minute refreshes on the next session with a seeded random walk."""
    import numpy as np
    import pandas as pd

    from . import tradingcal
    from .export import refresh_prices

    rng = np.random.default_rng(3)
    nxt = tradingcal.add_trading_days(prices.index[-1], 1)
    state: dict[str, float] = {}

    for k in range(6):
        ts = (pd.Timestamp(nxt).tz_localize("America/New_York") + pd.Timedelta(hours=9, minutes=45 + 15 * k))

        def fetch(sym: str, since: str | None, ts: Any = ts) -> dict[str, Any]:
            last = state.get(sym, float(prices[sym].dropna().iloc[-1]))
            step = rng.normal(0, 0.004)
            if sym == "XLRE" and k == 2:
                step = -0.06  # force one intraday stop touch so the sample shows the field
            new = last * (1 + step)
            state[sym] = new
            return {"last": new, "high": max(last, new) * 1.001, "low": min(last, new) * 0.999,
                    "ts": ts.tz_convert("UTC").isoformat()}

        refresh_prices(out_dir, fetch, journal, now=ts.tz_convert("UTC").to_pydatetime(), force=True)


def cmd_refresh_prices(args: argparse.Namespace) -> int:
    from .export import make_quote_fetcher, refresh_prices
    from .journal import Journal

    cfg = load_config(args.config)
    secrets = load_secrets(args.env)
    j = Journal(args.journal or resolve_path(cfg, cfg["general"]["journal_db"]))
    res = refresh_prices(Path(args.out), make_quote_fetcher(secrets), j, force=args.force)
    print(res)
    return 0


def cmd_verify_ciks(args: argparse.Namespace) -> int:
    from . import sec

    cfg = load_config(args.config)
    secrets = load_secrets(args.env)
    client = sec.EdgarClient(secrets.sec_user_agent, resolve_path(cfg, cfg["data"]["cache_dir"]) / "edgar")
    for f in cfg["strategies"]["smart_money"]["funds"]:
        try:
            name = client.entity_name(f["cik"])
            n13 = len(client.filings(f["cik"], ("13F-HR",)))
            print(f"{f['cik']}  config: {f['name']:32}  EDGAR: {name}  13F-HR filings: {n13}")
        except Exception as exc:  # noqa: BLE001
            print(f"{f['cik']}  {f['name']}: ERROR {exc}")
    return 0


def cmd_verify_journal(args: argparse.Namespace) -> int:
    from .journal import Journal

    cfg = load_config(args.config)
    j = Journal(args.journal or resolve_path(cfg, cfg["general"]["journal_db"]))
    res = j.verify()
    print(res)
    return 0 if all(res.values()) else 3


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="smartbot", description="Daily signal bot (signals + paper trading only).")
    p.add_argument("--config", default=None, help="path to config.yaml")
    p.add_argument("--env", default=None, help="path to .env")
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("backtest", help="run the backtest and write the HTML report")
    b.add_argument("--synthetic", action="store_true", help="use generated prices (offline verification)")
    b.add_argument("--start")
    b.add_argument("--end")
    b.add_argument("--tune", action="store_true", help="in-sample grid search (smoothness objective)")
    b.add_argument("--tracks", help="comma list, e.g. MESIC,TYDEN")
    b.add_argument("--risk-profiles", help="comma list, e.g. konzervativni")
    b.add_argument("--leverage", help="comma list, e.g. 1x,3x")
    b.add_argument("--no-sweep", action="store_true", help="skip the reward:risk sweep")
    b.add_argument("--out")
    b.set_defaults(func=cmd_backtest)

    u = sub.add_parser("update-data", help="download prices, 13F, (optional) Form 4 / fundamentals, VIX")
    u.add_argument("--full", action="store_true", help="re-download full price history")
    u.add_argument("--skip-sec", action="store_true")
    u.add_argument("--skip-vix", action="store_true")
    u.add_argument("--insiders", action="store_true", help="fetch Form 4 (slow)")
    u.add_argument("--insider-days", default=400)
    u.add_argument("--fundamentals", action="store_true")
    u.set_defaults(func=cmd_update_data)

    r = sub.add_parser("run-daily", help="end-of-day signals -> journal -> Discord (-> paper)")
    r.add_argument("--dry-run", action="store_true", help="print Discord messages and paper orders instead of sending")
    r.add_argument("--paper", action="store_true", help="also execute on the Alpaca PAPER account")
    r.add_argument("--synthetic", action="store_true")
    r.add_argument("--asof", help="process data up to this date (testing)")
    r.add_argument("--force", action="store_true")
    r.add_argument("--journal")
    r.set_defaults(func=cmd_run_daily)

    rep = sub.add_parser("report", help="track record + phase-gate report from the journal")
    rep.add_argument("--out")
    rep.add_argument("--journal")
    rep.set_defaults(func=cmd_report)

    e = sub.add_parser("export", help="write signals.json / history.json / performance.json for the PWA")
    e.add_argument("--out", required=True)
    e.add_argument("--journal")
    e.add_argument("--synthetic", action="store_true", help="build a SAMPLE from a simulated synthetic paper run")
    e.add_argument("--days", default=120, type=int, help="synthetic sample length in sessions")
    e.set_defaults(func=cmd_export)

    rp = sub.add_parser("refresh-prices", help="intraday update of open signals in signals.json (15-min cron)")
    rp.add_argument("--out", required=True)
    rp.add_argument("--journal")
    rp.add_argument("--force", action="store_true", help="run even when the US market is closed")
    rp.set_defaults(func=cmd_refresh_prices)

    vc = sub.add_parser("verify-ciks", help="print EDGAR entity names for the configured 13F CIKs")
    vc.set_defaults(func=cmd_verify_ciks)
    vj = sub.add_parser("verify-journal", help="verify the journal hash chains")
    vj.add_argument("--journal")
    vj.set_defaults(func=cmd_verify_journal)
    return p


def safe_console(*streams: Any) -> None:
    """Never crash on Czech text when stdout/stderr is redirected to a file on Windows.

    A redirected stream uses the ANSI code page (cp1252 on English/most Western Windows), which cannot
    encode e.g. "ě", "č", "ř", "ů" -> UnicodeEncodeError in `run-daily --dry-run > log.txt`.
    """
    for s in streams or (sys.stdout, sys.stderr):
        try:
            s.reconfigure(errors="backslashreplace")
        except (AttributeError, ValueError):  # not a TextIOWrapper (e.g. captured by a test runner)
            pass


def main(argv: list[str] | None = None) -> int:
    safe_console()
    args = build_parser().parse_args(argv)
    logging.basicConfig(level=logging.INFO if args.verbose else logging.WARNING,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    return int(args.func(args) or 0)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
