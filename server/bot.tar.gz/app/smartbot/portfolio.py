"""Portfolio-of-sleeves layer.

Each track (DEN, DNY, TYDEN, MESIC, KRIZE) is a sleeve = a separate sub-account
whose sizing is a fraction of its own equity. The combined account allocates
capital across sleeves by inverse volatility with a correlation penalty, using
only PAST sleeve returns (weights decided at close t apply from t+1).

    w_k  ~  (1 / vol_k) / (1 + corr_penalty * mean positive corr(k, others))

clipped to [min_weight, max_weight], rebalanced every `rebalance_days` and left
to drift in between. Sleeves are linear in capital, so re-allocating between
sub-accounts is modelled as costless (moving cash between sub-accounts).
No allocation scheme can guarantee an always-rising equity curve.
"""
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd


def _clip_normalize(w: np.ndarray, lo: float, hi: float) -> np.ndarray:
    w = np.clip(w, 0, None)
    if w.sum() <= 0:
        w = np.ones_like(w)
    w = w / w.sum()
    n = len(w)
    lo = min(lo, 1.0 / n)
    hi = max(hi, 1.0 / n)
    for _ in range(50):
        w = np.clip(w, lo, hi)
        w = w / w.sum()
        if (w >= lo - 1e-9).all() and (w <= hi + 1e-9).all():
            break
    return w


def target_weights(rets_window: pd.DataFrame, method: str = "inverse_vol_corr", corr_penalty: float = 1.0,
                   min_w: float = 0.05, max_w: float = 0.60) -> np.ndarray:
    k = rets_window.shape[1]
    if method == "equal" or len(rets_window) < 20:
        return np.full(k, 1.0 / k)
    vol = rets_window.std().to_numpy() * np.sqrt(252.0)
    vol = np.where(np.isfinite(vol) & (vol > 0.01), vol, 0.01)
    raw = 1.0 / vol
    if corr_penalty > 0 and k > 1:
        c = rets_window.corr().to_numpy()
        c = np.where(np.isfinite(c), c, 0.0)
        np.fill_diagonal(c, np.nan)
        pos = np.nanmean(np.clip(c, 0, None), axis=1)
        raw = raw / (1.0 + corr_penalty * np.nan_to_num(pos))
    return _clip_normalize(raw, min_w, max_w)


def combine_sleeves(equities: dict[str, pd.Series], cfg: dict[str, Any]) -> tuple[pd.Series, pd.DataFrame]:
    """Combine sleeve equity curves into one account. Returns (equity, weights)."""
    pc = cfg.get("portfolio", {})
    names = list(equities)
    eq = pd.DataFrame(equities).dropna(how="all").ffill()
    rets = eq.pct_change().fillna(0.0)
    window = int(pc.get("window_days", 90))
    reb = int(pc.get("rebalance_days", 21))
    method = str(pc.get("method", "inverse_vol_corr"))
    pen = float(pc.get("corr_penalty", 1.0))
    lo, hi = float(pc.get("min_weight", 0.05)), float(pc.get("max_weight", 0.60))
    w = np.full(len(names), 1.0 / len(names))
    val = [1.0]
    hist = [w.copy()]
    R = rets.to_numpy()
    for t in range(1, len(rets)):
        r = R[t]
        rc = float(w @ r)
        val.append(val[-1] * (1.0 + rc))
        w = w * (1.0 + r) / (1.0 + rc) if (1.0 + rc) > 0 else w
        if t % reb == 0:  # decided at close t with returns up to t, applies from t+1
            win = rets.iloc[max(1, t - window + 1): t + 1]
            w = target_weights(win, method, pen, lo, hi)
        hist.append(w.copy())
    start_cap = float(np.mean([s.dropna().iloc[0] for s in equities.values()]))
    equity = pd.Series(val, index=rets.index) * start_cap
    weights = pd.DataFrame(hist, index=rets.index, columns=names)
    return equity, weights
