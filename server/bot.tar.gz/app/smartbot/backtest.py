"""Backtester: runs the shared engine per track x risk profile x leverage profile.

* next-open execution, commissions/slippage (cash) or spread + overnight financing (CFD)
* in-sample / out-of-sample split (first `is_fraction` of the trading period vs the rest)
* optional in-sample tuning with a SMOOTHNESS objective (CAGR/Ulcer or Calmar) and a
  minimum trade count; out-of-sample reported on the held-out window only, with a
  Deflated Sharpe Ratio for the number of trials
* benchmarks: SPY buy & hold, 60/40 SPY/IEF (monthly rebalanced)
* combined portfolio of sleeves (portfolio.py)
"""
from __future__ import annotations

import itertools
import logging
import math
import time
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from . import metrics as M
from .data import MarketBundle
from .engine import Engine, MarketArrays, Profile, build_market
from .portfolio import combine_sleeves
from .risk import RiskSettings
from .strategies.base import StrategyOutput
from .strategies.ensemble import TrackSignals, build_track_signals

log = logging.getLogger(__name__)


def core_trades(trades: pd.DataFrame) -> pd.DataFrame:
    if trades is None or trades.empty or "sleeve" not in trades.columns:
        return trades if trades is not None else pd.DataFrame()
    return trades[trades["sleeve"] == "core"]


def defensive_stats(trades: pd.DataFrame) -> dict[str, float]:
    if trades is None or trades.empty or "sleeve" not in trades.columns:
        return {"defensive_trades": 0.0, "defensive_pnl": 0.0}
    d = trades[trades["sleeve"] == "defensive"]
    return {"defensive_trades": float(len(d)), "defensive_pnl": float(d["pnl"].sum()) if len(d) else 0.0}


@dataclass
class RunResult:
    track: str
    profile: Profile
    nav: pd.DataFrame
    trades: pd.DataFrame
    events: list[dict[str, Any]]
    stats: dict[str, float]
    stats_is: dict[str, float]
    stats_oos: dict[str, float]
    extra: dict[str, float] = field(default_factory=dict)


@dataclass
class BacktestOutput:
    synthetic: bool
    start: str
    end: str
    split_date: str
    runs: dict[tuple[str, str, str], RunResult]
    combined: dict[tuple[str, str], dict[str, Any]]
    rr_sweep: list[dict[str, Any]]
    tuning: list[dict[str, Any]]
    benchmarks: dict[str, pd.Series]
    bench_stats: dict[str, dict[str, float]]
    regime: pd.DataFrame
    notes: dict[str, Any]
    elapsed_s: float = 0.0


class Backtester:
    def __init__(self, cfg: dict[str, Any], bundle: MarketBundle) -> None:
        self.cfg = cfg
        self.bundle = bundle
        self.rs = RiskSettings.from_config(cfg)
        self.market: MarketArrays = build_market(bundle, cfg, self.rs)
        self._strat_cache: dict[str, StrategyOutput] = {}
        self._sig_cache: dict[tuple[str, float], TrackSignals] = {}
        bt = cfg.get("backtest", {})
        dates = self.market.dates
        warm = int(bt.get("warmup_days", 260))
        start_req = pd.Timestamp(bt.get("start")) if bt.get("start") and not bundle.synthetic else None
        first = warm
        if start_req is not None:
            first = max(warm, int(dates.searchsorted(start_req)))
        end_req = bt.get("end")
        last = len(dates) - 1 if not end_req else int(dates.searchsorted(pd.Timestamp(end_req), side="right")) - 1
        if last - first < 260:
            raise ValueError("not enough data after warm-up for a backtest")
        self.start_i, self.end_i = first, last
        self.split_i = first + int((last - first) * float(bt.get("is_fraction", 0.7)))
        self.mc_cfg = dict(bt.get("monte_carlo", {}))

    # -------------------------------------------------------------- signals
    def signals(self, track: str, stop_mult: float | None = None) -> TrackSignals:
        tcfg = self.cfg["tracks"][track]
        sm = float(stop_mult if stop_mult is not None else tcfg["stop_atr_mult"])
        key = (track, sm)
        if key not in self._sig_cache:
            self._sig_cache[key] = build_track_signals(self.bundle, self.cfg, track, self._strat_cache,
                                                       {"stop_atr_mult": sm})
        return self._sig_cache[key]

    # ------------------------------------------------------------------ run
    def run_one(self, track: str, profile: Profile, start: int | None = None, end: int | None = None,
                stop_mult: float | None = None, with_mc: bool = True) -> RunResult:
        tcfg = dict(self.cfg["tracks"][track])
        if stop_mult is not None:
            tcfg["stop_atr_mult"] = stop_mult
        s, e = (self.start_i if start is None else start), (self.end_i if end is None else end)
        eng = Engine(self.market, self.signals(track, stop_mult), tcfg, self.rs, profile,
                     float(self.cfg["general"].get("initial_capital", 100_000)), track=track)
        eng.run(s, e)
        nav = eng.nav_frame()
        trades = eng.trades_frame()
        eq = nav["equity"]
        mc = self.mc_cfg if with_mc else {"sims": 0}
        # trade statistics (hit rate, expectancy, R, Monte Carlo) use CORE signals only; defensive-sleeve
        # allocations (BIL/TLT/GLD rebalancing, no target) are reported separately
        core = core_trades(trades)
        stats = M.summarize(eq, core, nav, mc) if with_mc else {**M.performance(eq), **M.trade_stats(core)}
        stats.update(defensive_stats(trades))
        split_d = self.market.dates[self.split_i]
        is_eq, oos_eq = eq.loc[:split_d], eq.loc[split_d:]
        t_is = core[pd.to_datetime(core["entry_date"]) < split_d] if len(core) else core
        t_oos = core[pd.to_datetime(core["entry_date"]) >= split_d] if len(core) else core
        stats_is = {**M.performance(is_eq), **M.trade_stats(t_is)}
        stats_oos = {**M.performance(oos_eq), **M.trade_stats(t_oos)} if len(oos_eq) > 30 else {}
        extra = {"costs_paid": eng.costs_paid, "financing_paid": eng.financing_paid,
                 "margin_calls": float(eng.margin_calls), "wiped": float(eng.wiped),
                 "turnover_x_per_year": eng.turnover / max(1.0, float(eq.mean())) / max(1e-9, len(eq) / 252.0),
                 "kill_days": float(sum(1 for ev in eng.events if ev["kind"] == "kill_switch")),
                 "breaker_events": float(sum(1 for ev in eng.events if ev["kind"] == "circuit_breaker"))}
        stats.update(extra)
        return RunResult(track, profile, nav, trades, eng.events, stats, stats_is, stats_oos, extra)

    def tracks(self, which: list[str] | None = None) -> list[str]:
        return [t for t in (which or list(self.cfg["tracks"])) if t in self.cfg["tracks"]]

    def run_all(self, tracks: list[str] | None = None, risk_profiles: list[str] | None = None,
                lev_profiles: list[str] | None = None, rr_sweep: bool = True, tune: bool = False) -> BacktestOutput:
        t0 = time.time()
        cfg = self.cfg
        tracks = self.tracks(tracks)
        rps = risk_profiles or list(cfg["risk_profiles"]["profiles"])
        lps = lev_profiles or list(cfg["leverage"]["profiles"])
        runs: dict[tuple[str, str, str], RunResult] = {}
        for tr in tracks:
            for rp in rps:
                for lp in lps:
                    log.info("backtest %s %s %s", tr, rp, lp)
                    runs[(tr, rp, lp)] = self.run_one(tr, Profile.from_config(cfg, rp, lp))
        combined = self.combine(runs, rps, lps)
        sweep = self.rr_sweep(tracks) if rr_sweep else []
        tuning = self.tune(tracks) if tune else []
        bench, bstats = self.benchmarks()
        notes = {tr: self.signals(tr).notes for tr in tracks}
        notes["_available"] = {tr: self.signals(tr).available for tr in tracks}
        regime = self.market.regime_frame.iloc[self.start_i:self.end_i + 1]
        return BacktestOutput(
            synthetic=self.bundle.synthetic, start=str(self.market.dates[self.start_i].date()),
            end=str(self.market.dates[self.end_i].date()), split_date=str(self.market.dates[self.split_i].date()),
            runs=runs, combined=combined, rr_sweep=sweep, tuning=tuning, benchmarks=bench, bench_stats=bstats,
            regime=regime, notes=notes, elapsed_s=time.time() - t0,
        )

    # ------------------------------------------------------------- combined
    def combine(self, runs: dict[tuple[str, str, str], RunResult], rps: list[str], lps: list[str]) -> dict[tuple[str, str], dict[str, Any]]:
        sleeves = [s for s in self.cfg.get("portfolio", {}).get("sleeves", []) if any(k[0] == s for k in runs)]
        out: dict[tuple[str, str], dict[str, Any]] = {}
        if len(sleeves) < 2:
            return out
        split_d = self.market.dates[self.split_i]
        for rp in rps:
            for lp in lps:
                eqs = {s: runs[(s, rp, lp)].nav["equity"] for s in sleeves if (s, rp, lp) in runs}
                eq, w = combine_sleeves(eqs, self.cfg)
                trades = pd.concat([core_trades(runs[(s, rp, lp)].trades) for s in eqs if len(runs[(s, rp, lp)].trades)],
                                   ignore_index=True) if eqs else pd.DataFrame()
                # sleeve trades are sized on sleeve equity -> scale contribution by the sleeve weight
                if len(trades):
                    wmean = w.mean()
                    trades = trades.copy()
                    trades["contribution"] = trades["contribution"] * trades["track"].map(wmean).fillna(0.0)
                stats = M.summarize(eq, trades, None, self.mc_cfg)
                out[(rp, lp)] = {"equity": eq, "weights": w, "stats": stats,
                                 "stats_is": M.performance(eq.loc[:split_d]),
                                 "stats_oos": M.performance(eq.loc[split_d:]), "sleeves": list(eqs)}
        return out

    # ----------------------------------------------------------- RR sweep
    def rr_sweep(self, tracks: list[str]) -> list[dict[str, Any]]:
        cfg = self.cfg
        rows = []
        rp = cfg["risk_profiles"].get("default")
        lp = cfg["general"].get("model_leverage_profile", "1x")
        for tr in tracks:
            if tr == "KRIZE":
                continue
            for rr in cfg["risk_profiles"].get("rr_sweep", [1.7, 2.0, 2.7]):
                res = self.run_one(tr, Profile.from_config(cfg, rp, lp, rr=float(rr)), with_mc=False)
                s = res.stats
                rows.append({"track": tr, "rr": rr, "cagr": s.get("cagr"), "max_dd": s.get("max_dd"),
                             "hit_rate": s.get("hit_rate"), "expectancy_r": s.get("expectancy_r"),
                             "exit_target": s.get("exit_target"), "exit_stop": s.get("exit_stop"),
                             "exit_time": s.get("exit_time"), "return_ulcer": s.get("return_ulcer"),
                             "oos_cagr": res.stats_oos.get("cagr"), "oos_max_dd": res.stats_oos.get("max_dd")})
        return rows

    # --------------------------------------------------------------- tuning
    def tune(self, tracks: list[str]) -> list[dict[str, Any]]:
        """In-sample grid search with a smoothness objective; OOS of the chosen combo only."""
        cfg = self.cfg
        bt = cfg.get("backtest", {})
        grid = bt.get("tune_grid", {})
        obj = bt.get("tune_objective", "return_ulcer")
        min_tr = int(bt.get("tune_min_trades", 30))
        stops = grid.get("stop_atr_mult", [None])
        rrs = grid.get("reward_risk", [None])
        rp = cfg["risk_profiles"].get("default")
        lp = cfg["general"].get("model_leverage_profile", "1x")
        out = []
        for tr in tracks:
            trials = []
            for sm, rr in itertools.product(stops, rrs):
                prof = Profile.from_config(cfg, rp, lp, rr=rr)
                res = self.run_one(tr, prof, self.start_i, self.split_i, stop_mult=sm, with_mc=False)
                s = res.stats
                score = s.get(obj, float("nan"))
                if s.get("trades", 0) < min_tr or not math.isfinite(score):
                    score = -np.inf
                trials.append({"stop_atr_mult": sm, "reward_risk": rr, "score": score, "is_sharpe": s.get("sharpe"),
                               "is_trades": s.get("trades")})
            best = max(trials, key=lambda x: x["score"])
            n_valid = sum(1 for x in trials if np.isfinite(x["score"]))
            row: dict[str, Any] = {"track": tr, "objective": obj, "trials": len(trials), "valid_trials": n_valid,
                                   "best": best, "all": trials}
            if np.isfinite(best["score"]):
                prof = Profile.from_config(cfg, rp, lp, rr=best["reward_risk"])
                warm = max(0, self.split_i)
                res = self.run_one(tr, prof, warm, self.end_i, stop_mult=best["stop_atr_mult"], with_mc=False)
                oos = res.stats
                sr_list = [x["is_sharpe"] for x in trials if x["is_sharpe"] is not None and np.isfinite(x["is_sharpe"])]
                sr_std = float(np.std(sr_list)) if len(sr_list) > 1 else 0.5
                row["oos"] = {k: oos.get(k) for k in ("cagr", "max_dd", "sharpe", "calmar", "return_ulcer",
                                                      "pct_pos_months", "trades", "expectancy_r")}
                row["deflated_sharpe_oos"] = M.deflated_sharpe(oos.get("sharpe", float("nan")), len(trials),
                                                               int(oos.get("n_days", 0) or 0), oos.get("skew", 0.0) or 0.0,
                                                               oos.get("kurt", 3.0) or 3.0, max(sr_std, 1e-3))
            out.append(row)
        return out

    # ----------------------------------------------------------- benchmarks
    def benchmarks(self) -> tuple[dict[str, pd.Series], dict[str, dict[str, float]]]:
        px = self.bundle.prices.close.iloc[self.start_i:self.end_i + 1]
        cap = float(self.cfg["general"].get("initial_capital", 100_000))
        bench = self.cfg["universe"]["benchmark"]
        out: dict[str, pd.Series] = {}
        out["SPY buy&hold"] = M.benchmark_buy_hold(px[bench]) * cap
        mix = self.cfg.get("backtest", {}).get("benchmark_6040", {"SPY": 0.6, "IEF": 0.4})
        if all(k in px.columns for k in mix):
            out["60/40"] = M.benchmark_mix(px, mix) * cap
        split_d = self.market.dates[self.split_i]
        stats = {}
        for k, v in out.items():
            st = M.performance(v)
            st["oos_cagr"] = M.performance(v.loc[split_d:]).get("cagr", float("nan"))
            st["oos_max_dd"] = M.performance(v.loc[split_d:]).get("max_dd", float("nan"))
            stats[k] = st
        return out, stats
