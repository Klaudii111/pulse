"""Event-driven daily portfolio engine shared by the backtester and the live daily run.

Timeline of one session t (`Engine.step(t)`):
  1. overnight financing for positions held over the previous close (CFD / margin)
  2. OPEN: execute orders decided at the previous close (sells first, then buys)
  3. INTRADAY: resting stop (sell-stop) and target (sell-limit) orders; gaps fill at the open;
     if a bar touches both, the STOP is assumed first (conservative)
  4. CLOSE: hard time exits (market-on-close), stale/delisted exits, mark-to-market,
     margin stop-out, circuit breaker, loss limits, trailing stops
  5. DECIDE at the close of t using only data <= t -> orders for the open of t+1

Signals computed at close t are therefore executed at the next open t+1.
"""
from __future__ import annotations

import logging
import math
from dataclasses import asdict, dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from . import indicators as ind
from . import risk as R
from . import tradingcal
from .data import MarketBundle
from .strategies.ensemble import TrackSignals

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Market arrays (precomputed, causal)
# ---------------------------------------------------------------------------
@dataclass
class MarketArrays:
    dates: pd.DatetimeIndex
    symbols: list[str]
    col: dict[str, int]
    open: np.ndarray
    high: np.ndarray
    low: np.ndarray
    close: np.ndarray
    close_ff: np.ndarray
    atr: np.ndarray
    logret: np.ndarray
    ret12: np.ndarray
    liquid: np.ndarray
    regime: np.ndarray
    regime_gap: np.ndarray          # benchmark close / SMA - 1
    regime_frame: pd.DataFrame      # regime components (SPY, breadth, VIX)
    spy_on: np.ndarray
    breadth_pct: np.ndarray | None
    vix_ratio: np.ndarray | None
    bench_sma20_ok: np.ndarray       # benchmark close > its 20d SMA (circuit-breaker re-entry)
    asset_class: list[str]
    sector: list[str]
    is_etf: np.ndarray
    names: dict[str, str]
    bench_col: int
    cash_col: int | None
    diag: dict[str, np.ndarray]
    earnings: np.ndarray | None
    synthetic: bool = False


def build_market(bundle: MarketBundle, cfg: dict[str, Any], rs: R.RiskSettings) -> MarketArrays:
    px = bundle.prices
    syms = px.symbols
    bench = cfg["universe"]["benchmark"]
    if bench not in syms:
        raise ValueError(f"benchmark {bench} missing from price data")
    close = px.close
    atr = ind.atr(px.high, px.low, close, rs.atr_days)
    stocks = [s for s in syms if not bundle.is_etf.get(s, False)]
    breadth = (R.breadth_stats(close, stocks, int(rs.breadth.get("sma_days", 200)), int(rs.breadth.get("nh_nl_days", 252)))
               if rs.breadth.get("enabled", False) and len(stocks) >= 20 else None)
    comp = R.composite_regime(close[bench], rs.regime_sma, breadth, rs.breadth, bundle.vix, rs.vix_term,
                              rs.regime_hysteresis)
    reg = comp["regime_on"]
    liq = R.liquidity_mask(close, px.volume, rs.min_price, rs.min_dollar_volume, rs.liquidity_window)
    cash = cfg["universe"].get("cash_proxy")
    ks = R.KillSwitch.from_settings(rs)
    c = close.to_numpy(dtype=float)
    return MarketArrays(
        dates=px.dates, symbols=syms, col={s: j for j, s in enumerate(syms)},
        open=px.open.to_numpy(dtype=float), high=px.high.to_numpy(dtype=float), low=px.low.to_numpy(dtype=float),
        close=c, close_ff=close.ffill().to_numpy(dtype=float), atr=atr.to_numpy(dtype=float),
        logret=ind.log_returns(close).to_numpy(dtype=float),
        ret12=ind.total_return(close, rs.defensive_lookback, 0).to_numpy(dtype=float),
        liquid=liq.to_numpy(dtype=bool), regime=reg.to_numpy(dtype=bool),
        regime_gap=comp["gap"].to_numpy(dtype=float),
        regime_frame=comp, spy_on=comp["spy_on"].to_numpy(dtype=bool),
        bench_sma20_ok=(close[bench] > close[bench].rolling(20, min_periods=20).mean()).to_numpy(dtype=bool),
        breadth_pct=comp["breadth_pct_above"].to_numpy(dtype=float) if "breadth_pct_above" in comp else None,
        vix_ratio=comp["vix_ratio"].to_numpy(dtype=float) if "vix_ratio" in comp else None,
        asset_class=[bundle.asset_classes.get(s, "equity") for s in syms],
        sector=[bundle.sectors.get(s, "Unknown") for s in syms],
        is_etf=np.array([bool(bundle.is_etf.get(s, False)) for s in syms]),
        names=dict(bundle.names), bench_col=syms.index(bench),
        cash_col=syms.index(cash) if cash in syms else None,
        diag=ks.precompute(c, syms.index(bench)),
        earnings=(R.earnings_blackout_matrix(bundle.earnings, px.dates, syms, rs.earnings_blackout_days)
                  if rs.earnings_enabled else None),
        synthetic=bundle.synthetic,
    )


# ---------------------------------------------------------------------------
# Profiles and records
# ---------------------------------------------------------------------------
@dataclass
class Profile:
    """One (risk profile, leverage profile, cost model) combination."""

    risk_name: str = "konzervativni"
    risk_per_trade: float = 0.01
    rr: float | None = 2.0
    lev_name: str = "1x"
    leverage: float = 1.0
    instrument: str = "cash"
    slippage_bps: float = 5.0
    spread_bps: dict[str, float] = field(default_factory=dict)
    commission_bps: float = 0.0
    commission_per_order: float = 0.0
    financing_annual: float = 0.0
    day_count: int = 360

    @classmethod
    def from_config(cls, cfg: dict[str, Any], risk_name: str | None = None, lev_name: str | None = None,
                    rr: float | None = None) -> "Profile":
        rp_all = cfg["risk_profiles"]["profiles"]
        risk_name = risk_name or cfg["risk_profiles"].get("default", next(iter(rp_all)))
        lev_name = lev_name or next(iter(cfg["leverage"]["profiles"]))
        rp = rp_all[risk_name]
        lp = cfg["leverage"]["profiles"][lev_name]
        inst = lp["instrument"]
        costs = cfg["costs"][inst]
        if inst == "cfd":
            fin = float(costs["benchmark_rate_annual"]) + float(costs["financing_markup_annual"])
            dc = int(costs.get("day_count", 360))
        else:
            fin = float(costs.get("margin_rate_annual", 0.08))
            dc = 360
        return cls(
            risk_name=risk_name, risk_per_trade=float(rp["risk_per_trade"]),
            rr=float(rr if rr is not None else rp.get("reward_risk", 2.0)),
            lev_name=lev_name, leverage=float(lp["leverage"]), instrument=inst,
            slippage_bps=float(costs.get("slippage_bps", 5.0)),
            spread_bps={k: float(v) for k, v in (costs.get("spread_bps") or {}).items()},
            commission_bps=float(costs.get("commission_bps", 0.0)),
            commission_per_order=float(costs.get("commission_per_order", 0.0)),
            financing_annual=fin, day_count=dc,
        )

    @property
    def key(self) -> str:
        return f"{self.risk_name}|{self.lev_name}|rr{self.rr}"


@dataclass
class Position:
    symbol: str
    sleeve: str                   # core | defensive
    shares: float
    entry_date: str
    entry_price: float
    initial_stop: float
    stop: float
    target: float | None
    exit_due: str
    highest_close: float
    reasons: list[str]
    asset_class: str
    entry_equity: float
    initial_risk: float           # $ at stop at entry
    cost_total: float = 0.0       # $ paid buying (incl. costs)
    proceeds_total: float = 0.0   # $ received selling
    signal_date: str = ""
    signal_ref: float = 0.0
    last_close: float = 0.0
    last_close_date: str = ""
    missing_days: int = 0
    max_shares: float = 0.0
    roll_planned: bool = False    # decided at the close BEFORE exit_due (no same-close look-ahead)


@dataclass
class Order:
    symbol: str
    action: str                   # BUY | SELL | RESIZE
    shares: float                 # target shares for BUY/RESIZE
    sleeve: str = "core"
    stop: float = 0.0
    target: float | None = None
    exit_due: str = ""
    reasons: list[str] = field(default_factory=list)
    signal_date: str = ""
    ref_price: float = 0.0
    reason: str = ""


@dataclass
class Signal:
    track: str
    date: str
    symbol: str
    action: str                   # BUY | SELL | HOLD
    ref_price: float
    stop: float
    target: float | None
    exit_due: str
    size_pct: float               # notional as fraction of equity
    risk_pct: float               # loss at stop as fraction of equity
    reward_pct: float             # gain at target as fraction of equity
    rr: float | None
    reasons: list[str]
    regime: str
    breaker: str
    sleeve: str = "core"
    asset_class: str = "equity"
    max_leverage: float = 1.0
    executed: bool = False        # True for exits already filled intraday/at close
    note: str = ""
    exp_r: float = 0.0            # causal expected-R estimate used for ranking
    risk_budget: float = 0.0      # intended loss at stop (fraction of equity) before caps
    rolls: bool = False           # HOLD only: position is due tomorrow and will be ROLLED (no time exit)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Decision:
    track: str
    date: str
    signals: list[Signal]
    regime: str
    regime_gap: float
    breaker: str
    kill: str | None
    blocked: str | None
    equity: float
    events: list[str]
    skipped: dict[str, str] = field(default_factory=dict)
    regime_note: str = ""


def regime_note(m: MarketArrays, i: int) -> str:
    """Human-readable regime components (Czech)."""
    parts = [f"SPY {m.regime_gap[i] * 100:+.1f} % vůči SMA200" if np.isfinite(m.regime_gap[i]) else "SPY bez SMA200"]
    if m.breadth_pct is not None and np.isfinite(m.breadth_pct[i]):
        parts.append(f"šíře trhu {m.breadth_pct[i] * 100:.0f} % akcií nad SMA200")
    if m.vix_ratio is not None and np.isfinite(m.vix_ratio[i]):
        parts.append(f"VIX/VIX3M {m.vix_ratio[i]:.2f}" + (" (backwardation)" if m.vix_ratio[i] > 1 else ""))
    return ", ".join(parts)


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------
class Engine:
    def __init__(self, market: MarketArrays, sig: TrackSignals, tcfg: dict[str, Any], rs: R.RiskSettings,
                 profile: Profile, initial_capital: float = 100_000.0, track: str = "MESIC") -> None:
        if list(sig.symbols) != list(market.symbols):
            raise ValueError("signal and market symbols differ")
        self.m, self.sig, self.t, self.rs, self.p = market, sig, tcfg, rs, profile
        self.track = track
        self.H = int(tcfg["horizon_days"])
        self.kill = R.KillSwitch.from_settings(rs)
        self.cash = float(initial_capital)
        self.initial_capital = float(initial_capital)
        self.positions: dict[str, Position] = {}
        self.pending: list[Order] = []
        self.breaker = R.CircuitBreaker(rs.halve_dd, rs.cash_dd, rs.halve_reset_dd, rs.min_days_in_cash,
                                        rs.reentry_sma_days, rs.reentry_max_loss, rs.hard_stop_dd,
                                        peak=float(initial_capital))
        # per-track: loss limits / equity-curve filter / stop cooldown can be disabled (mean-reversion tracks buy
        # exactly after bad days, so these trend-following brakes select against their best setups)
        big = 1e9
        ll = tcfg.get("loss_limits", True)
        self.limits = R.LossLimits(rs.daily_loss_r if ll else big, rs.weekly_loss_r if ll else big, prev_equity=float(initial_capital))
        self.use_ec = bool(tcfg.get("ec_filter", True)) and rs.ec_filter
        self.cooldown = int(tcfg.get("cooldown_days", rs.cooldown_days))
        self.stopped_out: dict[str, str] = {}
        self.blocked: str | None = None
        self.wiped = False
        self.ec_hist: list[float] = []
        self.ec_mult = 1.0
        self.last_i: int | None = None
        self.equity = float(initial_capital)
        # outputs
        self.nav: list[dict[str, Any]] = []
        self.trades: list[dict[str, Any]] = []
        self.events: list[dict[str, Any]] = []
        self.decisions: list[Decision] = []
        self.day_exits: list[Signal] = []
        self.keep_decisions = False
        self.turnover = 0.0
        self.costs_paid = 0.0
        self.financing_paid = 0.0
        self.margin_calls = 0

    # ------------------------------------------------------------------ utils
    def _price(self, i: int, j: int) -> float:
        return float(self.m.close_ff[i, j])

    def _event(self, i: int, kind: str, msg: str) -> None:
        self.events.append({"date": str(self.m.dates[i].date()), "track": self.track, "kind": kind, "message": msg})

    def _fill(self, price: float, side: str, cls: str) -> float:
        adj = self.p.slippage_bps / 1e4
        if self.p.instrument == "cfd":
            adj += self.p.spread_bps.get(cls, self.p.spread_bps.get("equity", 10.0)) / 2e4
        return price * (1.0 + adj) if side == "buy" else price * (1.0 - adj)

    def _commission(self, notional: float) -> float:
        return self.p.commission_per_order + abs(notional) * self.p.commission_bps / 1e4

    def _equity(self, i: int, prices: str = "close") -> float:
        arr = {"close": self.m.close_ff, "open": self.m.open}[prices]
        val = 0.0
        for s, p in self.positions.items():
            j = self.m.col[s]
            px = arr[i, j]
            if not math.isfinite(px):
                px = self.m.close_ff[i, j] if math.isfinite(self.m.close_ff[i, j]) else p.last_close
            val += p.shares * px
        return self.cash + val

    def _exit_due(self, i: int, n: int) -> str:
        if i + n < len(self.m.dates):
            return str(self.m.dates[i + n].date())
        return str(tradingcal.add_trading_days(self.m.dates[i], n, known=self.m.dates).date())

    def _trading_days_since(self, i: int, iso: str) -> int:
        k = int(self.m.dates.searchsorted(pd.Timestamp(iso)))
        return i - k

    # ---------------------------------------------------------------- trading
    def _buy(self, i: int, o: Order, price: float) -> None:
        j = self.m.col[o.symbol]
        cls = self.m.asset_class[j]
        fill = self._fill(price, "buy", cls)
        shares = o.shares
        if self.p.instrument == "cash" and self.p.leverage <= 1.0:
            afford = max(0.0, self.cash) / (fill * (1 + self.p.commission_bps / 1e4) + 1e-12)
            shares = min(shares, afford)
        if shares <= 1e-9:
            return
        notional = shares * fill
        comm = self._commission(notional)
        self.cash -= notional + comm
        self.costs_paid += shares * (fill - price) + comm
        self.turnover += notional
        eq = self._equity(i, "open")
        p = self.positions.get(o.symbol)
        if p is None:
            self.positions[o.symbol] = Position(
                symbol=o.symbol, sleeve=o.sleeve, shares=shares, entry_date=str(self.m.dates[i].date()),
                entry_price=fill, initial_stop=o.stop, stop=o.stop, target=o.target, exit_due=o.exit_due,
                highest_close=fill, reasons=list(o.reasons), asset_class=cls, entry_equity=eq,
                initial_risk=max(0.0, shares * (fill - o.stop)), cost_total=notional + comm,
                signal_date=o.signal_date, signal_ref=o.ref_price, last_close=price,
                last_close_date=str(self.m.dates[i].date()), max_shares=shares,
            )
        else:  # add-on (defensive resize up)
            p.shares += shares
            p.cost_total += notional + comm
            p.max_shares = max(p.max_shares, p.shares)

    def _sell(self, i: int, sym: str, shares: float, price: float, reason: str) -> None:
        p = self.positions[sym]
        shares = min(shares, p.shares)
        fill = self._fill(price, "sell", p.asset_class)
        notional = shares * fill
        comm = self._commission(notional)
        self.cash += notional - comm
        self.costs_paid += shares * (price - fill) + comm
        self.turnover += notional
        p.proceeds_total += notional - comm
        p.shares -= shares
        if p.shares <= 1e-9:
            self._close_record(i, p, fill, reason)
            del self.positions[sym]
            if reason == "stop":
                self.stopped_out[sym] = str(self.m.dates[i].date())

    def _close_record(self, i: int, p: Position, fill: float, reason: str) -> None:
        pnl = p.proceeds_total - p.cost_total
        r_mult = pnl / p.initial_risk if p.initial_risk > 0 else float("nan")
        self.trades.append({
            "track": self.track, "symbol": p.symbol, "sleeve": p.sleeve, "signal_date": p.signal_date,
            "entry_date": p.entry_date, "entry_price": p.entry_price, "exit_date": str(self.m.dates[i].date()),
            "exit_price": fill, "exit_reason": reason, "shares": p.max_shares, "pnl": pnl,
            "return_pct": pnl / p.cost_total if p.cost_total else 0.0,
            "contribution": pnl / p.entry_equity if p.entry_equity else 0.0,
            "r_multiple": r_mult, "initial_stop": p.initial_stop, "target": p.target,
            "exit_due": p.exit_due, "reasons": "+".join(p.reasons), "asset_class": p.asset_class,
            "risk_profile": self.p.risk_name, "leverage_profile": self.p.lev_name, "rr": self.p.rr,
            "holding_days": self._trading_days_since(i, p.entry_date) + 1,
        })
        self.day_exits.append(Signal(
            track=self.track, date=str(self.m.dates[i].date()), symbol=p.symbol, action="SELL", ref_price=fill,
            stop=p.stop, target=p.target, exit_due=p.exit_due, size_pct=0.0, risk_pct=0.0, reward_pct=0.0,
            rr=self.p.rr, reasons=[reason], regime="", breaker=self.breaker.state, sleeve=p.sleeve,
            asset_class=p.asset_class, executed=True, note=f"exit {reason} R={r_mult:.2f}" if math.isfinite(r_mult) else f"exit {reason}",
        ))

    def _liquidate_all(self, i: int, prices: str, reason: str) -> None:
        arr = self.m.open if prices == "open" else self.m.close_ff
        for s in list(self.positions):
            j = self.m.col[s]
            px = arr[i, j] if math.isfinite(arr[i, j]) else self.m.close_ff[i, j]
            self._sell(i, s, self.positions[s].shares, float(px), reason)

    def _margin_check(self, i: int, prices: str) -> None:
        if self.p.instrument != "cfd" or not self.positions:
            eq = self._equity(i, prices)
            if eq <= 0 and self.positions:
                self._liquidate_all(i, prices, "margin_stop_out")
                self._wipe(i)
            return
        arr = self.m.open if prices == "open" else self.m.close_ff
        used = 0.0
        for s, p in self.positions.items():
            j = self.m.col[s]
            px = arr[i, j] if math.isfinite(arr[i, j]) else self.m.close_ff[i, j]
            used += p.shares * px / float(self.rs.esma_max.get(p.asset_class, 5.0))
        eq = self._equity(i, prices)
        if used > 0 and eq < self.rs.margin_stop_out_level * used:
            self.margin_calls += 1
            self._event(i, "margin_stop_out", f"equity {eq:,.0f} < {self.rs.margin_stop_out_level:.0%} of margin {used:,.0f}")
            self._liquidate_all(i, prices, "margin_stop_out")
            self._wipe(i)

    def _wipe(self, i: int) -> None:
        if self.cash <= 0:  # ESMA negative balance protection: losses capped at the deposit
            self.cash = 0.0
            self.wiped = True
            self._event(i, "account_wiped", "equity <= 0 (negative balance protection)")

    # ------------------------------------------------------------------- step
    def step(self, i: int) -> Decision | None:
        m = self.m
        d = m.dates[i]
        self.day_exits = []
        # 1. financing for the night(s) since the previous close
        if self.last_i is not None and self.positions:
            nights = max(1, (d - m.dates[self.last_i]).days)
            if self.p.instrument == "cfd":
                notional = sum(p.shares * self._price(self.last_i, m.col[s]) for s, p in self.positions.items())
                fee = notional * self.p.financing_annual * nights / self.p.day_count
            else:
                fee = max(0.0, -self.cash) * self.p.financing_annual * nights / 360.0
            self.cash -= fee
            self.financing_paid += fee
        # 2. open: execute pending orders
        orders, self.pending = self.pending, []
        sells = [o for o in orders if o.action in ("SELL", "RESIZE")]
        buys = [o for o in orders if o.action == "BUY"]
        for o in sells:
            if o.symbol not in self.positions:
                continue
            j = m.col[o.symbol]
            px = m.open[i, j]
            if not math.isfinite(px):
                self.pending.append(o)  # no bar today -> retry next session
                continue
            p = self.positions[o.symbol]
            qty = p.shares if o.action == "SELL" else max(0.0, p.shares - o.shares)
            if qty > 0:
                self._sell(i, o.symbol, qty, float(px), o.reason or "signal_exit")
        for o in buys:
            j = m.col[o.symbol]
            px = m.open[i, j]
            if self.wiped or not math.isfinite(px):
                continue
            if o.symbol in self.positions:
                p = self.positions[o.symbol]
                if p.sleeve == o.sleeve and o.shares > p.shares:
                    self._buy(i, Order(o.symbol, "BUY", o.shares - p.shares, o.sleeve, p.stop, p.target,
                                       p.exit_due, p.reasons), float(px))
                continue
            if self.rs.skip_gap_through_stop and px <= o.stop:
                self._event(i, "skip_entry", f"{o.symbol} gap through stop at open")
                continue
            if o.target is not None and px >= o.target:
                self._event(i, "skip_entry", f"{o.symbol} gap above target at open")
                continue
            self._buy(i, o, float(px))
        self._margin_check(i, "open")
        # 3. intraday resting stop / target orders
        for s in list(self.positions):
            p = self.positions[s]
            j = m.col[s]
            res = R.resolve_intraday_exit(m.open[i, j], m.high[i, j], m.low[i, j], p.stop, p.target)
            if res is not None:
                self._sell(i, s, p.shares, res[1], res[0])
        # 4. close
        for s in list(self.positions):
            p = self.positions[s]
            j = m.col[s]
            c = m.close[i, j]
            if not math.isfinite(c):
                p.missing_days += 1
                if p.missing_days >= 3:
                    self._sell(i, s, p.shares, p.last_close, "data_missing")
                continue
            p.missing_days = 0
            p.last_close, p.last_close_date = float(c), str(d.date())
            if pd.Timestamp(p.exit_due) <= d:
                if self._can_roll(i, p):
                    p.roll_planned = False
                    p.exit_due = self._exit_due(i, self.H)
                    if p.sleeve == "core":
                        p.stop = max(p.stop, float(c) - float(self.t["stop_atr_mult"]) * m.atr[i, j]) \
                            if math.isfinite(m.atr[i, j]) else p.stop
                        p.target = R.target_price(float(c), p.stop, self.p.rr) if p.stop < c else p.target
                else:
                    self._sell(i, s, p.shares, float(c), "time")
        self._margin_check(i, "close")
        self.equity = self._equity(i)
        regime = bool(m.regime[i])
        self.ec_hist.append(self.equity)
        if len(self.ec_hist) > 400:
            del self.ec_hist[:-400]
        ev = self.breaker.update(self.equity, regime, self.ec_hist, bool(m.bench_sma20_ok[i]))
        if ev:
            self._event(i, "circuit_breaker", ev)
        if self.use_ec:
            new_mult = R.equity_curve_multiplier(self.ec_hist, self.rs.ec_sma_days, self.rs.ec_cut)
            if new_mult != self.ec_mult:
                self._event(i, "equity_curve_filter", "risk cut" if new_mult < 1 else "risk restored")
            self.ec_mult = new_mult
        blocked, why = self.limits.update(d, self.equity, self.p.risk_per_trade)
        self.blocked = why if blocked else None
        if self.t.get("use_trailing", False):
            mult = float(self.t.get("trailing_atr_mult", 3.0))
            for s, p in self.positions.items():
                j = m.col[s]
                c = m.close[i, j]
                if p.sleeve == "core" and math.isfinite(c):
                    p.highest_close = max(p.highest_close, float(c))
                    p.stop = R.trail_stop(p.stop, p.highest_close, m.atr[i, j], mult)
        gross = sum(p.shares * self._price(i, m.col[s]) for s, p in self.positions.items())
        core_gross = sum(p.shares * self._price(i, m.col[s]) for s, p in self.positions.items() if p.sleeve == "core")
        self.nav.append({
            "date": d, "equity": self.equity, "gross": gross / self.equity if self.equity > 0 else 0.0,
            "core_gross": core_gross / self.equity if self.equity > 0 else 0.0,
            "n_positions": len(self.positions), "regime": int(regime), "breaker": self.breaker.state,
            "open_risk": self._open_risk(), "blocked": int(self.blocked is not None), "ec_mult": self.ec_mult,
        })
        self.last_i = i
        dec = self.decide(i)
        if self.keep_decisions and dec is not None:
            self.decisions.append(dec)
        return dec

    def _can_roll(self, i: int, p: Position) -> bool:
        if p.sleeve == "defensive":
            return True  # the defensive sleeve is re-evaluated in decide()
        # decided at the PREVIOUS close (decide() sets roll_planned the evening before exit_due), so the
        # market-on-close exit never depends on the close it trades at - and paper/live can skip the MOC
        return bool(self.t.get("roll_on_time_exit", False) and p.roll_planned)

    def _open_risk(self) -> float:
        """Sum of risk-at-stop (from entry; 0 once the stop is above entry) / equity."""
        if self.equity <= 0:
            return 0.0
        r = sum(max(0.0, p.entry_price - p.stop) * p.shares for p in self.positions.values() if p.sleeve == "core")
        return r / self.equity

    # ----------------------------------------------------------------- decide
    def decide(self, i: int) -> Decision:
        m, rs, t, p = self.m, self.rs, self.t, self.p
        # per-track overrides of portfolio limits (short mean-reversion tracks hold many small positions)
        mor = float(t.get("max_open_risk_r", rs.max_open_risk_r))
        maxpos = int(t.get("max_positions", rs.max_positions))
        maxcorr = float(t.get("max_corr", rs.max_corr))
        d = m.dates[i]
        iso = str(d.date())
        regime = bool(m.regime[i])
        rlabel = "risk_on" if regime else "risk_off"
        mult = self.breaker.multiplier
        lev_eff = R.effective_leverage(p.leverage, regime, rs.risk_off_max_leverage)
        # equity-curve filter halves the risk of NEW entries (no forced resizing -> less churn)
        risk = p.risk_per_trade * mult * self.ec_mult
        regime_ok = regime or not t.get("regime_filter", True)
        gross_cap = lev_eff * (1.0 if regime_ok else rs.risk_off_max_gross) * mult
        eq = self.equity
        signals: list[Signal] = list(self.day_exits)
        for s_ in signals:
            s_.regime = rlabel
        skipped: dict[str, str] = {}
        events: list[str] = []
        dec = Decision(self.track, iso, signals, rlabel, float(m.regime_gap[i]), self.breaker.state, None,
                       self.blocked, eq, events, skipped)
        if self.keep_decisions or i == len(m.dates) - 1:
            dec.regime_note = regime_note(m, i)
        if self.wiped or eq <= 0:
            dec.kill = "account wiped"
            return dec
        kill = self.kill.check(i, m.diag, self.sig.raw_count, len(m.symbols))
        if kill:
            self._event(i, "kill_switch", kill)
            dec.kill = kill
            dec.signals = []
            return dec

        def price(j: int) -> float:
            return self._price(i, j)

        # ---- exits of core positions (executed next open)
        core = {s: q for s, q in self.positions.items() if q.sleeve == "core"}
        exits: dict[str, str] = {}
        for s, q in core.items():
            j = m.col[s]
            if not math.isfinite(m.close[i, j]):
                continue
            reason = None
            if any(self.sig.strat_exit.get(r_) is not None and self.sig.strat_exit[r_][i, j] for r_ in q.reasons):
                reason = "signal_exit"
            elif t.get("exit_on_signal_loss", False) and self.sig.agree[i, j] < int(t.get("exit_min_agree", 1)):
                reason = "signal_lost"
            if gross_cap <= 0:
                reason = "circuit_breaker"
            if reason:
                exits[s] = reason
        kept = {s: q for s, q in core.items() if s not in exits}
        cur_w = {s: q.shares * price(m.col[s]) / eq for s, q in kept.items()}
        open_risk = sum(max(0.0, q.entry_price - q.stop) * q.shares for q in kept.values()) / eq
        # ---- new entries
        new: list[dict[str, Any]] = []
        n_new_max = int(t.get("max_new_entries_per_day", 3))
        if self.blocked:
            events.append(f"no new entries: {self.blocked}")
        elif gross_cap > 0:
            cand = np.nonzero(self.sig.entry[i])[0]
            if len(cand):
                # rank by expected R, then number of agreeing strategies, then score rank
                er = self.sig.exp_r[i, cand] if self.sig.exp_r is not None else np.zeros(len(cand))
                er = np.where(np.isfinite(er), er, -9.0)
                order = np.lexsort((-self.sig.rank_score[i, cand], -self.sig.agree[i, cand], -er))
                cand = cand[order]
            split = bool(t.get("split_open_risk", False))
            slots = n_new_max
            gross_used = sum(cur_w.values())
            sect_used: dict[str, float] = {}
            for s, w in cur_w.items():
                sect_used[m.sector[m.col[s]]] = sect_used.get(m.sector[m.col[s]], 0.0) + w
            W = rs.corr_window
            lo = max(0, i - W + 1)
            hold_rets = {s: m.logret[lo:i + 1, m.col[s]] for s in kept}
            for j in cand:
                s = m.symbols[j]
                if len(new) >= n_new_max:
                    break
                if len(kept) + len(new) >= maxpos:
                    skipped[s] = "max_positions"
                    break
                if s in self.positions:
                    continue
                c = m.close[i, j]
                a = m.atr[i, j]
                if not (math.isfinite(c) and math.isfinite(a) and a > 0):
                    skipped[s] = "no_data"
                    continue
                if not m.liquid[i, j]:
                    skipped[s] = "liquidity"
                    continue
                if m.diag["quarantine"][i, j]:
                    skipped[s] = "quarantine_price_jump"
                    continue
                if s in self.stopped_out and self._trading_days_since(i, self.stopped_out[s]) < self.cooldown:
                    skipped[s] = "cooldown"
                    continue
                if m.earnings is not None and m.earnings[i, j]:
                    skipped[s] = "earnings_blackout"
                    continue
                if gross_cap - gross_used < rs.min_position_pct or \
                        mor * risk - open_risk <= 1e-9:
                    skipped[s] = "no_capacity(gross/open_risk)"
                    break
                stop = R.initial_stop(float(c), float(a), float(t["stop_atr_mult"]))
                if stop <= 0:
                    skipped[s] = "invalid_stop"
                    continue
                dist = (c - stop) / c
                lev_a = R.asset_leverage_cap(m.asset_class[j], lev_eff, rs.esma_max)
                risk_j = risk
                if split:  # share the remaining open-risk budget among today's remaining slots
                    remaining = max(0.0, mor * risk - open_risk)
                    risk_j = min(risk, remaining / max(1, min(slots - len(new), len(cand))))
                w = R.position_notional(risk_j, float(c), stop, lev_a, rs.max_position_pct)
                w = min(w, gross_cap - gross_used)
                w = min(w, max(0.0, mor * risk - open_risk) / dist)
                sec = m.sector[j]
                w = min(w, rs.max_sector_pct * max(gross_cap, 1e-9) - sect_used.get(sec, 0.0))
                if w < rs.min_position_pct:
                    skipped[s] = "no_capacity(gross/open_risk/sector)"
                    continue
                corr = R.correlated_with(m.logret[lo:i + 1, j], hold_rets, maxcorr)
                if corr:
                    skipped[s] = f"corr>{maxcorr} with {corr}"
                    continue
                er_j = float(self.sig.exp_r[i, j]) if self.sig.exp_r is not None and math.isfinite(self.sig.exp_r[i, j]) else 0.0
                new.append({"j": j, "s": s, "w": w, "stop": stop, "c": float(c), "dist": dist, "lev": lev_a, "er": er_j, "rb": risk_j})
                gross_used += w
                open_risk += w * dist
                sect_used[sec] = sect_used.get(sec, 0.0) + w
                hold_rets[s] = m.logret[lo:i + 1, j]
        # ---- portfolio volatility target + gross cap (scale down only)
        resized: dict[str, float] = {}
        syms_book = list(kept) + [n["s"] for n in new]
        if syms_book:
            wv = np.array([cur_w[s] for s in kept] + [n["w"] for n in new])
            lo = max(0, i - rs.cov_window + 1)
            rets = m.logret[lo:i + 1][:, [m.col[s] for s in syms_book]]
            est = R.portfolio_vol(wv, rets)
            vol_cap = rs.target_vol * lev_eff
            scale = min(1.0, vol_cap / est) if est > 0 else 1.0
            tot = float(wv.sum())
            if tot > gross_cap > 0:
                scale = min(scale, gross_cap / tot)
            if scale < 1.0:
                for n in new:
                    n["w"] *= scale
                new = [n for n in new if n["w"] >= rs.min_position_pct]
                for s in list(kept):
                    tgt = cur_w[s] * scale
                    if tgt < cur_w[s] * (1 - rs.rebalance_band):
                        q = kept[s]
                        self.pending.append(Order(s, "RESIZE", q.shares * scale, reason="risk_reduce"))
                        cur_w[s] = tgt
                        resized[s] = tgt
        # ---- emit core orders + signals
        H = self.H
        due = self._exit_due(i, H)
        for s, why in exits.items():
            q = self.positions[s]
            j = m.col[s]
            self.pending.append(Order(s, "SELL", 0.0, reason=why))
            signals.append(self._mk_signal(iso, s, "SELL", price(j), q.stop, q.target, q.exit_due, 0.0, 0.0, 0.0,
                                           [why], rlabel, "core", j, lev_eff))
        for s, q in kept.items():
            j = m.col[s]
            c = price(j)
            w = cur_w[s]
            rk = max(0.0, (c - q.stop) / c) * w if c > 0 else 0.0
            rw = max(0.0, ((q.target or c) - c) / c) * w if c > 0 else 0.0
            hs = self._mk_signal(iso, s, "HOLD", c, q.stop, q.target, q.exit_due, w, rk, rw,
                                 q.reasons, rlabel, "core", j, lev_eff)
            if pd.Timestamp(q.exit_due) <= pd.Timestamp(self._exit_due(i, 1)):   # time exit due next session
                q.roll_planned = bool(t.get("roll_on_time_exit", False) and self.sig.entry[i, j]
                                      and not self.blocked and self.breaker.state == "normal")
                hs.rolls = q.roll_planned
                hs.note = (hs.note + "; " if hs.note else "") + (
                    "prodloužení držení (signál trvá)" if q.roll_planned else "časový výstup na zavření příští seance")
            if s in resized:
                hs.note = f"snížit pozici na {resized[s] * 100:.1f} % účtu"
            signals.append(hs)
        for n in new:
            j, s = n["j"], n["s"]
            tgt = R.target_price(n["c"], n["stop"], p.rr)
            reasons = [k for k, arr in self.sig.strat_entry.items() if arr[i, j]]
            shares = n["w"] * eq / n["c"]
            self.pending.append(Order(s, "BUY", shares, "core", n["stop"], tgt, due, reasons, iso, n["c"]))
            rw = (tgt - n["c"]) / n["c"] * n["w"] if tgt else 0.0
            sg = self._mk_signal(iso, s, "BUY", n["c"], n["stop"], tgt, due, n["w"], n["w"] * n["dist"],
                                 rw, reasons, rlabel, "core", j, n["lev"])
            sg.exp_r = n["er"]
            sg.risk_budget = n["rb"]
            signals.append(sg)
        # ---- defensive sleeve (MESIC): dual momentum / cash proxy
        if t.get("defensive_sleeve", False):
            self._defensive(i, iso, regime, rlabel, kept, cur_w, new, signals, due)
        return dec

    def _defensive(self, i: int, iso: str, regime: bool, rlabel: str, kept: dict[str, Position],
                   cur_w: dict[str, float], new: list[dict[str, Any]], signals: list[Signal], due: str) -> None:
        m, rs = self.m, self.rs
        eq = self.equity
        desired: dict[str, float] = {}
        core_after = sum(cur_w.values()) + sum(n["w"] for n in new)
        cash_sym = m.symbols[m.cash_col] if m.cash_col is not None else None
        if self.p.instrument == "cfd":
            # a CFD on a T-bill ETF pays benchmark+markup financing on its full notional while yielding
            # ~the benchmark: "cash" in a CFD account is simply uninvested cash
            cash_sym = None
        if self.breaker.state in ("cash", "locked"):
            if cash_sym:
                desired[cash_sym] = 0.98
        elif not regime:
            room = max(0.0, 1.0 - core_after) * self.breaker.multiplier
            cash_r = float(m.ret12[i, m.cash_col]) if m.cash_col is not None else 0.0   # T-bill hurdle
            r12 = {s: float(m.ret12[i, m.col[s]]) for s in rs.defensive_assets if s in m.col}
            picks = [s for s in R.select_defensive(r12, cash_r, rs.defensive_top_n) if s not in kept]
            left = room
            for s in picks:
                w = min(rs.defensive_max_weight, room / max(1, len(picks)))
                desired[s] = w
                left -= w
            if cash_sym and left > rs.min_position_pct:
                desired[cash_sym] = left * 0.98
        held_def = {s: q for s, q in self.positions.items() if q.sleeve == "defensive"}
        for s, q in held_def.items():
            j = m.col[s]
            if s not in desired:
                self.pending.append(Order(s, "SELL", 0.0, reason="regime_rebalance"))
                signals.append(self._mk_signal(iso, s, "SELL", self._price(i, j), q.stop, None, q.exit_due, 0.0,
                                               0.0, 0.0, ["regime_rebalance"], rlabel, "defensive", j, 1.0))
        for s, w in desired.items():
            j = m.col[s]
            c = self._price(i, j)
            if not math.isfinite(c) or c <= 0:
                continue
            a = m.atr[i, j] if math.isfinite(m.atr[i, j]) else 0.0
            stop = c - max(3.0 * a, 0.03 * c)
            shares = w * eq / c
            why = ["cash_proxy"] if s == cash_sym else ["dual_momentum"]
            if s in held_def:
                q = held_def[s]
                cw = q.shares * c / eq
                q.stop = max(q.stop, stop)
                if abs(cw - w) > rs.rebalance_band * w:
                    self.pending.append(Order(s, "RESIZE" if w < cw else "BUY", shares, "defensive", q.stop,
                                              None, q.exit_due, why, iso, c, reason="rebalance"))
                signals.append(self._mk_signal(iso, s, "HOLD", c, q.stop, None, q.exit_due, w, 0.0, 0.0, why,
                                               rlabel, "defensive", j, 1.0))
            elif s not in self.positions:
                self.pending.append(Order(s, "BUY", shares, "defensive", stop, None, due, why, iso, c))
                signals.append(self._mk_signal(iso, s, "BUY", c, stop, None, due, w, w * (c - stop) / c, 0.0, why,
                                               rlabel, "defensive", j, 1.0))

    def _mk_signal(self, iso: str, s: str, action: str, ref: float, stop: float, target: float | None, due: str,
                   size: float, risk_pct: float, reward_pct: float, reasons: list[str], rlabel: str, sleeve: str,
                   j: int, lev: float) -> Signal:
        return Signal(track=self.track, date=iso, symbol=s, action=action, ref_price=float(ref), stop=float(stop),
                      target=float(target) if target is not None else None, exit_due=due, size_pct=float(size),
                      risk_pct=float(risk_pct), reward_pct=float(reward_pct),
                      rr=self.p.rr if sleeve == "core" else None, reasons=list(reasons), regime=rlabel,
                      breaker=self.breaker.state, sleeve=sleeve, asset_class=self.m.asset_class[j],
                      max_leverage=float(R.asset_leverage_cap(self.m.asset_class[j],
                                                              R.effective_leverage(self.p.leverage, rlabel == "risk_on",
                                                                                   self.rs.risk_off_max_leverage),
                                                              self.rs.esma_max)))

    # ------------------------------------------------------------------ run
    def run(self, start: int, end: int | None = None) -> "Engine":
        end = len(self.m.dates) - 1 if end is None else end
        for i in range(start, end + 1):
            self.step(i)
        return self

    def nav_frame(self) -> pd.DataFrame:
        if not self.nav:
            return pd.DataFrame(columns=["equity"])
        return pd.DataFrame(self.nav).set_index("date")

    def trades_frame(self) -> pd.DataFrame:
        return pd.DataFrame(self.trades)

    # ------------------------------------------------------- persistence (live)
    def to_state(self) -> dict[str, Any]:
        return {
            "cash": self.cash, "equity": self.equity, "initial_capital": self.initial_capital,
            "positions": {s: asdict(p) for s, p in self.positions.items()},
            "pending": [asdict(o) for o in self.pending],
            "breaker": self.breaker.to_dict(), "limits": self.limits.to_dict(),
            "stopped_out": self.stopped_out, "wiped": self.wiped,
            "ec_hist": self.ec_hist[-max(self.rs.ec_sma_days, 1):], "ec_mult": self.ec_mult,
            "last_date": str(self.m.dates[self.last_i].date()) if self.last_i is not None else None,
            "profile": asdict(self.p),
        }

    def load_state(self, st: dict[str, Any]) -> list[str]:
        """Restore state; rescales stored prices when the adjusted history changed (splits/dividends)."""
        notes: list[str] = []
        self.cash = float(st["cash"])
        self.equity = float(st.get("equity", self.cash))
        self.positions = {s: Position(**p) for s, p in st.get("positions", {}).items()}
        self.pending = [Order(**o) for o in st.get("pending", [])]
        self.breaker.load(st.get("breaker", {}))
        self.limits.load(st.get("limits", {}))
        self.stopped_out = dict(st.get("stopped_out", {}))
        self.wiped = bool(st.get("wiped", False))
        self.ec_hist = [float(x) for x in st.get("ec_hist", [])]
        self.ec_mult = float(st.get("ec_mult", 1.0))
        ld = st.get("last_date")
        if ld:
            k = int(self.m.dates.searchsorted(pd.Timestamp(ld)))
            if k < len(self.m.dates) and self.m.dates[k] == pd.Timestamp(ld):
                self.last_i = k
            else:
                raise ValueError(f"state last_date {ld} not in price calendar")
        for o in [o for o in self.pending if o.symbol not in self.m.col]:
            self.pending.remove(o)
            notes.append(f"{o.symbol}: pending {o.action} dropped (symbol not in the price data)")
        if self.last_i is not None:
            for s in [s for s in self.positions if s not in self.m.col]:
                # symbol left the universe / price data: close at the last stored close instead of
                # crashing on every later session (step() indexes market columns by symbol)
                p = self.positions.pop(s)
                fill = self._fill(p.last_close, "sell", p.asset_class)
                notional = p.shares * fill
                comm = self._commission(notional)
                self.cash += notional - comm
                self.costs_paid += p.shares * (p.last_close - fill) + comm
                p.proceeds_total += notional - comm
                self._close_record(self.last_i, p, fill, "data_missing")
                notes.append(f"{s}: closed at last stored close {p.last_close:.4f} (symbol not in the price data)")
        factors: dict[str, float] = {}
        for s, p in list(self.positions.items()):
            if s not in self.m.col or not p.last_close_date:
                continue
            k = int(self.m.dates.searchsorted(pd.Timestamp(p.last_close_date)))
            if k >= len(self.m.dates):
                continue
            now = self.m.close_ff[k, self.m.col[s]]
            if math.isfinite(now) and p.last_close > 0:
                f = now / p.last_close
                if abs(f - 1) > 1e-4:
                    for attr in ("entry_price", "initial_stop", "stop", "highest_close", "last_close", "signal_ref"):
                        setattr(p, attr, getattr(p, attr) * f)
                    if p.target is not None:
                        p.target *= f
                    p.shares /= f
                    p.max_shares /= f
                    factors[s] = f
                    notes.append(f"{s}: rescaled stored prices by {f:.6f} (split/dividend adjustment)")
        # pending orders were sized/priced in the same (old) adjusted price space -> rescale them too
        for o in self.pending:
            f = factors.get(o.symbol)
            if f is None and o.ref_price > 0 and o.signal_date:
                k = int(self.m.dates.searchsorted(pd.Timestamp(o.signal_date)))
                if k < len(self.m.dates) and self.m.dates[k] == pd.Timestamp(o.signal_date):
                    now = self.m.close_ff[k, self.m.col[o.symbol]]
                    if math.isfinite(now) and abs(now / o.ref_price - 1) > 1e-4:
                        f = now / o.ref_price
            if f is None:
                continue
            o.stop *= f
            o.ref_price *= f
            if o.target is not None:
                o.target *= f
            o.shares /= f
            notes.append(f"{o.symbol}: rescaled pending {o.action} by {f:.6f}")
        return notes
