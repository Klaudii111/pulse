"""SQLite journal - the immutable track record.

nav.bench_close holds the benchmark (SPY) TOTAL-RETURN index, chained from adjusted closes.

Tables signals / outcomes / nav / alerts / intraday_events are APPEND-ONLY:
SQLite triggers abort every UPDATE and DELETE, and each row carries a SHA-256
hash chained to the previous row of the same table (tamper evidence,
`verify()`). The `state` table holds the mutable model-portfolio state and is
NOT part of the track record.
"""
from __future__ import annotations

import hashlib
import json
import math
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

APPEND_ONLY = ("signals", "outcomes", "nav", "alerts", "intraday_events")

SCHEMA = {
    "signals": """id INTEGER PRIMARY KEY AUTOINCREMENT, created_utc TEXT NOT NULL, track TEXT NOT NULL,
        signal_date TEXT NOT NULL, symbol TEXT NOT NULL, name TEXT, action TEXT NOT NULL CHECK(action IN ('BUY','SELL','HOLD')),
        ref_price REAL, stop REAL, target REAL, exit_due TEXT, size_pct REAL, risk_pct REAL, reward_pct REAL, rr REAL,
        max_leverage REAL, exp_r REAL, reasons TEXT, regime TEXT, breaker TEXT, sleeve TEXT, asset_class TEXT,
        executed INTEGER, published INTEGER, meta TEXT, prev_hash TEXT, hash TEXT""",
    "outcomes": """id INTEGER PRIMARY KEY AUTOINCREMENT, created_utc TEXT NOT NULL, track TEXT NOT NULL, signal_id INTEGER,
        symbol TEXT NOT NULL, sleeve TEXT, entry_date TEXT, entry_price REAL, exit_date TEXT, exit_price REAL,
        exit_reason TEXT, return_pct REAL, r_multiple REAL, pnl REAL, contribution REAL, meta TEXT, prev_hash TEXT, hash TEXT""",
    "nav": """id INTEGER PRIMARY KEY AUTOINCREMENT, created_utc TEXT NOT NULL, track TEXT NOT NULL, date TEXT NOT NULL,
        equity REAL, gross REAL, regime INTEGER, breaker TEXT, bench_close REAL, prev_hash TEXT, hash TEXT""",
    "alerts": """id INTEGER PRIMARY KEY AUTOINCREMENT, created_utc TEXT NOT NULL, track TEXT, date TEXT, kind TEXT,
        message TEXT, prev_hash TEXT, hash TEXT""",
    "intraday_events": """id INTEGER PRIMARY KEY AUTOINCREMENT, created_utc TEXT NOT NULL, track TEXT, signal_id INTEGER,
        symbol TEXT, kind TEXT, level_price REAL, hit_at TEXT, last_price REAL, prev_hash TEXT, hash TEXT""",
}


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _clean(v: Any) -> Any:
    if isinstance(v, bool):
        return int(v)
    if hasattr(v, "item") and not isinstance(v, (list, dict, str)):
        v = v.item()
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, float) and not math.isfinite(v):
        return None
    if isinstance(v, (list, dict)):
        return json.dumps(v, ensure_ascii=False, sort_keys=True)
    if hasattr(v, "item"):
        return v.item()
    return v


def _norm(col_type: str, v: Any) -> Any:
    """Canonical value by declared column type (so the hash survives the SQLite round trip)."""
    if v is None:
        return None
    if col_type == "REAL":
        return float(v)
    if col_type == "INTEGER":
        return int(v)
    return str(v)


class JournalError(RuntimeError):
    pass


class Journal:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.in_memory = str(path) == ":memory:"
        if not self.in_memory:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        self.con = sqlite3.connect(str(path))
        self.con.row_factory = sqlite3.Row
        self._init()

    @classmethod
    def in_memory_copy(cls, path: str | Path) -> "Journal":
        """Throw-away in-memory copy of a journal (used by --dry-run: nothing is written to disk)."""
        j = cls(":memory:")
        p = Path(path)
        if str(path) != ":memory:" and p.exists():
            src = sqlite3.connect(str(p))
            try:
                src.backup(j.con)
            finally:
                src.close()
            j._init()
        return j

    def close(self) -> None:
        self.con.close()

    def _init(self) -> None:
        cur = self.con.cursor()
        for t, cols in SCHEMA.items():
            cur.execute(f"CREATE TABLE IF NOT EXISTS {t} ({cols})")
            for op in ("UPDATE", "DELETE"):
                cur.execute(
                    f"CREATE TRIGGER IF NOT EXISTS {t}_no_{op.lower()} BEFORE {op} ON {t} "
                    f"BEGIN SELECT RAISE(ABORT, 'journal table {t} is append-only'); END;")
        cur.execute("CREATE TABLE IF NOT EXISTS state (track TEXT PRIMARY KEY, json TEXT NOT NULL, updated_utc TEXT)")
        cur.execute("CREATE INDEX IF NOT EXISTS ix_sig ON signals(track, signal_date, symbol)")
        self.con.commit()

    # ------------------------------------------------------------- append
    def _last_hash(self, table: str) -> str:
        r = self.con.execute(f"SELECT hash FROM {table} ORDER BY id DESC LIMIT 1").fetchone()
        return r["hash"] if r else "GENESIS"

    @staticmethod
    def _digest(prev: str, row: dict[str, Any]) -> str:
        payload = json.dumps({k: row[k] for k in sorted(row)}, ensure_ascii=False, sort_keys=True, default=str)
        return hashlib.sha256((prev + "|" + payload).encode("utf-8")).hexdigest()

    def append(self, table: str, row: dict[str, Any]) -> int:
        if table not in APPEND_ONLY:
            raise JournalError(f"unknown table {table}")
        types = self._types(table)
        unknown = set(row) - set(types)
        if unknown:
            raise JournalError(f"unknown columns for {table}: {sorted(unknown)}")
        r = {c: _norm(types[c], _clean(row.get(c))) for c in types}
        if not r.get("created_utc"):
            r["created_utc"] = _now()
        prev = self._last_hash(table)
        r["prev_hash"] = prev
        r["hash"] = self._digest(prev, {k: v for k, v in r.items() if k not in ("prev_hash", "hash")})
        cols = ",".join(r)
        q = ",".join("?" for _ in r)
        cur = self.con.execute(f"INSERT INTO {table} ({cols}) VALUES ({q})", list(r.values()))
        self.con.commit()
        return int(cur.lastrowid)

    def _types(self, table: str) -> dict[str, str]:
        return {c[1]: str(c[2]).upper() for c in self.con.execute(f"PRAGMA table_info({table})")
                if c[1] not in ("id", "prev_hash", "hash")}

    def verify(self) -> dict[str, bool]:
        """Recompute every hash chain. False = a row was modified outside this API."""
        out = {}
        for t in APPEND_ONLY:
            prev = "GENESIS"
            ok = True
            for row in self.con.execute(f"SELECT * FROM {t} ORDER BY id"):
                d = dict(row)
                h, ph = d.pop("hash"), d.pop("prev_hash")
                d.pop("id")
                types = self._types(t)
                d = {k: _norm(types.get(k, ""), v) for k, v in d.items()}
                if ph != prev or self._digest(prev, d) != h:
                    ok = False
                    break
                prev = h
            out[t] = ok
        return out

    # ------------------------------------------------------------- domain
    def record_signal(self, sig: Any, name: str = "", published: bool = True, meta: dict[str, Any] | None = None,
                      created_utc: str | None = None) -> int:
        d = sig.to_dict() if hasattr(sig, "to_dict") else dict(sig)
        return self.append("signals", {"created_utc": created_utc,
            "track": d["track"], "signal_date": d["date"], "symbol": d["symbol"], "name": name, "action": d["action"],
            "ref_price": d["ref_price"], "stop": d["stop"], "target": d.get("target"), "exit_due": d.get("exit_due"),
            "size_pct": d.get("size_pct"), "risk_pct": d.get("risk_pct"), "reward_pct": d.get("reward_pct"),
            "rr": d.get("rr"), "max_leverage": d.get("max_leverage"), "exp_r": d.get("exp_r"),
            "reasons": d.get("reasons", []), "regime": d.get("regime"), "breaker": d.get("breaker"),
            "sleeve": d.get("sleeve"), "asset_class": d.get("asset_class"), "executed": int(bool(d.get("executed"))),
            "published": int(published), "meta": {**(meta or {}), "risk_budget": d.get("risk_budget"), "note": d.get("note")},
        })

    def find_entry_signal(self, track: str, symbol: str, signal_date: str) -> int | None:
        r = self.con.execute("SELECT id FROM signals WHERE track=? AND symbol=? AND signal_date=? AND action='BUY' "
                             "ORDER BY id DESC LIMIT 1", (track, symbol, signal_date)).fetchone()
        return int(r["id"]) if r else None

    def record_outcome(self, trade: dict[str, Any], created_utc: str | None = None) -> int:
        sid = self.find_entry_signal(trade["track"], trade["symbol"], trade.get("signal_date", ""))
        return self.append("outcomes", {"created_utc": created_utc,
            "track": trade["track"], "signal_id": sid, "symbol": trade["symbol"], "sleeve": trade.get("sleeve"),
            "entry_date": trade["entry_date"], "entry_price": trade["entry_price"], "exit_date": trade["exit_date"],
            "exit_price": trade["exit_price"], "exit_reason": trade["exit_reason"], "return_pct": trade["return_pct"],
            "r_multiple": trade.get("r_multiple"), "pnl": trade["pnl"], "contribution": trade.get("contribution"),
            "meta": {"signal_date": trade.get("signal_date")},
        })

    def record_nav(self, track: str, date: str, equity: float, gross: float, regime: int, breaker: str,
                   bench_close: float | None, created_utc: str | None = None) -> int:
        return self.append("nav", {"created_utc": created_utc, "track": track, "date": date, "equity": equity, "gross": gross, "regime": regime,
                                   "breaker": breaker, "bench_close": bench_close})

    def record_alert(self, track: str | None, date: str | None, kind: str, message: str) -> int:
        return self.append("alerts", {"track": track, "date": date, "kind": kind, "message": message})

    def has_signals_for(self, track: str, date: str) -> bool:
        r = self.con.execute("SELECT 1 FROM signals WHERE track=? AND signal_date=? LIMIT 1", (track, date)).fetchone()
        return r is not None

    def frame(self, table: str, where: str = "", params: Iterable[Any] = ()) -> pd.DataFrame:
        q = f"SELECT * FROM {table}" + (f" WHERE {where}" if where else "") + " ORDER BY id"
        return pd.read_sql_query(q, self.con, params=list(params))

    # --------------------------------------------------------------- state
    def load_state(self, track: str) -> dict[str, Any] | None:
        r = self.con.execute("SELECT json FROM state WHERE track=?", (track,)).fetchone()
        return json.loads(r["json"]) if r else None

    def save_state(self, track: str, state: dict[str, Any]) -> None:
        self.con.execute("INSERT INTO state(track, json, updated_utc) VALUES(?,?,?) "
                         "ON CONFLICT(track) DO UPDATE SET json=excluded.json, updated_utc=excluded.updated_utc",
                         (track, json.dumps(state, default=str), _now()))
        self.con.commit()
