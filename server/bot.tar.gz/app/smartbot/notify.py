"""Discord webhook notifications (plain text, Czech labels, no emoji).

One channel/format per horizon (DISCORD_WEBHOOK_URL_<TRACK>, falling back to
DISCORD_WEBHOOK_URL). Every message chunk ends with the mandatory disclaimer and
the CFD/leverage warning. Dry-run prints instead of posting.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Callable

from . import risk as R
from .engine import Decision, Signal

log = logging.getLogger(__name__)

ACTION_CZ = {"BUY": "NÁKUP", "SELL": "PRODEJ", "HOLD": "DRŽET"}
REASON_CZ = {"stop": "stop", "target": "cíl", "time": "časový výstup", "signal_exit": "výstupní signál",
             "signal_lost": "signál zanikl", "circuit_breaker": "jistič ztrát", "regime_rebalance": "změna režimu",
             "margin_stop_out": "margin stop-out", "data_missing": "chybí data", "risk_reduce": "snížení rizika"}
HORIZON_CZ = {"DEN": "1 obch. den", "DNY": "2-3 obch. dny", "TYDEN": "cca 5 obch. dní", "MESIC": "max 21 obch. dní",
              "KRIZE": "krizový sleeve, max 21 obch. dní"}


def _p(x: float | None, digits: int = 2) -> str:
    return "-" if x is None else f"{x:,.{digits}f}".replace(",", " ")


def _pct(x: float | None, digits: int = 1) -> str:
    return "-" if x is None else f"{x * 100:.{digits}f} %"


def leverage_lines(sig: Signal, cfg: dict[str, Any], rs: R.RiskSettings) -> list[str]:
    # Use the full risk budget only when the model account was limited by the per-position notional
    # cap (which grows with leverage); otherwise the signal's own risk (after open-risk/vol caps) applies.
    model_lev = R.effective_leverage(float(cfg["leverage"]["profiles"].get(
        cfg["general"].get("model_leverage_profile", "1x"), {"leverage": 1.0})["leverage"]),
        sig.regime == "risk_on", rs.risk_off_max_leverage)
    cap_model = rs.max_position_pct * R.asset_leverage_cap(sig.asset_class, model_lev, rs.esma_max)
    capped_by_size = sig.size_pct >= cap_model * 0.999
    risk = (sig.risk_budget or sig.risk_pct) if capped_by_size else sig.risk_pct
    out = []
    for lev in cfg.get("notify", {}).get("leverage_lines", [1, 2, 3, 5]):
        ll = R.leverage_line(risk, sig.ref_price, sig.stop, sig.target, float(lev), sig.asset_class, rs.esma_max,
                             rs.max_position_pct, sig.regime == "risk_on", rs.risk_off_max_leverage)
        capped = " (páka omezena)" if ll["effective_leverage"] < float(lev) else ""
        out.append(f"  Při páce {lev:g}x: velikost pozice {ll['notional_pct'] * 100:.1f} % účtu, "
                   f"ztráta při stopu {ll['loss_at_stop_pct'] * 100:.2f} % účtu{capped}")
    return out


def format_signal(sig: Signal, cfg: dict[str, Any], rs: R.RiskSettings) -> list[str]:
    act = ACTION_CZ.get(sig.action, sig.action)
    if sig.action == "SELL":
        why = ", ".join(REASON_CZ.get(r, r) for r in sig.reasons)
        done = " (provedeno)" if sig.executed else " (na otevření)"
        return [f"{act} {sig.symbol} @ {_p(sig.ref_price)} | důvod: {why}{done}" + (f" | {sig.note}" if sig.note else "")]
    lines = [f"{act} {sig.symbol} @ {_p(sig.ref_price)} | stop {_p(sig.stop)} | cíl {_p(sig.target)} | "
             f"výstup nejpozději {sig.exit_due}"]
    if sig.action == "BUY" and sig.sleeve == "defensive":
        lines[0] = f"{act} {sig.symbol} @ {_p(sig.ref_price)} | obranná alokace {_pct(sig.size_pct)} účtu | " \
                   f"stop {_p(sig.stop)} | přehodnocení nejpozději {sig.exit_due}"
        lines.append(f"  Důvody: {', '.join(sig.reasons)} (risk-off / jistič; bez cíle, bez páky)")
        return lines
    if sig.action == "BUY":
        if sig.rr:
            lines.append(f"  Riziko: {_pct(sig.risk_pct, 2)} účtu | Cíl: +{_pct(sig.reward_pct, 2)} účtu | Poměr 1:{sig.rr:.1f}")
        else:
            lines.append(f"  Riziko: {_pct(sig.risk_pct, 2)} účtu | alokace {_pct(sig.size_pct)} (bez cíle)")
        lines += leverage_lines(sig, cfg, rs)
        lines.append(f"  Důvody: {', '.join(sig.reasons)}")
    return lines


def format_decision(dec: Decision, cfg: dict[str, Any], rs: R.RiskSettings, max_chars: int | None = None) -> list[str]:
    """Return message chunks (each <= max_chars, each with the mandatory footer)."""
    ncfg = cfg.get("notify", {})
    max_chars = max_chars or int(ncfg.get("max_message_chars", 1900))
    footer = [ncfg.get("disclaimer", "Automaticky generovaný signál, nejde o investiční doporučení na míru. Riziko ztráty."),
              ncfg.get("cfd_warning", "CFD/páka: většina retailových účtů s pákou prodělává.")]
    tcfg = cfg["tracks"].get(dec.track, {})
    label = tcfg.get("label", dec.track)
    buys = [s for s in dec.signals if s.action == "BUY"]
    exit_date = buys[0].exit_due if buys else "-"
    head = [f"SmartBot | {label} ({HORIZON_CZ.get(dec.track, '')}) | signály k {dec.date} | výstup nejpozději {exit_date}"]
    if tcfg.get("experimental"):
        head.append("EXPERIMENTÁLNÍ horizont - náklady a spread mohou převážit zisk.")
    note = dec.regime_note or ("" if dec.regime_gap != dec.regime_gap else f"SPY {dec.regime_gap * 100:+.1f} % vůči SMA200")
    head.append(f"Režim trhu: {dec.regime} ({note}) | jistič: {dec.breaker}"
                + (" | páka v risk-off omezena na 1x" if dec.regime != "risk_on" else ""))
    body: list[str] = []
    if dec.kill:
        body.append(f"POZOR: kontrola dat selhala ({dec.kill}). Dnes žádné signály.")
    elif dec.blocked:
        body.append(f"Nové vstupy pozastaveny: {dec.blocked}")
    order = {"SELL": 0, "BUY": 1, "HOLD": 2}
    sigs = sorted(dec.signals, key=lambda s: (order.get(s.action, 3), s.symbol))
    holds = [s for s in sigs if s.action == "HOLD"]
    for s in sigs:
        if s.action != "HOLD":
            body += format_signal(s, cfg, rs)
    if holds:
        body.append("DRŽET: " + "; ".join(
            f"{s.symbol} (stop {_p(s.stop)}, cíl {_p(s.target)}, do {s.exit_due}" + (f", {s.note}" if s.note else "") + ")"
            for s in holds))
    if not body:
        body.append("Žádné nové signály.")
    chunks: list[str] = []
    cur = list(head)
    reserve = sum(len(x) + 1 for x in footer) + 8

    def size(lines: list[str]) -> int:
        return sum(len(x) + 1 for x in lines)

    for line in body:
        if size(cur) + len(line) + 1 + reserve > max_chars:
            chunks.append("\n".join(cur + ["---"] + footer))
            cur = [head[0] + " (pokračování)"]
        cur.append(line[: max_chars - reserve - 100])
    chunks.append("\n".join(cur + ["---"] + footer))
    return chunks


def format_alert(track: str, date: str, message: str, cfg: dict[str, Any]) -> str:
    ncfg = cfg.get("notify", {})
    return "\n".join([f"SmartBot ALERT | {track} | {date}", message, "Signály nebyly odeslány.", "---",
                      ncfg.get("disclaimer", ""), ncfg.get("cfd_warning", "")])


class DiscordNotifier:
    def __init__(self, webhook_url: str | None, dry_run: bool = True,
                 post: Callable[..., Any] | None = None, printer: Callable[[str], None] = print) -> None:
        self.url = webhook_url
        self.dry_run = dry_run or not webhook_url
        self._post = post
        self._print = printer

    def send(self, chunks: list[str]) -> int:
        sent = 0
        for c in chunks:
            if len(c) > 2000:
                raise ValueError("Discord message exceeds 2000 characters")
            if self.dry_run:
                self._print("[DRY-RUN] Discord message:\n" + c + "\n")
                sent += 1
                continue
            self._send_one(c)
            sent += 1
        return sent

    def _send_one(self, content: str) -> None:
        post = self._post
        if post is None:
            import requests

            post = requests.post
        payload = {"content": content, "allowed_mentions": {"parse": []}}
        for attempt in range(5):
            r = post(self.url, json=payload, timeout=20)
            code = getattr(r, "status_code", 204)
            if code == 429:
                try:
                    wait = float(r.json().get("retry_after", 1.0))
                except Exception:  # noqa: BLE001
                    wait = 1.0
                time.sleep(min(wait, 30))
                continue
            if code >= 400:
                raise RuntimeError(f"Discord webhook failed: HTTP {code}")
            return
        raise RuntimeError("Discord webhook rate-limited repeatedly")
