"""Performance, smoothness, trade (R) statistics, Monte Carlo and multiple-testing metrics."""
from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd

TD = 252.0


def _rets(equity: pd.Series) -> pd.Series:
    return equity.pct_change().dropna()


def max_drawdown(equity: pd.Series | np.ndarray) -> float:
    e = np.asarray(equity, dtype=float)
    if e.size == 0:
        return 0.0
    peak = np.maximum.accumulate(e)
    with np.errstate(all="ignore"):
        dd = np.where(peak > 0, e / peak - 1.0, -1.0)
    return float(np.nanmin(dd))


def ulcer_index(equity: pd.Series) -> float:
    """Root-mean-square percentage drawdown (Martin 1987), in %."""
    e = equity.to_numpy(dtype=float)
    if e.size == 0:
        return 0.0
    dd = (e / np.maximum.accumulate(e) - 1.0) * 100.0
    return float(np.sqrt(np.mean(dd ** 2)))


def longest_drawdown_days(equity: pd.Series) -> int:
    """Longest time (trading days) from a peak until a new high (or the end)."""
    e = equity.to_numpy(dtype=float)
    peak, start, best = -np.inf, 0, 0
    for k, v in enumerate(e):
        if v >= peak:
            peak, start = v, k
        else:
            best = max(best, k - start)
    return int(best)


def r2_log_equity(equity: pd.Series) -> float:
    """Signed R^2 of log(equity) vs time (+1 = perfectly straight rising line, -1 = straight falling)."""
    e = equity.to_numpy(dtype=float)
    e = e[np.isfinite(e) & (e > 0)]
    if e.size < 3:
        return float("nan")
    y = np.log(e)
    x = np.arange(len(y), dtype=float)
    if np.std(y) == 0:
        return 0.0                      # flat equity (e.g. a locked / all-cash period)
    c = np.corrcoef(x, y)[0, 1]
    # signed: a perfectly straight FALLING line scores -1
    return float(np.sign(c) * c * c) if np.isfinite(c) else float("nan")


def performance(equity: pd.Series, rf_annual: float = 0.0) -> dict[str, float]:
    """Return / risk / smoothness metrics of a daily equity curve."""
    equity = equity.dropna()
    out: dict[str, float] = {}
    if len(equity) < 3 or equity.iloc[0] <= 0:
        return {k: float("nan") for k in ("cagr", "vol", "sharpe", "sortino", "max_dd", "calmar")}
    r = _rets(equity)
    years = len(r) / TD
    end = max(equity.iloc[-1], 1e-12)
    cagr = (end / equity.iloc[0]) ** (1 / years) - 1 if years > 0 else 0.0
    vol = float(r.std() * math.sqrt(TD))
    ex = r - rf_annual / TD
    downside = float(np.sqrt(np.mean(np.minimum(ex.to_numpy(), 0.0) ** 2)) * math.sqrt(TD))
    mdd = max_drawdown(equity)
    m = equity.resample("ME").last()
    mret = m.pct_change().dropna()
    w = equity.resample("W-FRI").last().pct_change().dropna()
    q3 = (m / m.shift(3) - 1).dropna()
    ui = ulcer_index(equity)
    out.update(
        cagr=float(cagr), total_return=float(end / equity.iloc[0] - 1), vol=vol,
        sharpe=float(ex.mean() * TD / vol) if vol > 0 else 0.0,
        sortino=float(ex.mean() * TD / downside) if downside > 0 else 0.0,
        max_dd=mdd, calmar=float(cagr / abs(mdd)) if mdd < 0 else float("nan"),
        worst_day=float(r.min()), worst_week=float(w.min()) if len(w) else float("nan"),
        worst_month=float(mret.min()) if len(mret) else float("nan"),
        worst_3m=float(q3.min()) if len(q3) else float("nan"),
        pct_pos_months=float((mret > 0).mean()) if len(mret) else float("nan"),
        pct_pos_weeks=float((w > 0).mean()) if len(w) else float("nan"),
        ulcer=ui, return_ulcer=float(cagr * 100 / ui) if ui > 0 else float("nan"),
        longest_dd_days=float(longest_drawdown_days(equity)), r2=r2_log_equity(equity),
        skew=float(r.skew()), kurt=float(r.kurt() + 3.0), n_days=float(len(r)),
    )
    return out


def trade_stats(trades: pd.DataFrame, horizon_trades: int = 100, sims: int = 5000,
                seed: int = 1) -> dict[str, float]:
    """Hit rate, expectancy in R, exit-reason mix, consecutive-loss probabilities."""
    out: dict[str, float] = {"trades": 0.0}
    if trades is None or trades.empty:
        return out
    t = trades
    pnl = t["pnl"].to_numpy(dtype=float)
    wins, losses = pnl[pnl > 0], pnl[pnl <= 0]
    r = t["r_multiple"].replace([np.inf, -np.inf], np.nan).dropna().to_numpy(dtype=float)
    p_loss = float(len(losses) / len(pnl))
    out.update(
        trades=float(len(t)), hit_rate=float(len(wins) / len(pnl)),
        avg_win=float(t.loc[t["pnl"] > 0, "return_pct"].mean()) if len(wins) else 0.0,
        avg_loss=float(t.loc[t["pnl"] <= 0, "return_pct"].mean()) if len(losses) else 0.0,
        expectancy_r=float(r.mean()) if r.size else float("nan"),
        avg_r_win=float(r[r > 0].mean()) if (r > 0).any() else 0.0,
        avg_r_loss=float(r[r <= 0].mean()) if (r <= 0).any() else 0.0,
        profit_factor=float(wins.sum() / -losses.sum()) if losses.sum() < 0 else float("inf"),
        avg_hold_days=float(t["holding_days"].mean()) if "holding_days" in t else float("nan"),
        max_consec_losses=float(_max_streak(pnl <= 0)),
        p_5_losses=prob_loss_streak(p_loss, 5, horizon_trades, sims, seed),
        p_10_losses=prob_loss_streak(p_loss, 10, horizon_trades, sims, seed),
    )
    reasons = t["exit_reason"].astype(str)
    for key, names in {"exit_target": ["target"], "exit_stop": ["stop"], "exit_time": ["time"],
                       "exit_other": None}.items():
        if names is None:
            out[key] = float((~reasons.isin(["target", "stop", "time"])).mean())
        else:
            out[key] = float(reasons.isin(names).mean())
    return out


def _max_streak(mask: np.ndarray) -> int:
    best = cur = 0
    for v in mask:
        cur = cur + 1 if v else 0
        best = max(best, cur)
    return best


def prob_loss_streak(p_loss: float, k: int, n_trades: int, sims: int = 5000, seed: int = 1) -> float:
    """P(at least one run of >= k consecutive losses within n_trades independent trades)."""
    if p_loss <= 0 or n_trades < k:
        return 0.0
    if p_loss >= 1:
        return 1.0
    # exact via dynamic programming over current streak length
    state = np.zeros(k)
    state[0] = 1.0
    hit = 0.0
    for _ in range(n_trades):
        new = np.zeros(k)
        new[0] = state.sum() * (1 - p_loss)
        new[1:] = state[:-1] * p_loss
        hit += state[-1] * p_loss
        state = new
    return float(min(1.0, hit))


def monte_carlo_trades(contrib: np.ndarray, sims: int = 2000, seed: int = 12345) -> dict[str, float]:
    """Bootstrap the order of trade contributions (fraction of equity) -> max drawdown distribution."""
    c = np.asarray(contrib, dtype=float)
    c = c[np.isfinite(c)]
    if c.size < 5:
        return {}
    rng = np.random.default_rng(seed)
    sims = int(max(200, min(sims, 4_000_000 // max(1, c.size))))  # bound memory
    idx = rng.integers(0, c.size, size=(sims, c.size))
    paths = np.cumprod(1.0 + np.clip(c[idx], -1.0, None), axis=1)
    paths = np.concatenate([np.ones((sims, 1)), paths], axis=1)
    dds = (paths / np.maximum.accumulate(paths, axis=1) - 1.0).min(axis=1)
    finals = paths[:, -1]
    return {"mc_dd_p50": float(np.median(dds)), "mc_dd_p95": float(np.percentile(dds, 5)),
            "mc_dd_p99": float(np.percentile(dds, 1)), "mc_final_p05": float(np.percentile(finals, 5)),
            "mc_final_p50": float(np.median(finals))}


def monte_carlo_daily(equity: pd.Series, sims: int = 2000, block: int = 10, seed: int = 12345,
                      horizon_days: int | None = None, wipe_level: float = 0.10) -> dict[str, float]:
    """Block bootstrap of daily returns -> P(account loss > 50%), P(margin wipe), DD percentiles.

    `wipe_level`: a path counts as wiped when equity falls below 10% of the start
    (margin stop-out / negative balance protection territory).
    """
    r = _rets(equity.dropna()).to_numpy(dtype=float)
    if r.size < block * 3:
        return {}
    n = horizon_days or r.size
    rng = np.random.default_rng(seed)
    sims = int(max(200, min(sims, 4_000_000 // max(1, n))))
    nb = int(math.ceil(n / block))
    starts = rng.integers(0, r.size - block + 1, size=(sims, nb))
    idx = (starts[:, :, None] + np.arange(block)[None, None, :]).reshape(sims, -1)[:, :n]
    eq = np.cumprod(1.0 + np.clip(r[idx], -1.0, None), axis=1)
    lo = eq.min(axis=1)
    eq1 = np.concatenate([np.ones((sims, 1)), eq], axis=1)
    dd = (eq1 / np.maximum.accumulate(eq1, axis=1) - 1.0).min(axis=1)
    return {"p_loss_50": float((lo < 0.5).mean()), "p_wipe": float((lo < wipe_level).mean()),
            "mcd_dd_p50": float(np.median(dd)), "mcd_dd_p95": float(np.percentile(dd, 5))}


def deflated_sharpe(sr_annual: float, n_trials: int, n_obs: int, skew: float = 0.0, kurt: float = 3.0,
                    sr_trials_std: float | None = None) -> float:
    """Deflated Sharpe Ratio (Bailey & Lopez de Prado 2014): P(true SR > 0 | best of n_trials).

    Uses daily Sharpe internally. sr_trials_std defaults to 0.5 annual-SR across trials when unknown.
    """
    from statistics import NormalDist

    if n_obs < 10 or not math.isfinite(sr_annual):
        return float("nan")
    nd = NormalDist()
    sr = sr_annual / math.sqrt(TD)
    v = (sr_trials_std if sr_trials_std is not None else 0.5) / math.sqrt(TD)
    n = max(1, int(n_trials))
    if n > 1:
        emc = 0.5772156649
        sr0 = v * ((1 - emc) * nd.inv_cdf(1 - 1.0 / n) + emc * nd.inv_cdf(1 - 1.0 / (n * math.e)))
    else:
        sr0 = 0.0
    den = math.sqrt(max(1e-12, 1 - skew * sr + (kurt - 1) / 4.0 * sr * sr))
    z = (sr - sr0) * math.sqrt(n_obs - 1) / den
    return float(nd.cdf(z))


def exposure_stats(nav: pd.DataFrame) -> dict[str, float]:
    if nav is None or nav.empty:
        return {}
    return {"avg_gross": float(nav["gross"].mean()), "avg_core_gross": float(nav["core_gross"].mean()),
            "time_in_market": float((nav["core_gross"] > 0.01).mean()),
            "avg_open_risk": float(nav["open_risk"].mean())}


def benchmark_buy_hold(close: pd.Series, cost_bps: float = 5.0) -> pd.Series:
    c = close.dropna()
    return (c / c.iloc[0]) * (1 - cost_bps / 1e4)


def benchmark_mix(closes: pd.DataFrame, weights: dict[str, float], cost_bps: float = 5.0) -> pd.Series:
    """Monthly rebalanced mix (e.g. 60/40 SPY/IEF)."""
    c = closes[list(weights)].dropna()
    r = c.pct_change().fillna(0.0)
    w = np.array([weights[k] for k in weights])
    eq = [1.0 - cost_bps / 1e4]
    hold = w.copy()
    month = c.index[0].month
    for k in range(1, len(c)):
        rr = r.iloc[k].to_numpy()
        val = eq[-1] * float(hold @ (1 + rr))
        hold = hold * (1 + rr)
        hold = hold / hold.sum()
        if c.index[k].month != month:
            month = c.index[k].month
            turn = float(np.abs(hold - w).sum())
            val *= 1 - turn * cost_bps / 1e4
            hold = w.copy()
        eq.append(val)
    return pd.Series(eq, index=c.index)


def summarize(equity: pd.Series, trades: pd.DataFrame | None, nav: pd.DataFrame | None, mc_cfg: dict[str, Any]) -> dict[str, float]:
    out = performance(equity)
    out.update(trade_stats(trades if trades is not None else pd.DataFrame(), int(mc_cfg.get("horizon_trades", 100))))
    if trades is not None and not trades.empty:
        out.update(monte_carlo_trades(trades["contribution"].to_numpy(), int(mc_cfg.get("sims", 2000)),
                                      int(mc_cfg.get("seed", 12345))))
    out.update(monte_carlo_daily(equity, int(mc_cfg.get("sims", 2000)) // 2, int(mc_cfg.get("block_days", 10)),
                                 int(mc_cfg.get("seed", 12345))))
    if nav is not None:
        out.update(exposure_stats(nav))
    return out
