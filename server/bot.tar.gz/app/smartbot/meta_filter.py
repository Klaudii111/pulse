"""STUB - ML meta-filter (disabled).

Idea (Lopez de Prado "meta-labeling"): a gradient-boosting classifier predicts, for each
base signal, P(signal hits its target before the stop / time exit). Signals with low
probability are skipped or down-sized. Base signals and the risk layer stay unchanged.

Strict rules for a future implementation:
  * features only from data available at the signal's close (same causality tests)
  * labels = journal outcomes; a label is usable only after the trade closed
  * purged walk-forward / expanding-window training (no shuffling, embargo >= horizon)
  * refuses to enable before `min_live_months` of live journal data AND
    `min_closed_signals` closed signals (default 6 months / 100)
"""
from __future__ import annotations

from typing import Any

import pandas as pd


class MetaFilterNotReady(RuntimeError):
    pass


def check_ready(outcomes: pd.DataFrame, cfg: dict[str, Any]) -> None:
    mc = cfg.get("meta_filter", {})
    if not mc.get("enabled", False):
        raise MetaFilterNotReady("meta_filter disabled in config")
    if outcomes is None or outcomes.empty:
        raise MetaFilterNotReady("no closed live signals yet")
    span = (pd.to_datetime(outcomes["exit_date"]).max() - pd.to_datetime(outcomes["entry_date"]).min()).days / 30.4
    if span < float(mc.get("min_live_months", 6)) or len(outcomes) < int(mc.get("min_closed_signals", 100)):
        raise MetaFilterNotReady(f"need >= {mc.get('min_live_months', 6)} months and >= "
                                 f"{mc.get('min_closed_signals', 100)} closed signals (have {span:.1f} m, {len(outcomes)})")


class MetaFilter:
    """Placeholder interface: fit(features, labels) / predict_proba(features)."""

    def __init__(self, cfg: dict[str, Any]) -> None:
        self.cfg = cfg

    def fit(self, *_: Any, **__: Any) -> None:
        raise NotImplementedError("meta-filter is a documented stub")

    def predict_proba(self, *_: Any, **__: Any) -> Any:
        raise NotImplementedError("meta-filter is a documented stub")
