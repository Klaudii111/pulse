"""Alpaca PAPER trading executor.

Safety:
  * the paper endpoint is hard-coded; any other base URL (env ALPACA_BASE_URL or the
    client's resolved URL) makes the executor refuse to run
  * this module never constructs a live-trading client
  * orders are whole shares, market DAY orders submitted before the open
    (bracket stop/target legs as GTC), so they execute at the next open like the backtest

Order mapping from signals of the configured track:
  BUY   -> market buy with bracket (stop-loss + take-profit) or OTO stop when no target
  SELL  -> cancel the symbol's open orders, market sell the position
  HOLD  -> if the stop moved up (trailing), replace the stop leg's stop price
  time exit due next session -> cancel open orders, market-on-close (TIF cls) sell - unless the model
           ROLLS the position (signal.rolls, e.g. MESIC roll_on_time_exit): then only the stop is updated.
           NOTE: on that last day the position is not stop-protected at the broker.
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Any, Protocol
from urllib.parse import urlparse

from .config import Secrets
from .engine import Signal

log = logging.getLogger(__name__)

PAPER_BASE_URL = "https://paper-api.alpaca.markets"
_PAPER_HOST = "paper-api.alpaca.markets"


class PaperGuardError(RuntimeError):
    """Raised whenever anything points to a non-paper endpoint."""


def assert_paper_url(url: str | None) -> str:
    """Return the paper URL; refuse anything that is not exactly the Alpaca paper host."""
    if url is None or str(url).strip() == "":
        return PAPER_BASE_URL
    u = str(getattr(url, "value", url)).strip().rstrip("/")
    parsed = urlparse(u)
    if parsed.scheme != "https" or parsed.hostname != _PAPER_HOST:
        raise PaperGuardError(f"refusing to run: base URL {u!r} is not the Alpaca PAPER endpoint {PAPER_BASE_URL}")
    return PAPER_BASE_URL


@dataclass
class PlannedOrder:
    symbol: str
    side: str            # buy | sell
    qty: int
    kind: str            # bracket | oto | market | moc | replace_stop | cancel
    stop: float | None = None
    target: float | None = None
    reason: str = ""


class BrokerClient(Protocol):
    def get_account(self) -> Any: ...
    def get_all_positions(self) -> Any: ...
    def get_orders(self, *args: Any, **kwargs: Any) -> Any: ...
    def submit_order(self, *args: Any, **kwargs: Any) -> Any: ...
    def cancel_order_by_id(self, *args: Any, **kwargs: Any) -> Any: ...
    def replace_order_by_id(self, *args: Any, **kwargs: Any) -> Any: ...


def plan_orders(signals: list[Signal], equity: float, positions: dict[str, float], max_leverage: float = 1.0,
                next_session: str | None = None, use_bracket: bool = True) -> list[PlannedOrder]:
    """Pure function: signals -> broker orders (testable without a broker)."""
    plan: list[PlannedOrder] = []
    for s in signals:
        held = int(positions.get(s.symbol, 0))
        if s.action == "SELL" and not s.executed and held > 0:
            plan.append(PlannedOrder(s.symbol, "sell", held, "market", reason=",".join(s.reasons)))
        elif s.action == "BUY" and held == 0:
            notional = min(s.size_pct * equity, equity * max_leverage)
            qty = int(math.floor(notional / s.ref_price)) if s.ref_price > 0 else 0
            if qty <= 0:
                continue
            kind = "bracket" if (use_bracket and s.target) else "oto"
            plan.append(PlannedOrder(s.symbol, "buy", qty, kind, round(s.stop, 2),
                                     round(s.target, 2) if s.target else None, ",".join(s.reasons)))
        elif s.action == "HOLD" and held > 0:
            if next_session is not None and s.exit_due == next_session and not getattr(s, "rolls", False):
                plan.append(PlannedOrder(s.symbol, "sell", held, "moc", reason="time_exit"))
            else:
                plan.append(PlannedOrder(s.symbol, "sell", held, "replace_stop", stop=round(s.stop, 2),
                                         reason="trail_stop"))
    return plan


class AlpacaPaperExecutor:
    def __init__(self, secrets: Secrets, client: BrokerClient | None = None) -> None:
        assert_paper_url(secrets.alpaca_base_url)  # env override must also be paper
        if client is None:
            if not (secrets.alpaca_key_id and secrets.alpaca_secret_key):
                raise PaperGuardError("ALPACA_KEY_ID / ALPACA_SECRET_KEY not set")
            from alpaca.trading.client import TradingClient

            client = TradingClient(secrets.alpaca_key_id, secrets.alpaca_secret_key, paper=True,
                                   url_override=PAPER_BASE_URL)
        resolved = getattr(client, "_base_url", PAPER_BASE_URL)
        assert_paper_url(str(getattr(resolved, "value", resolved)))
        self.client = client

    def account_equity(self) -> float:
        acc = self.client.get_account()
        num = str(getattr(acc, "account_number", ""))
        if num and not num.upper().startswith("PA"):
            log.warning("account number %s does not look like a paper account (expected PA...)", num)
        return float(getattr(acc, "equity", 0.0))

    def positions(self) -> dict[str, float]:
        return {str(p.symbol): float(p.qty) for p in self.client.get_all_positions()}

    def _open_orders(self, symbol: str) -> list[Any]:
        try:
            from alpaca.trading.enums import QueryOrderStatus
            from alpaca.trading.requests import GetOrdersRequest

            req = GetOrdersRequest(status=QueryOrderStatus.OPEN, symbols=[symbol], nested=True)
            return list(self.client.get_orders(filter=req))
        except ImportError:  # fake client in tests
            return list(self.client.get_orders(symbol=symbol))

    def execute(self, plan: list[PlannedOrder], dry_run: bool = True) -> list[str]:
        log_lines = []
        for o in plan:
            line = f"{o.kind} {o.side} {o.qty} {o.symbol} stop={o.stop} target={o.target} ({o.reason})"
            log_lines.append(line)
            if dry_run:
                continue
            self._submit(o)
        return log_lines

    def _submit(self, o: PlannedOrder) -> None:
        from alpaca.trading.enums import OrderClass, OrderSide, TimeInForce
        from alpaca.trading.requests import MarketOrderRequest, ReplaceOrderRequest, StopLossRequest, TakeProfitRequest

        if o.kind in ("market", "moc"):
            for od in self._open_orders(o.symbol):
                self.client.cancel_order_by_id(od.id)
            self.client.submit_order(MarketOrderRequest(
                symbol=o.symbol, qty=o.qty, side=OrderSide.SELL,
                time_in_force=TimeInForce.CLS if o.kind == "moc" else TimeInForce.DAY))
        elif o.kind in ("bracket", "oto"):
            kw: dict[str, Any] = dict(symbol=o.symbol, qty=o.qty, side=OrderSide.BUY, time_in_force=TimeInForce.GTC,
                                      stop_loss=StopLossRequest(stop_price=o.stop))
            if o.kind == "bracket":
                kw.update(order_class=OrderClass.BRACKET, take_profit=TakeProfitRequest(limit_price=o.target))
            else:
                kw.update(order_class=OrderClass.OTO)
            self.client.submit_order(MarketOrderRequest(**kw))
        elif o.kind == "replace_stop":
            for od in self._open_orders(o.symbol):
                legs = [od] + list(getattr(od, "legs", None) or [])
                for leg in legs:
                    if str(getattr(leg, "type", "")).lower().endswith("stop") and getattr(leg, "stop_price", None):
                        if o.stop and float(leg.stop_price) < o.stop:
                            self.client.replace_order_by_id(leg.id, ReplaceOrderRequest(stop_price=o.stop))
